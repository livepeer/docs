# Codex Content Briefs — P1 Blockers
## Grounded in actual docs-v2-dev branch state

Each brief is a complete, self-contained Codex agent task.  
Base: `docs-v2-dev`. One worktree. One branch. One PR. No combining.

---

## BRIEF ORC-A — `v2/orchestrators/concepts/job-types.mdx`

**Branch:** `content/orc-job-types`  
**Type:** NEW page  
**Priority:** P1 — Persona C (Pro Operator) and E (AI Native) blocked

### Step 0 — Read before writing
```
v2/orchestrators/concepts/capabilities.mdx    ← what exists in concepts already
v2/orchestrators/concepts/incentive-model.mdx ← avoid overlap
/mnt/project/ai-workloads-overview.mdx
/mnt/project/ai-workloads-sources.md
/mnt/project/gpu-nodes-ia-planning.md         ← Persona C + E profiles
```

### Brief
```
Who reads this:   GPU operator deciding what their hardware can run
What they need:   Know which job types exist, what hardware each needs, which to prioritise
Page type:        concept
Reader question:  What types of jobs can my orchestrator process and what are the
                  hardware requirements for each?
Promise:          After reading, reader knows which job types their GPU supports
                  and what to enable
In scope:         Job type taxonomy, VRAM requirements per pipeline, realtime vs batch,
                  dual workload trade-offs
Out of scope:     How to configure aiModels.json (→ guides/ai-and-job-workloads/ai-pipelines.mdx)
                  Pricing per job type (→ guides/config-and-optimisation/pricing-strategy.mdx)
Primary sources:  ai-workloads-overview.mdx, go-livepeer AI subnet, ai-workloads-sources.md
Next page:        quickstart/AI-prompt-start.mdx OR guides/ai-and-job-workloads/ai-pipelines.mdx
```

### Required sections
1. **Two job categories** — Video transcoding (low VRAM, stable demand) vs AI inference (high VRAM, growing demand). Can run both.
2. **Video transcoding** — What it is, VRAM floor, job routing mechanics, performance variables.
3. **AI inference: Realtime** — What realtime means (streaming, Cascade), supported pipelines, VRAM minimums per pipeline in a table.
4. **AI inference: Batch** — What batch means, supported pipelines, when gateways use batch.
5. **Pipeline catalogue table** — Columns: Pipeline | Type (realtime/batch) | VRAM minimum | GPU class recommended. Rows: text-to-image, image-to-image, image-to-video, audio-to-text, LLM, upscale, segment. Mark each with current supported status.
6. **Dual workload** — Running transcoding + AI on same GPU: capacity allocation, trade-offs, when to separate.
7. **Next step** — Enable AI pipelines → `guides/ai-and-job-workloads/ai-pipelines.mdx`

### Output
`v2/orchestrators/concepts/job-types.mdx` — ~8KB

---

## BRIEF ORC-B — `v2/orchestrators/resources/faq.mdx`

**Branch:** `content/orc-faq`  
**Type:** NEW page  
**Priority:** P1 — confirmed journey blocker across all personas

### Step 0 — Read before writing
```
v2/orchestrators/resources/glossary.mdx      ← what's already in resources
/mnt/project/gpu-nodes-ia-planning.md        ← all persona pain points
/mnt/project/local-gateways-discord.txt      ← Discord error patterns
```

### Required Q&A sections

**Evaluation questions**
- How much LPT do I need to run a solo orchestrator?
- What's the difference between a solo orchestrator and a pool worker?
- How much can I realistically earn?
- What hardware is the minimum? What's optimal?
- How long until I start getting jobs after setup?

**Startup / activation errors**
- "Orchestrator not available" — causes and fixes
- Port forwarding: serviceAddr setup, common home router issues
- What ports must be open for go-livepeer?
- ETH balance too low — what's the minimum to activate?

**Operational questions**
- Why am I not receiving jobs when I'm in the active set?
- How do I check if I'm actually in the active set?
- How do I set a competitive price per pixel?
- How do I monitor earnings in real time?

**AI pipeline questions**
- What VRAM minimum for AI pipelines?
- How do I add AI pipelines to an existing transcoding node?
- What is aiModels.json and where does it live?
- Models not loading — how do I diagnose?

### Output
`v2/orchestrators/resources/faq.mdx` — ~12KB, Q&A format with Accordion components

---

## BRIEF GW-A — `v2/gateways/concepts/payment-modes.mdx`

**Branch:** `content/gw-payment-modes`  
**Type:** NEW page  
**Priority:** P1 — first gateway architecture decision, all personas blocked

### Step 0 — Read before writing
```
v2/gateways/concepts/role.mdx               ← what concepts already cover
v2/gateways/concepts/architecture.mdx
v2/gateways/concepts/business-model.mdx
v2/gateways/navigator.mdx                   ← what the navigator covers
/mnt/project/Remote_signers.md
/mnt/project/local-gateways-discord.txt
/mnt/project/gateways-ia-planning.md        ← Persona A pain points
```

### Brief
```
Who reads this:   Gateway operator who just decided to run a gateway, making first architecture decision
What they need:   Understand on-chain vs off-chain, pick the right mode, know next step
Page type:        concept
Reader question:  What is the difference between on-chain and off-chain gateway mode
                  and which should I use?
Promise:          After reading, reader knows which mode fits their use case and
                  what their next setup step is
In scope:         Mode distinction, remote signer intro, clearinghouse intro, decision matrix
Out of scope:     How to set up remote signers (→ setup/remote-signers.mdx)
                  Full clearinghouse architecture (→ guides/payments-and-pricing/clearinghouse.mdx)
                  Pricing configuration (→ guides/payments-and-pricing/)
Primary sources:  Remote_signers.md, local-gateways-discord.txt, gateways-ia-planning.md
Next page:        Off-chain → quickstart/. On-chain → setup/remote-signers.mdx
```

### Required sections
1. **Two modes** — What on-chain and off-chain mean. Core difference: ETH key management and probabilistic micropayment (PM) ticket settlement.
2. **On-chain gateway** — Who it's for. Requirements: funded ETH key, PM ticket management. Use when: full orchestrator control, running public gateway service.
3. **Off-chain gateway** — Who it's for. Requirements: remote signer or clearinghouse handles signing. Use when: AI workloads, app-embedded gateways, getting started fast.
4. **Remote signer** — 1 paragraph: what it is, why it exists, hosted vs self-hosted option. Link to `setup/remote-signers.mdx` for setup.
5. **Clearinghouse** — 1 paragraph: remote signer + auth + accounting + discovery in one managed service. Link to `guides/payments-and-pricing/clearinghouse.mdx`.
6. **Decision matrix** — Table: Use case | Recommended mode. Rows: AI inference app / Video transcoding service / Public gateway service / Testing and dev / Production at scale.
7. **Next steps** — Two paths with links.

### Tone
Persona A is a developer comfortable with Docker + REST APIs but new to crypto payment rails. Define PM tickets in one sentence.

### Output
`v2/gateways/concepts/payment-modes.mdx` — ~8KB

---

## BRIEF DEV-A — `v2/developers/concepts/ai-on-livepeer.mdx`

**Branch:** `content/dev-ai-concept`  
**Type:** REWRITE  
**Priority:** P1 — current version pre-dates NaaP/clearinghouse model

### Step 0 — Read before writing
```
v2/developers/concepts/ai-on-livepeer.mdx   ← current state (read it fully first)
v2/developers/concepts/developer-stack.mdx  ← avoid overlap
/mnt/project/ai-workloads-sources.md
/mnt/project/ai-workloads-overview.mdx
/mnt/project/local-gateways-discord.txt     ← NaaP, clearinghouse quotes
```

### Brief
```
Who reads this:   ML engineer / app developer evaluating Livepeer for AI inference
What they need:   Understand how Livepeer's AI network works and whether it fits
Page type:        concept
Reader question:  How does AI inference work on the Livepeer network and is it
                  right for my application?
Promise:          After reading, reader understands AI network architecture and
                  knows which entry point fits their use case
In scope:         AI network architecture, pipelines available, hosted vs self-hosted
                  entry points, realtime vs batch distinction, NaaP/clearinghouse model
Out of scope:     SDK implementation (→ get-started/ai-quickstart.mdx)
                  Gateway operation (→ Gateways tab)
                  Video transcoding (→ concepts/video.mdx)
Primary sources:  ai-workloads-sources.md, local-gateways-discord.txt (NaaP/clearinghouse)
Next page:        get-started/setup-paths.mdx
```

### Required sections
1. **How AI works on Livepeer** — Pipelines (text-to-image, image-to-video, LLM, audio-to-text). Gateways route requests. GPU Orchestrators execute. ETH micropayment settlement.
2. **Two entry points** — Hosted API (NaaP/Daydream: get API key, make calls, nothing else). Self-hosted gateway (for cost control at scale, full configuration). Clear when to use each.
3. **The clearinghouse model** — For hosted entry: clearinghouse abstracts payment, orchestrator selection, auth. Developer gets an API key. Quote the Discord framing: "Give the SDK an API key and go."
4. **Available pipelines** — Current supported types with brief descriptions. Link to resources for full model list.
5. **Realtime vs batch** — What each means. Which pipelines support which. When your application needs each. This is the pre-decision for quickstart choice.
6. **Next step** — Decision: hosted API → get API key. Self-hosted → `get-started/setup-paths.mdx`.

### Output
`v2/developers/concepts/ai-on-livepeer.mdx` — ~10KB rewrite

---

## BRIEF ORC-C — `v2/orchestrators/quickstart/join-a-pool.mdx`

**Branch:** `content/orc-join-pool`  
**Type:** NEW page  
**Priority:** P1 — Persona B (Pool Worker) has no path

### Step 0 — Read before writing
```
v2/orchestrators/quickstart/video-transcoding.mdx  ← quickstart format reference
v2/orchestrators/concepts/role.mdx                  ← how pools are described
/mnt/project/setup-paths-sources.md                 ← Titan Node repo, OrchestratorSiphon
/mnt/project/gpu-nodes-ia-planning.md               ← Persona B profile
```

### Brief
```
Who reads this:   Person with 1-2 consumer GPUs who doesn't want to manage LPT staking
What they need:   Run go-livepeer as a pool worker and connect to a pool
Page type:        tutorial
Reader question:  How do I contribute GPU compute to Livepeer through a pool
                  without running a full orchestrator?
Promise:          After reading, reader has go-livepeer running as a worker node
                  connected to a pool and processing jobs
In scope:         Pool worker setup path: install as worker, connect to pool, verify
Out of scope:     Solo orchestrator setup (→ quickstart/video-transcoding.mdx)
                  Running your own pool (→ guides/advanced-operations/run-a-pool.mdx)
                  LPT staking (→ LP Token tab)
Primary sources:  setup-paths-sources.md (Titan Node GitHub, OrchestratorSiphon README)
Next page:        guides/monitoring-and-tooling/ (monitoring once running)
```

### Required sections
1. **Pool worker vs solo orchestrator** — 1 paragraph. Key difference: no LPT needed, pool handles on-chain. You provide compute, pool distributes rewards.
2. **Prerequisites** — GPU with 4GB+ VRAM, OS, NVIDIA drivers, network ports.
3. **Step 1: Install go-livepeer** — Link to `setup/install.mdx`. Don't repeat.
4. **Step 2: Configure as transcoder worker** — Exact flags for worker-only mode (not full orchestrator mode). `-transcoder`, `-orchAddr`.
5. **Step 3: Connect to a pool** — How to point worker at pool orchestrator endpoint. Reference community pools without endorsing specific ones.
6. **Step 4: Verify** — How to confirm worker is accepting and processing jobs.
7. **Find a pool** — Link to `resources/community-pools.mdx`.

### Tone
Persona B is not a devops professional. Terminal-comfortable. Concrete commands. No jargon without definition.

### Output
`v2/orchestrators/quickstart/join-a-pool.mdx` — ~8KB

---

## BRIEF ORC-D — `v2/orchestrators/quickstart/setup-paths.mdx`

**Branch:** `content/orc-setup-paths`  
**Type:** NEW page  
**Priority:** P1 — all personas need pre-decision before quickstart

### Step 0 — Read before writing
```
v2/orchestrators/quickstart/guide.mdx       ← current thin path selector
/mnt/project/gpu-nodes-ia-planning.md       ← all 5 personas
/mnt/project/setup-paths-sources.md
```

### Required sections
1. **Four paths** — Brief intro: choose your path before you start.
2. **Decision table** — Rows: Solo transcoding / Pool worker / AI inference / Dual (transcoding + AI). Columns: LPT required | VRAM minimum | Technical complexity | Best for.
3. **Path A: Solo Orchestrator** — Who it's for, what you need (LPT stake, hardware), link to `quickstart/video-transcoding.mdx`.
4. **Path B: Pool Worker** — Who it's for, what you need (no LPT), link to `quickstart/join-a-pool.mdx`.
5. **Path C: AI Inference** — Who it's for, VRAM requirement, link to `quickstart/AI-prompt-start.mdx`.
6. **Path D: Dual** — Who it's for, combined requirements, link to `guides/ai-and-job-workloads/ai-pipelines.mdx`.

### Output
`v2/orchestrators/quickstart/setup-paths.mdx` — ~6KB

---

## BRIEF ORC-E — `v2/orchestrators/setup/publish-offerings.mdx`

**Branch:** `content/orc-publish`  
**Type:** NEW page  
**Priority:** P1 — solo orchestrator path breaks at on-chain activation

### Step 0 — Read before writing
```
v2/orchestrators/setup/connect.mdx          ← previous setup step
v2/orchestrators/setup/verify.mdx           ← next setup step
go-livepeer livepeer_cli documentation
```

### Brief
```
Who reads this:   Solo orchestrator operator who has installed + configured, now activating on-chain
What they need:   Register on the network and start receiving jobs
Page type:        how-to
Reader question:  How do I activate my orchestrator on the Livepeer network so it
                  can receive jobs?
Promise:          After reading, orchestrator is registered on-chain and eligible
                  to receive work
In scope:         livepeer_cli activation steps, service URI configuration, LPT stake
                  requirement, marketplace registration
Out of scope:     Installing go-livepeer (→ setup/install.mdx)
                  Pricing configuration (→ guides/config-and-optimisation/)
Primary sources:  go-livepeer livepeer_cli docs, v2/orchestrators/setup/connect.mdx
Next page:        setup/verify.mdx
```

### Output
`v2/orchestrators/setup/publish-offerings.mdx` — ~8KB

---

## BRIEF GW-B — `v2/gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx`

**Branch:** `content/gw-orch-discovery`  
**Type:** NEW page  
**Priority:** P1 — off-chain gateway gets no jobs without this

### Step 0 — Read before writing
```
v2/gateways/setup/connect.mdx               ← how on-chain discovery works
v2/gateways/guides/advanced-operations/     ← what advanced-operations already covers
/mnt/project/local-gateways-discord.txt     ← j0sh, EliteEncoder quotes on discovery
j0sh livepeer-python-gateway examples: github.com/j0sh/livepeer-python-gateway/tree/main/examples
```

### Required sections
1. **The discovery problem** — Off-chain gateways don't use on-chain registry automatically. They need an orchestrator list from somewhere.
2. **Option A: On-chain list endpoint** — Using the go-livepeer endpoint to get the authoritative on-chain orchestrator list. Configuration flags.
3. **Option B: Static list** — Hardcoded orchestrator addresses in CLI flags. When to use. Limitations.
4. **Option C: Custom discovery endpoint** — Building or using an external endpoint. Python gateway examples. Configuration.
5. **Reference implementations** — j0sh livepeer-python-gateway examples (link). EliteEncoder remote signer which also provides discovery.
6. **Recommended** — Production: on-chain endpoint or clearinghouse discovery. Testing: static list.

### Output
`v2/gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx` — ~8KB

---

## BRIEF GW-C — `v2/gateways/setup/remote-signers.mdx`

**Branch:** `content/gw-remote-signers`  
**Type:** NEW page  
**Priority:** P1 — on-chain gateway path blocked without this

### Step 0 — Read before writing
```
v2/gateways/concepts/payment-modes.mdx      ← where reader comes from (GW-A)
v2/gateways/setup/configure.mdx             ← adjacent setup step
/mnt/project/Remote_signers.md              ← full design doc — primary source
/mnt/project/local-gateways-discord.txt     ← EliteEncoder hosted signer at signer.eliteencoder.net
go-livepeer PRs #3791 and #3822
```

### Brief
```
Who reads this:   Gateway operator who chose on-chain mode, now configuring key separation
What they need:   Working remote signer, gateway configured to use it
Page type:        how-to
Reader question:  How do I set up a remote signer for my on-chain gateway?
Promise:          After reading, remote signer is running and gateway is signing
                  via it (not direct key exposure)
In scope:         Hosted option + self-hosted option + gateway configuration flags
Out of scope:     What remote signers are and why (→ concepts/payment-modes.mdx)
                  Clearinghouse (→ guides/payments-and-pricing/clearinghouse.mdx)
Primary sources:  Remote_signers.md, PRs #3791/#3822, local-gateways-discord.txt
Next page:        setup/configure.mdx
```

### Required sections
1. **Prerequisites** — Ethereum wallet with ETH, go-livepeer installed, on-chain mode decision made.
2. **Option A: Use a hosted remote signer** — Community-hosted signer (signer.eliteencoder.net — from Discord). Configuration flags to point gateway at external signer.
3. **Option B: Self-host the remote signer** — Docker setup for the remote signer service. Required env vars. Startup verification.
4. **Configure your gateway** — Specific go-livepeer flags: `-remoteSignerAddr` and any auth configuration.
5. **Verify** — How to confirm gateway is signing via remote signer (not direct key).
6. **Security** — Key custody, network exposure of signer endpoint. Brief, factual. Not a threat list.

### Output
`v2/gateways/setup/remote-signers.mdx` — ~10KB

---

## BRIEF GW-D — `v2/gateways/guides/payments-and-pricing/clearinghouse.mdx`

**Branch:** `content/gw-clearinghouse`  
**Type:** NEW page  
**Priority:** P1 — Provider persona (B) completely blocked; Discord-confirmed gap

### Step 0 — Read before writing
```
v2/gateways/guides/payments-and-pricing/    ← what payments section already covers
v2/gateways/setup/remote-signers.mdx        ← GW-C (should be merged before this)
/mnt/project/local-gateways-discord.txt     ← "Yeah that would basically be the clearinghouse"
/mnt/project/Remote_signers.md
```

### Brief
```
Who reads this:   Gateway operator building a gateway service business (Persona B: Provider)
What they need:   Understand the clearinghouse architecture and evaluate whether to
                  build or use one
Page type:        concept
Reader question:  What is the clearinghouse and how does it provide a complete
                  managed gateway infrastructure?
Promise:          After reading, reader understands all clearinghouse components
                  and can evaluate build vs use decisions
In scope:         Component definitions, how they fit together, NaaP reference,
                  build vs use guidance
Out of scope:     Remote signer setup (→ setup/remote-signers.mdx)
                  NaaP-specific API docs (→ NaaP product docs if they exist)
Primary sources:  local-gateways-discord.txt, Remote_signers.md
Next page:        guides/advanced-operations/ for production scaling
```

### Required sections
1. **What the clearinghouse is** — Component definition derived from Discord: remote signer + user management/auth + accounting + orchestrator discovery + billing. One concrete paragraph.
2. **Why it exists** — The problem it solves: app developers shouldn't think about PM tickets, remote signers, or orchestrator lists. "Give the SDK an API key and go."
3. **Components** — Each explained in 2-3 sentences: Remote Signer, Auth/API key management, Accounting, Orchestrator discovery, Billing layer.
4. **How they fit together** — Flow: request → API key auth → clearinghouse routes → remote signer signs → payment → orchestrator executes.
5. **NaaP** — Network as a Platform is building this. What it offers. Link if public docs exist.
6. **Build vs use** — When to build your own clearinghouse stack (large scale, custom requirements) vs use NaaP (fastest path, managed). One table or clear criteria.

### Output
`v2/gateways/guides/payments-and-pricing/clearinghouse.mdx` — ~12KB
