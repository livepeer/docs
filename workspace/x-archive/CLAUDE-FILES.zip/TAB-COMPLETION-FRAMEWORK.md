# Tab Completion Framework
## Quality gates per tab — grounded in docs-v2-dev branch state

> A tab ships when every gate is GREEN.  
> Red = blocking. Yellow = degraded but shippable.

---

## UNIVERSAL GATES (all tabs)

| # | Gate | Test |
|---|---|---|
| U1 | No published stubs | Every page in docs.json nav has substantive content (>2KB, not "Coming Soon") |
| U2 | Zero-to-hero complete | A reader with no prior knowledge can complete the full journey without Discord |
| U3 | Discord test passed | Every question appearing 3+ times in Discord has a linkable page answer |
| U4 | Opening paragraph contract | Subject → what this page does → constraint. No anti-patterns. |
| U5 | No dead ends | Every page has a clear next step or explicit handoff |
| U6 | Trade-offs named | Every concept/economics/architecture page has at least one named failure condition |
| U7 | Primary sources verifiable | No factual claim without a traceable source |

---

## HOME

| Gate | Test | Status |
|---|---|---|
| H1 | 4 get-started/* stubs removed from nav | docs.json edit only | 🔴 |
| H2 | roadmap.mdx has content or redirects | Write 2 paragraphs or redirect | 🔴 |
| H3 | ecosystem.mdx Foundation current | June 2025 Foundation launch reflected | ⚠️ |
| H4 | trending.mdx has review mechanism | Date-stamp or remove | ⚠️ |

---

## ABOUT

| Gate | Test | Status |
|---|---|---|
| A1 | actors.mdx comprehensive | Single page ~15KB, all 4 actors, sub-stubs merged in, removed from nav | 🔴 |
| A2 | Ecosystem/products page exists | What's been built — NEW page needed | 🔴 |
| A3 | evaluating-livepeer.mdx written | Stub → real content | 🟡 P3 |
| A4 | core-mechanisms.mdx complete | Identify + fill unfinished sections | ⚠️ |
| A5 | network-metrics.mdx has real data | Real figures or live data component | ⚠️ |
| A6 | All 4 actor sub-stubs removed from nav | Remove livepeer-actors/* from docs.json | 🔴 |

---

## GPU NODES / ORCHESTRATORS

| Gate | Persona | Test | Status |
|---|---|---|---|
| O1 | Solo operator zero-to-hero | A | install → configure → connect → verify chain unbroken | ✅ |
| O2 | Pool worker path exists | B | join-a-pool.mdx written and in nav | 🔴 |
| O3 | Setup paths decision matrix | All | setup-paths.mdx: solo/pool/AI/enterprise matrix | 🔴 |
| O4 | Job types current | C, E | job-types.mdx: transcoding vs AI types, VRAM per pipeline, realtime vs batch | 🔴 |
| O5 | FAQ has troubleshooting | All | 20+ Q&As covering Discord-confirmed errors | 🔴 |
| O6 | On-chain activation documented | A, C | publish-offerings.mdx written | 🔴 |
| O7 | AI pipeline config documented | C, E | aiModels.json schema, containers, warm loading | 🟡 |
| O8 | Competitive pricing guide | All | pricing-strategy.mdx — Discord #1 pain | 🔴 |
| O9 | Pool operator guide | C, D | run-a-pool.mdx expanded | 🟡 |
| O10 | Enterprise path exists | D | data-centre-setup.mdx written | 🟡 |
| O11 | CLI flags reference | All | cli-flags.mdx complete | 🟡 |
| O12 | Community pools directory | B | community-pools.mdx written | 🟡 |

---

## GATEWAYS

| Gate | Persona | Test | Status |
|---|---|---|---|
| G1 | Payment modes concept page | A | on-chain vs off-chain — decision page exists | 🔴 |
| G2 | Remote signers documented | A, B | setup/remote-signers.mdx written (post PRs #3791/#3822) | 🔴 |
| G3 | Clearinghouse documented | B | guides/payments-and-pricing/clearinghouse.mdx written | 🔴 |
| G4 | Off-chain discovery documented | A | guides/advanced-operations/orchestrator-discovery-offchain.mdx written | 🔴 |
| G5 | Dual AI+video config | C | setup/configure/dual.mdx written | 🟡 |
| G6 | Graduate journey complete | A | "I was using Daydream, now I want self-hosted" path unbroken | 🟡 |
| G7 | Go-production tutorial | B | guides/tutorials/go-production.mdx complete | 🟡 |

---

## DEVELOPERS

| Gate | Persona | Test | Status |
|---|---|---|---|
| D1 | AI on Livepeer concept current | AI dev | ai-on-livepeer.mdx reflects NaaP/clearinghouse/AI subnet | 🔴 |
| D2 | Setup paths decision tree | All | get-started/setup-paths.mdx: "which quickstart?" pre-decision | 🟡 |
| D3 | Auth guide complete | AI dev | guides/ai/authentication.mdx: auth flows documented | 🟡 |
| D4 | Production checklist complete | All | guides/ai/production-checklist.mdx: pre-launch complete | 🟡 |
| D5 | Video developer zero-to-hero | Video dev | full video path unbroken | ✅ |

---

## LP TOKEN / DELEGATORS

| Gate | Test | Status |
|---|---|---|
| LP1 | Delegation journey complete | bridge → choose → delegate → manage chain | ✅ |
| LP2 | Governance voting path | processes.mdx current (GovWorks Feb 2025 update) | ⚠️ verify |
| LP3 | Treasury proposals current | proposals.mdx current process verified | ⚠️ verify |
| LP4 | Tokenomics numbers current | post-AI subnet inflation numbers verified | ⚠️ verify |

**This tab needs 3 currency verifications, no new pages.**

---

## COMMUNITY

| Gate | Test | Status |
|---|---|---|
| C1 | Foundation info current everywhere | June 2025 Foundation launch in all pages | 🔴 |
| C2 | Workstreams routes to live source | Points to Forum, doesn't duplicate volatile state | 🔴 |
| C3 | Platform map complete | channels.mdx has full platform table (Discord/Forum/Telegram/X/YouTube/GitHub) | ⚠️ |
| C4 | Events/calls schedule current | Recurring calls with schedule | ⚠️ |
| C5 | Final IA implemented | Renames per community-tab-05-final-ia-and-pages.md canonical plan | ⚠️ |

---

## SOLUTIONS

| Gate | Test | Status |
|---|---|---|
| S1 | Each product: overview + quickstart | daydream/embody/frameworks expanded | ⚠️ |
| S2 | Bridge from About exists | about/concepts/ecosystem-products.mdx links here | 🔴 |

---

## RESOURCES

| Gate | Test | Status |
|---|---|---|
| R1 | Changelogs current | go-livepeer latest release reflected | ⚠️ check |

**Status: ✅ Publishable. Just keep changelogs current.**

---

## INDIVIDUAL PAGE QUALITY TEST

Every page before merge:

```
□ 1. Who is reading this? (one specific person, one moment in their journey)
□ 2. What are they trying to accomplish?
□ 3. Opening: subject → what this page does → constraint (3 sentences, no anti-patterns)
□ 4. Every factual claim has a traceable primary source
□ 5. Clear "next step" — where does the reader go after this page?
□ 6. Can a reader with stated prerequisites complete the task without leaving the page?
```

All 6 must pass. 5/6 = fail.

---

## ANTI-PATTERNS BANNED IN ALL PAGES

```
BAD: "This page will help you understand..."      → document self-description
BAD: "Depending on your setup..."                  → conditional hedge opening
BAD: "Running an orchestrator costs real money..." → barrier before value
BAD: "Livepeer is a powerful and flexible..."      → enthusiasm without information
BAD: "Whether it makes sense depends on..."        → restating the reader's question

GOOD: "Orchestrators earn by processing jobs routed from Gateways. 
       This page covers [concrete thing]. 
       For [out of scope thing], see [link]."
```
