# Livepeer Docs v2 — First-Principles Site Map
## Grounded in actual docs-v2-dev branch (read 2026-04-07)

> Derived from: what each human type needs to accomplish.  
> Verified against: actual `docs-v2-dev` file structure.  
> Every file path is real. Every gap is confirmed against the repo.

---

## THE SIX HUMAN TYPES — SUCCESS DEFINITIONS

| Human | Their goal | "Done" means |
|---|---|---|
| **GPU Operator** | Earn ETH + LPT from GPU hardware | Node running, jobs processing, earnings visible in Explorer |
| **Gateway Operator** | Route jobs through network profitably | Gateway processing jobs, payments settling correctly |
| **Developer / Builder** | Ship a product using Livepeer AI or video APIs | First successful API call, production-ready integration |
| **Delegator / LPT Holder** | Stake LPT, earn rewards, participate in governance | Stake active on Arbitrum, rewards accruing, can vote |
| **Community Participant** | Contribute meaningfully, stay connected | In the right channel, taken one concrete action |
| **Evaluator** | Accurately assess Livepeer before committing | Can explain architecture, economics, governance, ecosystem |

---

## THE IA PATTERN — ALL ROLE TABS

Every role tab in docs-v2-dev uses this locked 6-position structure:

```
portal.mdx          Position 1a  Landing / orientation
navigator.mdx       Position 1b  Journey / persona path selector
concepts/           Position 2   What is this? How does it work?
quickstart/         Position 3   Get me to first success fast
setup/              Position 4   Full operational setup
guides/             Position 5   Depth, advanced, operational
resources/          Position 6   Reference lookup
```

This structure is correct. The gaps are content completeness within it.

---

## HOME (`v2/home/`)

**Job:** Introduce Livepeer. Route readers to the right tab.  
**Audience:** Everyone, first visit.

### Actual file structure
```
v2/home/
├── index.mdx                        2.1KB
├── mission-control.mdx              6.3KB  ✅ 9-card routing hub
├── primer.mdx                       10.6KB ✅ 10-min Livepeer overview
├── get-started.mdx                  7.5KB  ✅ persona routing cards
├── trending.mdx                     6.4KB  ⚠️ stale risk
├── about-livepeer/
│   ├── vision.mdx                   8.8KB  ✅
│   ├── evolution.mdx                7.9KB  ✅
│   ├── ecosystem.mdx                25.7KB ⚠️ Foundation launch June 2025 — update
│   ├── benefits.mdx                 9.9KB  ✅
│   └── roadmap.mdx                  1.8KB  🔴 STUB
├── get-started/                           🔴 ALL 4 STUBS IN NAV
│   ├── ai-pipelines.mdx             484B   🔴 "Coming Soon"
│   ├── build-on-livepeer.mdx        448B   🔴 "Coming Soon"
│   ├── stream-video.mdx             480B   🔴 "Coming Soon"
│   └── use-livepeer.mdx             427B   🔴 "Coming Soon"
├── solutions/
│   ├── applications.mdx             3.7KB  ⚠️ verify currency
│   ├── landscape.mdx                1.2KB  🔴 too thin
│   ├── showcase.mdx                 2.4KB  ⚠️
│   └── verticals.mdx                13KB   ✅
└── resources/
```

### Zero-to-hero journey coverage
| Stage | Required | Exists? |
|---|---|---|
| "What is Livepeer?" | primer.mdx | ✅ |
| "Where do I go?" | get-started.mdx + mission-control.mdx | ✅ |
| "What's the vision?" | about-livepeer/vision.mdx | ✅ |
| "What's been built?" | solutions/* | ⚠️ thin |
| "What's next?" | roadmap.mdx | 🔴 STUB |

### Actions required
1. **Remove from nav** — 4 × `get-started/*` stubs (Coming Soon = dead end)
2. **roadmap.mdx** — Write 2 paragraphs + link to `about/resources/reference/technical-roadmap.mdx`
3. **ecosystem.mdx** — Update for Foundation launch (June 2025)

---

## ABOUT (`v2/about/`)

**Job:** Complete conceptual and architectural reference. The evaluator's tab.  
**Audience:** Evaluators, researchers, anyone wanting depth beyond their role tab.

### Actual file structure
```
v2/about/
├── portal.mdx                       4.6KB  ✅
├── navigator.mdx                    4.6KB  ✅
├── index.mdx                        3.5KB
├── concepts/
│   ├── livepeer-overview.mdx        10.7KB ✅
│   ├── mental-model.mdx             21KB   ✅ GOLD — best page in About
│   └── core-concepts.mdx            9.7KB  ✅
├── network/
│   ├── overview.mdx                 6.8KB  ✅
│   ├── actors.mdx                   5KB    🔴 THIN — comprehensive version needed
│   ├── livepeer-actors/                    🔴 4 STUBS — remove from nav
│   │   ├── orchestrators.mdx        1.7KB  🔴
│   │   ├── gateways.mdx             1.5KB  🔴
│   │   ├── delegators.mdx           1.6KB  🔴
│   │   └── end-users.mdx            1.5KB  🔴
│   ├── job-lifecycle.mdx            10.4KB ✅
│   ├── marketplace.mdx              6.5KB  ✅
│   ├── technical-architecture.mdx   6.2KB  ✅
│   └── interfaces.mdx               5.9KB  ✅
├── protocol/
│   ├── overview.mdx                 14.5KB ✅
│   ├── core-mechanisms.mdx          25KB   ⚠️ incomplete sections
│   ├── livepeer-token.mdx           13.3KB ✅
│   ├── economics.mdx                10.4KB ✅
│   ├── governance-model.mdx         15.8KB ✅
│   ├── treasury.mdx                 16.7KB ✅
│   ├── blockchain-contracts.mdx     59KB   ✅ GOLD
│   ├── technical-architecture.mdx   9.9KB  ✅
│   └── design-philosophy.mdx        11.4KB ✅
└── resources/
    ├── faq.mdx                      2.9KB  🔴 THIN
    ├── glossary.mdx                 51KB   ✅
    ├── knowledge-hub/
    │   ├── contributor-orientation.mdx 1.5KB 🔴 STUB — remove from nav or write
    │   ├── evaluating-livepeer.mdx     1.5KB 🔴 STUB — write (P2 priority)
    │   ├── gateways-vs-orchestrators.mdx 2.7KB ⚠️ thin
    │   └── livepeer-whitepaper.mdx     4KB  ✅
    └── reference/
        ├── livepeer-contract-addresses.mdx ✅
        ├── network-metrics.mdx         1.6KB 🔴 THIN — real data needed
        └── technical-roadmap.mdx       8KB  ✅
```

### Evaluator journey coverage
| Question | Page | Status |
|---|---|---|
| What is Livepeer? | concepts/livepeer-overview.mdx | ✅ |
| How does it all fit together? | concepts/mental-model.mdx | ✅ GOLD |
| Who are all the participants? | network/actors.mdx | 🔴 5KB thin — needs rewrite |
| How does a job flow? | network/job-lifecycle.mdx | ✅ |
| How does the marketplace work? | network/marketplace.mdx | ✅ |
| How does the protocol work? | protocol/overview.mdx | ✅ |
| What is LPT? | protocol/livepeer-token.mdx | ✅ |
| How does governance work? | protocol/governance-model.mdx | ✅ |
| How does treasury/org work? | protocol/treasury.mdx | ✅ |
| What are the smart contracts? | protocol/blockchain-contracts.mdx | ✅ GOLD |
| **What products exist?** | — | 🔴 NO PAGE — missing entirely |
| **What's the current network state?** | network-metrics.mdx | 🔴 1.6KB fails |
| **Should I engage? How do I evaluate?** | evaluating-livepeer.mdx | 🔴 STUB |
| **How do I participate?** | contributor-orientation.mdx | 🔴 STUB |

### Required pages missing or failing
| Page | Path | Priority |
|---|---|---|
| All Actors (comprehensive) | `v2/about/network/actors.mdx` | P2 — rewrite, merge 4 sub-stubs |
| Ecosystem / Products | `v2/about/concepts/ecosystem-products.mdx` | P2 — NEW, does not exist |
| Evaluating Livepeer | `v2/about/resources/knowledge-hub/evaluating-livepeer.mdx` | P3 — write from stub |
| Core Mechanisms (complete) | `v2/about/protocol/core-mechanisms.mdx` | P3 — complete unfinished sections |

### Nav cleanup
Remove from nav: `network/livepeer-actors/*` (4 stubs) → merge into `actors.mdx`  
Remove from nav: `knowledge-hub/contributor-orientation.mdx` until written

---

## GPU NODES / ORCHESTRATORS (`v2/orchestrators/`)

**Job:** Complete zero-to-hero for GPU operators.  
**Audience:** 5 personas: Solo Miner (A), Pool Worker (B), Pro Operator (C), Enterprise (D), AI Native (E).

### Actual file structure
```
v2/orchestrators/
├── portal.mdx                       6.7KB  ✅ — needs earnings hook for Persona A
├── navigator.mdx                    12KB   ✅ — missing Pool Worker + AI Native paths
├── index.mdx                        8.1KB
│
├── concepts/
│   ├── role.mdx                     15KB   ✅
│   ├── architecture.mdx             19.5KB ✅
│   ├── incentive-model.mdx          18.6KB ✅
│   ├── capabilities.mdx             13.8KB ✅
│   └── composable/                  ← view components (not nav pages)
│   [MISSING] job-types.mdx          🔴 transcoding vs AI, VRAM per pipeline, realtime vs batch
│
├── quickstart/
│   ├── guide.mdx                    5.1KB  ⚠️ thin path selector
│   ├── tutorial.mdx                 1.4KB  🔴 STUB
│   ├── video-transcoding.mdx        5.3KB  ✅
│   ├── AI-prompt-start.mdx          10.2KB ✅ AI onboarding
│   └── dep-x-setup-paths.mdx        3.5KB  ← deprecated, not in nav
│   [MISSING] join-a-pool.mdx        🔴 Pool Worker (Persona B) blocked
│   [MISSING] setup-paths.mdx        🔴 decision matrix before choosing path
│   [MISSING] realtime-ai-quickstart.mdx 🔴 realtime AI path
│   [MISSING] batch-ai-quickstart.mdx    🔴 batch AI path
│
├── setup/
│   ├── guide.mdx                    3.3KB  ⚠️ thin overview
│   ├── s-guide.mdx                  1.9KB  🔴 unclear purpose
│   ├── prepare.mdx                  3.3KB  ⚠️ thin prerequisites
│   ├── install.mdx                  17KB   ✅ EXISTS — binary, Docker, source
│   ├── configure.mdx                15.6KB ✅ core flags
│   ├── connect.mdx                  13.1KB ✅ Arbitrum connection
│   ├── verify.mdx                   16.7KB ✅ end-to-end verification
│   └── monitor.mdx                  2.5KB  🔴 THIN — needs Grafana/Prometheus
│   [MISSING] publish-offerings.mdx  🔴 on-chain activation step — does not exist
│   [MISSING] data-centre-setup.mdx  🔴 enterprise/multi-node — does not exist
│
├── guides/
│   ├── operator-considerations/     ✅ section exists
│   ├── deployment-details/          ✅ section exists
│   ├── ai-and-job-workloads/
│   │   [ai-pipelines.mdx]           🔴 aiModels.json, containers, warm loading — THIN
│   │   [MISSING] hosting-models.mdx 🔴 BYOC custom models
│   ├── config-and-optimisation/
│   │   [MISSING] pricing-strategy.mdx 🔴 competitive pricing — Discord #1 pain point
│   ├── monitoring-and-tooling/      ⚠️ Grafana complexity unresolved
│   ├── staking-and-rewards/         ✅
│   ├── payments-and-pricing/        ✅
│   ├── advanced-operations/
│   │   [run-a-pool.mdx]             🔴 THIN — pool operator guide incomplete
│   │   [MISSING] remote-workers.mdx 🔴 BYOC remote workers
│   └── tutorials/
│       [MISSING] pool-worker.mdx    🔴 Persona B tutorial
│
└── resources/
    ├── glossary.mdx                 89.7KB ✅
    └── operator-terms.mdx           22KB   ✅
    [MISSING] faq.mdx                🔴 troubleshooting — CONFIRMED JOURNEY BLOCKER
    [MISSING] cli-flags.mdx          🔴 complete CLI reference
    [MISSING] community-pools.mdx    🔴 pool directory
    [MISSING] aimodels-schema.mdx    🔴 aiModels.json schema reference
```

### Per-persona journey coverage
| Persona | Critical path | Status |
|---|---|---|
| A: Solo Miner | install → configure → connect → verify | ✅ all 4 setup pages exist |
| B: Pool Worker | join-a-pool quickstart | 🔴 BLOCKED — page does not exist |
| C: Pro Operator | AI pipelines + run-a-pool | 🔴 ai-pipelines thin, run-a-pool thin |
| D: Enterprise | data-centre-setup | 🔴 BLOCKED — page does not exist |
| E: AI Native | job-types → realtime/batch quickstart | 🔴 BLOCKED — job-types missing |

### Discord-confirmed gaps in this tab
| Discord question | Required page | Status |
|---|---|---|
| "Orchestrator not available" error | faq.mdx with troubleshooting | 🔴 missing |
| "How do I join a pool?" | quickstart/join-a-pool.mdx | 🔴 missing |
| "What price per pixel should I set?" | guides/config-and-optimisation/pricing-strategy.mdx | 🔴 missing |
| "What is aiModels.json?" | resources/aimodels-schema.mdx | 🔴 missing |
| "Realtime vs batch AI — what's the difference?" | concepts/job-types.mdx | 🔴 missing |

---

## GATEWAYS (`v2/gateways/`)

**Job:** Complete zero-to-hero for gateway operators.  
**Audience:** Graduate developer (A), Provider (B), Protocol researcher (C).

### Actual file structure
```
v2/gateways/
├── portal.mdx                       5.6KB  ✅
├── navigator.mdx                    18.9KB ✅ — on-chain/off-chain pre-decision missing
├── index.mdx                        12KB
│
├── concepts/
│   ├── role.mdx                     16.7KB ✅
│   ├── architecture.mdx             15KB   ✅
│   ├── capabilities.mdx             11.3KB ✅
│   └── business-model.mdx           11KB   ✅
│   [MISSING] payment-modes.mdx      🔴 on-chain vs off-chain decision — first gateway blocker
│
├── quickstart/
│   └── [composable views: Docker/Linux/Windows × on-chain/off-chain]  ✅ structure good
│
├── setup/
│   ├── guide.mdx                    14.7KB ✅ setup overview
│   ├── prepare.mdx                  14.1KB ✅ GOLD STANDARD
│   ├── install.mdx                  2.8KB  ⚠️ thin shell → sub-views
│   ├── configure.mdx                2.2KB  ⚠️ thin shell → sub-views
│   ├── configure/                   ← composable views: AI / video / pricing
│   │   [MISSING] dual.mdx           🔴 dual AI+video config — does not exist
│   ├── connect.mdx                  4.9KB  ✅
│   ├── connect/                     ← composable views
│   ├── verify.mdx                   2.4KB  ⚠️ thin shell
│   ├── verify/                      ← composable views
│   ├── monitor.mdx                  17.5KB ✅
│   ├── monitor/                     ← composable views
│   ├── prepare/, publish/, requirements/, transcoding/  ← composable views
│   [MISSING] remote-signers.mdx     🔴 post Q4 2025 PRs #3791/#3822
│
├── guides/
│   ├── operator-considerations/     ✅
│   ├── deployment-details/          ✅
│   ├── monitoring-and-tooling/      ✅
│   ├── node-pipelines/              ⚠️ dual AI+video config missing
│   ├── payments-and-pricing/
│   │   ├── [payment-guide.mdx]      ✅
│   │   [MISSING] remote-signers.mdx 🔴 remote signer setup
│   │   [MISSING] clearinghouse.mdx  🔴 architecture completely undocumented
│   ├── roadmap-and-funding/         ✅
│   ├── advanced-operations/
│   │   ├── [scaling.mdx]            ✅
│   │   ├── [orchestrator-selection.mdx] ✅
│   │   [MISSING] orchestrator-discovery-offchain.mdx 🔴 off-chain gateway gets no jobs
│   └── tutorials/
│       └── [go-production.mdx]      ⚠️ incomplete
│
├── custom/                          ← custom gateway configs
└── resources/                       ✅ API reference strong (AI-API, CLI-HTTP, AI-Worker)
```

### Per-persona journey coverage
| Persona | Critical question | Status |
|---|---|---|
| A: Graduate | "On-chain or off-chain?" | 🔴 payment-modes.mdx missing |
| A: Graduate | "Do I need a remote signer?" | 🔴 remote-signers.mdx missing |
| A: Graduate | "How does off-chain find orchestrators?" | 🔴 discovery page missing |
| B: Provider | "How does the clearinghouse work?" | 🔴 clearinghouse.mdx missing |
| C: All | "Can I run AI + video on the same node?" | 🔴 dual config missing |

### Discord-confirmed gaps in this tab
| Discord question | Required page | Status |
|---|---|---|
| "On-chain vs off-chain gateway?" | concepts/payment-modes.mdx | 🔴 missing |
| "Do I need a remote signer?" | setup/remote-signers.mdx | 🔴 missing |
| "How does the clearinghouse work?" | guides/payments-and-pricing/clearinghouse.mdx | 🔴 missing |
| "How does off-chain discover orchestrators?" | guides/advanced-operations/orchestrator-discovery-offchain.mdx | 🔴 missing |

---

## DEVELOPERS (`v2/developers/`)

**Job:** Build on Livepeer — AI pipelines, video APIs, SDKs.  
**Audience:** AI app developer, video app developer, OSS contributor.

### Actual file structure
```
v2/developers/
├── portal.mdx                       5.3KB  ✅
├── navigator.mdx                    8.4KB  ✅
├── index.mdx                        4.4KB
│
├── concepts/
│   ├── ai-on-livepeer.mdx           🔴 REWRITE — pre-NaaP/clearinghouse model
│   ├── developer-stack.mdx          ✅
│   ├── oss-stack.mdx                ✅
│   ├── running-a-gateway.mdx        ✅
│   └── video.mdx                    ✅
│
├── get-started/
│   ├── setup-paths.mdx              ⚠️ thin — "which quickstart?" decision tree missing
│   ├── ai-quickstart.mdx            ✅
│   ├── transcoding-quickstart.mdx   ✅
│   ├── comfystream.mdx              ✅
│   ├── contributor.mdx              ✅
│   └── video.mdx                    ✅
│
├── build/
│   ├── byoc.mdx                     ✅
│   ├── comfystream.mdx              ✅
│   ├── model-support.mdx            ✅
│   ├── sdk-gateway.mdx              ✅
│   └── workload-fit.mdx             ⚠️ thin
│
├── guides/
│   ├── ai/
│   │   ├── authentication.mdx       ⚠️ THIN — auth flows incomplete
│   │   ├── production-checklist.mdx ⚠️ INCOMPLETE
│   │   └── troubleshooting.mdx      ✅
│   ├── video/                       ✅ comprehensive
│   ├── tutorials/                   ✅
│   └── opportunities/               ✅ grants, bounties
│
└── resources/                       ✅ APIs, SDKs, examples
```

### Developer journey coverage
| Question | Page | Status |
|---|---|---|
| "Can Livepeer do AI inference?" | concepts/ai-on-livepeer.mdx | 🔴 outdated — rewrite |
| "Which quickstart should I use?" | get-started/setup-paths.mdx | 🔴 thin |
| "How do I make my first AI call?" | get-started/ai-quickstart.mdx | ✅ |
| "How do I authenticate?" | guides/ai/authentication.mdx | 🔴 thin |
| "Am I production-ready?" | guides/ai/production-checklist.mdx | 🔴 incomplete |
| "How do I build a video app?" | guides/video/ | ✅ |

---

## LP TOKEN / DELEGATORS (`v2/delegators/`)

**Job:** Stake LPT, earn rewards, participate in governance.  
**Audience:** LPT holders at all crypto literacy levels.

### Actual file structure
```
v2/delegators/
├── portal.mdx                       2.8KB  ⚠️ thin
├── index.mdx                        2.7KB
│
├── concepts/
│   ├── overview.mdx                 ✅
│   ├── mechanics.mdx                ✅
│   ├── purpose.mdx                  ✅
│   └── tokenomics.mdx               ⚠️ verify post-AI subnet numbers
│
├── delegation/
│   ├── overview.mdx                 ✅
│   ├── bridge-lpt-to-arbitrum.mdx   ✅ tabbed CEX/DEX/Bridge/Wallet layout
│   ├── choose-orchestrator.mdx      ✅
│   ├── delegate.mdx                 ✅
│   ├── delegation-economics.mdx     ✅
│   ├── manage.mdx                   ✅
│   └── about.mdx                    ✅
│
├── guides/
│   ├── governance/
│   │   ├── overview.mdx             ✅
│   │   ├── model.mdx                ✅
│   │   └── processes.mdx            ⚠️ GovWorks Feb 2025 update — verify
│   └── treasury/
│       ├── overview.mdx             ✅
│       ├── allocations.mdx          ✅
│       └── proposals.mdx            ⚠️ current process — verify
│
└── resources/
    ├── glossary.mdx                 ✅
    ├── exchanges.mdx                ✅
    ├── lpt-eth-usage.mdx            ✅
    ├── videos-and-blogs.mdx         ✅
    └── reference/                   ← contract addresses, protocol parameters
```

### Delegator journey coverage — CLOSEST TAB TO SHIP-READY
| Stage | Status |
|---|---|
| Bridge LPT to Arbitrum | ✅ comprehensive |
| Choose + delegate | ✅ |
| Manage position | ✅ |
| Governance voting | ⚠️ verify GovWorks Feb 2025 |
| Treasury proposal | ⚠️ verify current process |

**Actions required:** 3 currency verifications. No missing pages.

---

## COMMUNITY (`v2/community/`)

**Job:** Activate participation. Connect participants. Route into contribution.  
**Audience:** Multi-persona — newcomer, delegator, contributor, operator, observer.

### Actual file structure
```
v2/community/
├── community-portal.mdx             6.9KB  ⚠️ Foundation info needs update
├── faq.mdx                          7.7KB  ⚠️ Foundation info needs update
├── index.mdx                        2.2KB
├── livepeer-community/
│   ├── guidelines.mdx               ✅
│   ├── governance-and-foundation.mdx ⚠️ Foundation June 2025 — update
│   ├── trending-topics.mdx          ⚠️ stale risk
│   └── roadmap.mdx                  🔴 STUB
├── livepeer-connect/
│   ├── events.mdx                   ⚠️ schedule currency
│   ├── forums.mdx                   ✅
│   └── news-and-socials.mdx         ⚠️ publishing map needed
├── livepeer-contribute/
│   ├── build.mdx                    ✅
│   ├── contribute.mdx               ✅
│   └── opportunities.mdx            ⚠️ volatile — route to live source
└── resources/
    ├── awesome-livepeer.mdx         ✅
    ├── dashboards.mdx               ✅
    ├── glossary.mdx                 ✅
    └── guides.mdx                   ✅
```

### Required final IA (canonical — from community-tab-05-final-ia-and-pages.md)
```
community/
├── community-portal.mdx             ← Landing
├── faq.mdx                          ← FAQ
├── livepeer-community/
│   ├── who-is-here.mdx              ← Concept: four roles
│   └── guidelines.mdx               ← Reference: conduct
├── shape-the-network/               ← [restructure from livepeer-community partial]
│   ├── governance-participation.mdx ← Concept: how to participate
│   └── workstreams.mdx              ← Reference: route to live Forum
├── get-involved/                    ← [rename from livepeer-contribute]
│   ├── ways-to-contribute.mdx       ← Landing: contribution taxonomy
│   └── opportunities.mdx            ← Reference: route to live source
├── connect/                         ← [rename from livepeer-connect]
│   ├── channels.mdx                 ← Reference: full platform map table
│   ├── events-and-calls.mdx         ← Reference: schedule + calendar link
│   └── news-and-updates.mdx         ← Reference: publishing surfaces
└── ecosystem/
    ├── community-tools.mdx          ← Reference: cross-role tools
    └── community-guides.mdx         ← Reference: guides by role
```

### Actions required
1. Update all Foundation references (June 2025 launch)
2. workstreams.mdx — route to live Forum, don't duplicate state
3. Implement final IA (renames + restructure per canonical plan)

---

## SOLUTIONS (`v2/solutions/`)

**Job:** Product documentation per platform built on Livepeer.  
**Audience:** Users and developers of specific products.

### Actual file structure
```
v2/solutions/
├── daydream/           3 pages  ⚠️ overview only, thin
├── embody/             3 pages  ⚠️ overview only, thin
├── frameworks/         3 pages  ⚠️ overview only, thin
├── streamplace/        8 pages  ✅ comprehensive
└── livepeer-studio/    88 pages ✅ comprehensive
```

### Actions required
1. Bridge from About: create `v2/about/concepts/ecosystem-products.mdx` linking here
2. daydream/embody/frameworks: expand to overview + quickstart + changelog minimum

---

## RESOURCES (`v2/resources/`)

**Job:** Cross-cutting reference and changelogs.  
**Audience:** All — lookup destination.

```
v2/resources/
├── changelog/          20 pages ✅ keep current
├── documentation-guide/ 15 pages ✅
├── glossary.mdx        ✅
└── help-center.mdx     ✅
```

**Status: ✅ Publishable as-is.** Keep changelogs current.

---

## MASTER GAP REGISTER — PRIORITY ORDER

### 🔴 P1 — Journey-blocking (zero-to-hero impossible without these)

| # | File path | Tab | What's needed |
|---|---|---|---|
| 1 | `v2/orchestrators/concepts/job-types.mdx` | GPU Nodes | NEW — transcoding vs AI types, VRAM/pipeline, realtime vs batch |
| 2 | `v2/orchestrators/quickstart/join-a-pool.mdx` | GPU Nodes | NEW — Pool Worker Persona B path |
| 3 | `v2/orchestrators/quickstart/setup-paths.mdx` | GPU Nodes | NEW — decision matrix: solo/pool/AI/enterprise |
| 4 | `v2/orchestrators/resources/faq.mdx` | GPU Nodes | NEW — troubleshooting (confirmed journey blocker) |
| 5 | `v2/orchestrators/setup/publish-offerings.mdx` | GPU Nodes | NEW — on-chain activation step |
| 6 | `v2/gateways/concepts/payment-modes.mdx` | Gateways | NEW — on-chain vs off-chain decision |
| 7 | `v2/gateways/setup/remote-signers.mdx` | Gateways | NEW — post Q4 2025 PRs #3791/#3822 |
| 8 | `v2/gateways/guides/payments-and-pricing/clearinghouse.mdx` | Gateways | NEW — architecture undocumented |
| 9 | `v2/gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx` | Gateways | NEW — off-chain gateway gets no jobs |
| 10 | `v2/developers/concepts/ai-on-livepeer.mdx` | Developers | REWRITE — pre-NaaP/clearinghouse |

### 🟡 P2 — Tab degrades without these

| # | File path | Tab | What's needed |
|---|---|---|---|
| 11 | `v2/about/network/actors.mdx` | About | REWRITE — merge 4 sub-stubs, ~15KB comprehensive |
| 12 | `v2/about/concepts/ecosystem-products.mdx` | About | NEW — "what's been built on Livepeer?" |
| 13 | `v2/orchestrators/setup/monitor.mdx` | GPU Nodes | EXPAND — 2.5KB → full Grafana/Prometheus |
| 14 | `v2/orchestrators/setup/data-centre-setup.mdx` | GPU Nodes | NEW — enterprise multi-node |
| 15 | `v2/orchestrators/guides/ai-and-job-workloads/ai-pipelines.mdx` | GPU Nodes | EXPAND — aiModels.json, containers, warm loading |
| 16 | `v2/orchestrators/guides/config-and-optimisation/pricing-strategy.mdx` | GPU Nodes | NEW — competitive pricing guidance |
| 17 | `v2/orchestrators/guides/advanced-operations/run-a-pool.mdx` | GPU Nodes | EXPAND — pool operator guide |
| 18 | `v2/gateways/setup/configure/dual.mdx` | Gateways | NEW — dual AI+video config |
| 19 | `v2/developers/get-started/setup-paths.mdx` | Developers | EXPAND — "which quickstart?" decision tree |
| 20 | `v2/developers/guides/ai/authentication.mdx` | Developers | EXPAND — auth flows |
| 21 | `v2/developers/guides/ai/production-checklist.mdx` | Developers | COMPLETE — pre-launch requirements |
| 22 | `v2/delegators/guides/governance/processes.mdx` | LP Token | VERIFY — GovWorks Feb 2025 |

### 🟢 P3 — Quality / completeness

| # | File path | Tab | What's needed |
|---|---|---|---|
| 23 | `v2/about/protocol/core-mechanisms.mdx` | About | COMPLETE — unfinished sections |
| 24 | `v2/about/resources/knowledge-hub/evaluating-livepeer.mdx` | About | WRITE from stub |
| 25 | `v2/home/about-livepeer/roadmap.mdx` | Home | WRITE or redirect |
| 26 | `v2/orchestrators/resources/cli-flags.mdx` | GPU Nodes | NEW — complete CLI reference |
| 27 | `v2/orchestrators/resources/community-pools.mdx` | GPU Nodes | NEW — pool directory |
| 28 | `v2/delegators/concepts/tokenomics.mdx` | LP Token | VERIFY — post-AI subnet numbers |
| 29 | Community Foundation updates | Community | UPDATE all references June 2025 |

### Remove from nav immediately
```
v2/home/get-started/ai-pipelines.mdx           Coming Soon stub
v2/home/get-started/build-on-livepeer.mdx      Coming Soon stub
v2/home/get-started/stream-video.mdx           Coming Soon stub
v2/home/get-started/use-livepeer.mdx           Coming Soon stub
v2/about/network/livepeer-actors/orchestrators.mdx   sub-stub
v2/about/network/livepeer-actors/gateways.mdx        sub-stub
v2/about/network/livepeer-actors/delegators.mdx      sub-stub
v2/about/network/livepeer-actors/end-users.mdx       sub-stub
v2/about/resources/knowledge-hub/contributor-orientation.mdx  stub
```

---

## COMPLETION SCORECARD

| Tab | P1 gaps | Est. complete | Ship-ready? |
|---|---|---|---|
| Home | 1 (nav stubs + roadmap) | 75% | 🔴 stubs visible in nav |
| About | 0 P1 / 2 P2 critical | 60% | 🔴 actors + ecosystem missing |
| GPU Nodes | 5 | 65% | 🔴 pool/AI/FAQ/publish/setup-paths |
| Gateways | 4 | 70% | 🔴 payment-modes/remote-signer/clearinghouse/discovery |
| Developers | 1 | 72% | 🔴 ai-on-livepeer rewrite |
| LP Token | 0 | 85% | 🟡 3 verifications |
| Community | 0 | 75% | 🟡 Foundation updates + IA renames |
| Solutions | 0 | 85% | 🟡 daydream/embody thin |
| Resources | 0 | 90% | ✅ publishable |
