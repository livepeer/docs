# Livepeer Docs v2 — Complete IA Per Tab
> Source: docs-v2-dev branch, `livepeer/docs`, read 2026-04-07
> Framework: first-principles human outcomes × actual repo structure
> Convention: ✅ exists | 🔴 MISSING | 🟡 EXISTS BUT NEEDS WORK | ~~strikethrough~~ = x-deprecated/not in nav

---

## STRUCTURAL PATTERN (all tabs)

Every tab follows this 6-position pattern from the governance framework:

```
Pos 1 — Hub:       portal.mdx + navigator.mdx (index.mdx = section index)
Pos 2 — Concepts:  concepts/ — what it is, how it works, why it matters
Pos 3 — Quickstart: quickstart/ — fastest path to first success
Pos 4 — Setup:     setup/ — full install → configure → connect → verify
Pos 5 — Guides:    guides/ — deep operational depth, advanced patterns
Pos 6 — Resources: resources/ — reference, FAQ, CLI, glossary
```

Navigator convention: `navigator.mdx` = the "choose your path" persona selector page
Portal convention: `portal.mdx` = the hub landing card page

---

## TAB 1: HOME

**Root:** `v2/home/`
**Job:** What is Livepeer? Where do I go?
**Primary human:** Everyone on first visit — evaluator, operator, builder, holder

### Required IA vs Actual

```
HOME
├── portal / index         → v2/home/index.mdx (or v2/index.mdx at root?)
├── about-livepeer/
│   ├── vision.mdx         ✅
│   ├── evolution.mdx      ✅
│   ├── ecosystem.mdx      ✅ (25.7KB — needs Foundation June 2025 update)
│   ├── benefits.mdx       ✅
│   └── roadmap.mdx        🟡 STUB — 1.8KB, needs content or redirect
├── primer.mdx             ✅ 10.6KB — the "what is Livepeer in 10 minutes" page
├── get-started.mdx        ✅ persona routing cards
├── get-started/
│   ├── ai-pipelines.mdx   🔴 Coming Soon stub — REMOVE FROM NAV
│   ├── build-on-livepeer.mdx 🔴 Coming Soon stub — REMOVE FROM NAV
│   ├── stream-video.mdx   🔴 Coming Soon stub — REMOVE FROM NAV
│   └── use-livepeer.mdx   🔴 Coming Soon stub — REMOVE FROM NAV
├── mission-control.mdx    ✅ 9-card routing hub
├── trending.mdx           🟡 6.4KB — stale risk, needs review mechanism
└── solutions/
    ├── applications.mdx   🟡 3.7KB — verify against live products
    ├── landscape.mdx      🔴 1.2KB — too thin
    ├── showcase.mdx       🟡 2.4KB
    └── verticals.mdx      ✅ 13KB
```

### Home success criteria
| Human need | Covered? |
|---|---|
| "What is Livepeer in 5 minutes?" | ✅ primer.mdx |
| "Where do I go for my role?" | ✅ get-started.mdx, mission-control.mdx |
| "What's been built?" | 🟡 solutions/* thin |
| "What's the vision/roadmap?" | 🔴 roadmap.mdx stub |
| Zero nav stubs | 🔴 4 stubs in nav |

### Actions required
1. Remove 4 get-started/* stubs from docs.json nav
2. roadmap.mdx: write or redirect to about/resources/reference/technical-roadmap.mdx
3. solutions/landscape.mdx: expand or merge into showcase.mdx
4. ecosystem.mdx: verify Foundation June 2025 launch is reflected

---

## TAB 2: ABOUT

**Root:** `v2/about/`
**Job:** Complete conceptual + architectural reference. How the whole thing works.
**Primary human:** Evaluator (investor, researcher, enterprise). Also: anyone wanting depth beyond their role tab.

### Actual structure (docs-v2-dev)

```
v2/about/
├── portal.mdx             ✅ 4.6KB
├── navigator.mdx          ✅ 4.6KB
├── index.mdx              ✅ 3.5KB
├── concepts/
│   ├── livepeer-overview.mdx  ✅ 10.7KB
│   ├── mental-model.mdx       ✅ 21KB — GOLD STANDARD
│   └── core-concepts.mdx      ✅ 9.7KB
├── network/
│   ├── overview.mdx           ✅ 6.8KB
│   ├── actors.mdx             🟡 5KB — THIN, needs comprehensive rewrite
│   ├── livepeer-actors/       🔴 4 sub-stubs — merge into actors.mdx, remove from nav
│   │   ├── orchestrators.mdx  🔴 1.7KB stub
│   │   ├── gateways.mdx       🔴 1.5KB stub
│   │   ├── delegators.mdx     🔴 1.6KB stub
│   │   └── end-users.mdx      🔴 1.5KB stub
│   ├── job-lifecycle.mdx      ✅ 10.4KB
│   ├── marketplace.mdx        ✅ 6.5KB
│   ├── technical-architecture.mdx ✅ 6.2KB
│   └── interfaces.mdx         ✅ 5.9KB
├── protocol/
│   ├── overview.mdx           ✅ 14.5KB
│   ├── core-mechanisms.mdx    🟡 25KB — marked unfinished
│   ├── livepeer-token.mdx     ✅ 13.3KB
│   ├── economics.mdx          ✅ 10.4KB
│   ├── governance-model.mdx   ✅ 15.8KB
│   ├── treasury.mdx           ✅ 16.7KB
│   ├── blockchain-contracts.mdx ✅ 59KB — GOLD
│   ├── technical-architecture.mdx ✅ 9.9KB
│   └── design-philosophy.mdx  ✅ 11.4KB
└── resources/
    ├── faq.mdx                🔴 2.9KB — THIN
    ├── glossary.mdx           ✅ 51KB
    ├── knowledge-hub/
    │   ├── contributor-orientation.mdx 🔴 1.5KB stub — REMOVE FROM NAV
    │   ├── evaluating-livepeer.mdx     🔴 1.5KB stub — WRITE (evaluator path)
    │   ├── gateways-vs-orchestrators.mdx 🟡 2.7KB thin
    │   └── livepeer-whitepaper.mdx     ✅ 4KB
    └── reference/
        ├── livepeer-contract-addresses.mdx ✅ 2.1KB
        ├── network-metrics.mdx             🔴 1.6KB — THIN
        └── technical-roadmap.mdx           ✅ 8KB — verify currency
```

### MISSING pages (not in repo, required by first-principles)
| Page | Path | Why needed |
|---|---|---|
| Ecosystem / Products bridge | `about/resources/ecosystem-and-products.mdx` | No page answers "what has been built on Livepeer?" — evaluator journey breaks here |
| Participation paths | `about/resources/knowledge-hub/participation-paths.mdx` | How to get involved (cross-role) |
| Current network state | `about/network/network-metrics.mdx` expanded | 1.6KB is not enough |

### About success criteria
| Evaluator need | Covered? |
|---|---|
| Complete mental model | ✅ mental-model.mdx (21KB, gold) |
| All actors comprehensive | 🔴 actors.mdx thin + 4 sub-stubs |
| Protocol mechanics | ✅ protocol/* |
| What's been built | 🔴 NOTHING |
| How to evaluate/engage | 🔴 evaluating-livepeer.mdx stub |
| Governance how it works | ✅ governance-model.mdx |
| Treasury / org structure | ✅ treasury.mdx |
| Smart contracts | ✅ blockchain-contracts.mdx |

---

## TAB 3: GPU NODES (Orchestrators)

**Root:** `v2/orchestrators/`
**Job:** Run a GPU node. Zero to first job. Zero to optimised earnings.
**Primary humans:** Solo GPU operator (A), Pool worker (B), Pro engineer (C), Enterprise (D), AI native (E)

### Actual structure (docs-v2-dev)

```
v2/orchestrators/
├── portal.mdx             ✅ 6.7KB — hub landing
├── navigator.mdx          ✅ 11.9KB — persona path selector
├── index.mdx              ✅ 8.1KB — section index
├── concepts/
│   ├── role.mdx           ✅ 15KB
│   ├── architecture.mdx   ✅ 19.5KB
│   ├── capabilities.mdx   ✅ 13.8KB
│   ├── incentive-model.mdx ✅ 18.6KB
│   └── composable/        (view files — not standalone pages)
├── quickstart/
│   ├── guide.mdx          ✅ 5.1KB — quickstart overview
│   ├── video-transcoding.mdx ✅ 5.3KB
│   ├── AI-prompt-start.mdx   ✅ 10.2KB — add AI to existing node
│   ├── tutorial.mdx       🟡 1.4KB — THIN
│   └── dep-x-setup-paths.mdx 🔴 3.5KB — deprecated, prefixed dep-x
├── setup/
│   ├── guide.mdx          ✅ 3.3KB — setup overview
│   ├── s-guide.mdx        🟡 1.9KB — duplicate/stub?
│   ├── prepare.mdx        ✅ 3.3KB
│   ├── install.mdx        ✅ 17KB — GOOD
│   ├── configure.mdx      ✅ 15.6KB
│   ├── connect.mdx        ✅ 13.1KB
│   ├── verify.mdx         ✅ 16.7KB
│   └── monitor.mdx        🟡 2.5KB — THIN
├── guides/
│   ├── operator-considerations/  ✅ (multiple pages)
│   ├── deployment-details/       ✅ (multiple pages)
│   ├── ai-and-job-workloads/     🟡 (pages exist, AI types outdated)
│   ├── config-and-optimisation/  🟡 (pricing guidance thin)
│   ├── monitoring-and-tooling/   ✅
│   ├── payments-and-pricing/     ✅
│   ├── staking-and-rewards/      ✅ (good from recent work)
│   ├── roadmap-and-funding/      ✅
│   ├── advanced-operations/      🟡 (pool guide thin)
│   └── tutorials/                🟡
└── resources/
    ├── faq.mdx            🔴 CONFIRMED JOURNEY BLOCKER — no troubleshooting
    ├── cli-flags.mdx      ✅ (or check if exists)
    └── community-pools.mdx 🟡
```

### MISSING pages (required by first-principles, not in repo)
| Page | Path | Persona blocked | Why |
|---|---|---|---|
| Join a pool | `quickstart/join-a-pool.mdx` | B (Pool Worker) | dep-x-setup-paths deprecated; pool worker has NO path |
| Job types (rewrite) | `concepts/job-types.mdx` | C, E | AI pipeline types current — realtime vs batch, VRAM per pipeline |
| Competitive pricing guide | `guides/config-and-optimisation/pricing-strategy.mdx` | A, C | Discord top question — no guidance exists |
| Run a pool (complete) | `guides/advanced-operations/run-a-pool.mdx` | C, D | Currently thin |
| Enterprise / data centre | `setup/enterprise.mdx` | D | Stub or missing |

### GPU Nodes success criteria
| Human need | Covered? |
|---|---|
| "Is this worth it for my GPU?" | ✅ concepts/incentive-model.mdx |
| "Solo vs pool vs AI-only — which path?" | 🔴 dep-x-setup-paths deprecated, no replacement |
| "How do I install go-livepeer?" | ✅ setup/install.mdx (17KB) |
| "How do I configure?" | ✅ setup/configure.mdx |
| "How do I connect to Arbitrum?" | ✅ setup/connect.mdx |
| "Why am I not getting jobs?" | 🔴 faq.mdx — no troubleshooting content |
| "How do I join a pool as a worker?" | 🔴 MISSING |
| "What AI pipelines can I run?" | 🟡 outdated in current job-types |
| "How do I set competitive pricing?" | 🔴 MISSING |
| "How do I run a pool?" | 🟡 thin |

---

## TAB 4: GATEWAYS

**Root:** `v2/gateways/`
**Job:** Run gateway infrastructure. Route jobs. Settle payments.
**Primary humans:** Graduate developer (A), Provider (B), Protocol researcher (C)

### Actual structure (docs-v2-dev)

```
v2/gateways/
├── portal.mdx             ✅ 5.6KB
├── navigator.mdx          ✅ 18.9KB — COMPREHENSIVE
├── index.mdx              ✅ 12KB
├── concepts/
│   ├── role.mdx           ✅ 16.7KB
│   ├── architecture.mdx   ✅ 15KB
│   ├── capabilities.mdx   ✅ 11.3KB
│   └── business-model.mdx ✅ 11KB
├── quickstart/
│   (directory exists — content TBC)
├── setup/
│   ├── guide.mdx          ✅ 14.7KB
│   ├── prepare.mdx        ✅ 14.1KB + prepare/ (composable views)
│   ├── install.mdx        🟡 2.8KB — THIN (install page for 2.8KB is insufficient)
│   ├── configure.mdx      ✅ + configure/ (composable views)
│   ├── connect.mdx        ✅ 4.9KB + connect/ (composable views)
│   ├── monitor.mdx        ✅ 17.5KB + monitor/ (composable views)
│   ├── verify.mdx         ✅ 2.4KB + verify/ (composable views)
│   ├── publish/           (composable views)
│   ├── requirements/      (composable views)
│   └── transcoding/       (composable views)
├── guides/
│   ├── operator-considerations/  ✅
│   ├── deployment-details/       ✅
│   ├── monitoring-and-tooling/   ✅
│   ├── node-pipelines/           🟡 (dual AI+video gaps)
│   ├── payments-and-pricing/     🔴 CRITICAL GAPS (clearinghouse missing)
│   ├── roadmap-and-funding/      ✅
│   ├── advanced-operations/      🔴 (off-chain discovery missing)
│   └── tutorials/                🟡
├── custom/                (custom gateway directory)
└── resources/
    (check contents)
```

### MISSING pages (required by first-principles, not in repo)
| Page | Path | Persona blocked | Why |
|---|---|---|---|
| Payment modes (on-chain vs off-chain) | `concepts/payment-modes.mdx` | A, B, C | First architecture decision — completely undocumented |
| Remote signers | `setup/remote-signers.mdx` | A, B | Q4 2025 PRs #3791/#3822 — not in docs |
| Clearinghouse architecture | `guides/payments-and-pricing/clearinghouse.mdx` | B | Discord: "completely undocumented" |
| Off-chain orchestrator discovery | `guides/advanced-operations/orchestrator-discovery-offchain.mdx` | A | j0sh Discord: "I'll publish docs soon" — not done |
| Dual AI + video config | `guides/node-pipelines/dual-ai-video.mdx` | A, B | Common question, no guide |

### Gateways success criteria
| Human need | Covered? |
|---|---|
| "What does a gateway do?" | ✅ concepts/role.mdx |
| "On-chain vs off-chain — which do I need?" | 🔴 MISSING |
| "Do I need a remote signer?" | 🔴 MISSING |
| "How does the clearinghouse work?" | 🔴 MISSING |
| "How does off-chain gateway find orchestrators?" | 🔴 MISSING |
| "How do I install?" | 🟡 install.mdx only 2.8KB |
| "How do I configure for AI?" | ✅ configure/ composables |
| "How do I monitor?" | ✅ monitor.mdx 17.5KB |

---

## TAB 5: DEVELOPERS

**Root:** `v2/developers/`
**Job:** Build on Livepeer. APIs, SDKs, AI pipelines, video.
**Primary humans:** AI app developer, video app developer, OSS contributor

### Actual structure (docs-v2-dev)

```
v2/developers/
├── portal.mdx             ✅ 5.3KB
├── navigator.mdx          ✅ 8.4KB
├── index.mdx              ✅ 4.4KB
├── concepts/
│   ├── ai-on-livepeer.mdx       🟡 8.7KB — needs rewrite (pre-NaaP/clearinghouse)
│   ├── developer-stack.mdx      ✅ 10.6KB
│   ├── oss-stack.mdx            ✅ 8.1KB
│   ├── running-a-gateway.mdx    ✅ 5.7KB
│   └── video-on-livepeer.mdx    ✅ 8.2KB
├── get-started/
│   (directory — content TBC, check files)
├── build/
│   (directory — content TBC)
├── guides/
│   (directory with subdirs)
└── resources/
    (directory)
```

### MISSING / needs work (required by first-principles)
| Page | Path | Human blocked | Why |
|---|---|---|---|
| AI on Livepeer (rewrite) | `concepts/ai-on-livepeer.mdx` | AI developer | Pre-NaaP/clearinghouse model — inaccurate for 2026 |
| Setup paths decision tree | `get-started/setup-paths.mdx` | All | "Which quickstart?" pre-decision — currently missing |
| Auth guide | `guides/ai/authentication.mdx` | AI developer | Production integration requires auth |
| Production checklist | `guides/ai/production-checklist.mdx` | All | Pre-launch requirements incomplete |
| Workload fit | `build/workload-fit.mdx` | All | AI vs video vs hybrid decision |

### Developers success criteria
| Human need | Covered? |
|---|---|
| "Can Livepeer do what I need?" | 🟡 concepts/* good except ai-on-livepeer outdated |
| "Hosted API vs self-hosted?" | 🔴 not clearly answered |
| "Which SDK?" | 🟡 developer-stack.mdx covers this |
| "AI quickstart" | 🟡 check get-started/ |
| "Video quickstart" | 🟡 check get-started/ |
| "Production checklist" | 🔴 incomplete |
| "How do I authenticate?" | 🔴 thin |

---

## TAB 6: LP TOKEN (Delegators)

**Root:** `v2/delegators/`
**Job:** Stake LPT. Earn. Vote.
**Primary humans:** LPT holder (all technical levels), governance participant

### Actual structure (docs-v2-dev)

```
v2/delegators/
├── portal.mdx             ✅ 2.8KB (THIN for a portal)
├── index.mdx              ✅ 2.7KB
├── concepts/
│   ├── overview.mdx       ✅ 5.3KB
│   ├── mechanics.mdx      ✅ 5.7KB
│   ├── purpose.mdx        ✅ 9.2KB
│   └── tokenomics.mdx     ✅ 5.8KB
├── delegation/
│   ├── overview.mdx              ✅ 4.8KB
│   ├── about-delegation.mdx      ✅ 4.6KB
│   ├── bridge-lpt-to-arbitrum.mdx ✅ 5.8KB
│   ├── choose-an-orchestrator.mdx ✅ 6KB
│   ├── delegate-your-lpt.mdx     ✅ 4.5KB
│   ├── delegation-economics.mdx  ✅ 5.9KB
│   └── manage-your-delegation.mdx ✅ 5.3KB
├── guides/
│   ├── governance/        🟡 (verify GovWorks Feb 2025 update)
│   └── treasury/          🟡 (verify current proposal process)
└── resources/
    (check contents)
```

### LP Token success criteria
| Human need | Covered? |
|---|---|
| "What is LPT?" | ✅ concepts/purpose.mdx |
| "How do I bridge to Arbitrum?" | ✅ bridge-lpt-to-arbitrum.mdx |
| "How do I choose an orchestrator?" | ✅ choose-an-orchestrator.mdx |
| "How do I delegate?" | ✅ delegate-your-lpt.mdx |
| "How much will I earn?" | ✅ delegation-economics.mdx |
| "How do I vote?" | 🟡 governance/* — verify GovWorks currency |
| "How do I submit a proposal?" | 🟡 treasury/* — verify current process |
| portal.mdx adequate for entry? | 🟡 2.8KB is thin for a tab portal |

**Status: Strongest tab. Primary actions: verify governance/treasury currency, beef up portal.**

---

## TAB 7: COMMUNITY

**Root:** `v2/community/`
**Job:** Orient, activate, connect.
**Primary humans:** Newcomer, delegator, governance participant, contributor, orchestrator, observer

### Actual structure (docs-v2-dev)

```
v2/community/
├── community-portal.mdx   ✅ 6.9KB
├── faq.mdx                ✅ 7.7KB
├── index.mdx              🟡 2.2KB
├── livepeer-community/
│   (subdirectory — check files)
├── livepeer-connect/
│   (subdirectory — check files)
├── livepeer-contribute/
│   (subdirectory — check files)
└── resources/
    (subdirectory — check files)
```

### Required IA (from community-tab-05-final-ia-and-pages.md — CANONICAL)

```
Community
├── community-portal.mdx               ✅ exists
├── faq.mdx                            ✅ exists
├── livepeer-community/
│   ├── who-is-here.mdx                🟡 check exists
│   └── community-guidelines.mdx       🟡 check exists
├── livepeer-community/ (shape the network)
│   ├── governance-participation.mdx   🟡 check exists
│   └── workstreams.mdx                🟡 volatile — must route to live Forum
├── livepeer-contribute/
│   ├── ways-to-contribute.mdx         🟡 check exists
│   └── opportunities.mdx              🟡 check exists
├── livepeer-connect/
│   ├── channels.mdx                   🟡 check exists
│   ├── events-and-calls.mdx           🟡 check exists
│   └── news-and-updates.mdx           🟡 check exists
└── resources/
    ├── community-tools.mdx            🟡 check exists
    └── community-guides.mdx           🟡 check exists
```

### Community success criteria
| Human need | Covered? |
|---|---|
| "Who is in this community?" | 🟡 needs check |
| "Where do I go?" (platform map) | 🟡 needs check |
| "How do I contribute?" | 🟡 needs check |
| "What are the funded opportunities?" | 🟡 needs check |
| "What are the recurring calls?" | 🟡 needs check |
| Foundation info current (June 2025) | 🔴 needs update everywhere |
| Workstreams not hard-coded | 🔴 volatile content must route to Forum |

---

## TAB 8: SOLUTIONS

**Root:** `v2/solutions/`
**Job:** Product documentation for platforms built on Livepeer.
**Primary humans:** Users and developers of specific products.

### Actual structure (docs-v2-dev)

Subdirectories exist per product. Structure TBC pending directory read.
Core requirement: each product needs **overview + quickstart + reference** minimum.

Products that must have docs:
- Daydream
- Streamplace
- Embody
- Frameworks
- Livepeer Studio (88 pages — comprehensive)

### Solutions success criteria
| Need | Covered? |
|---|---|
| Each product: overview | 🟡 varies by product |
| Each product: quickstart | 🟡 varies |
| Bridge from About tab | 🔴 About has no "what's been built?" page |

---

## TAB 9: RESOURCES

**Root:** `v2/resources/`
**Job:** Cross-cutting reference. Changelogs. Documentation guide.
**Primary humans:** All — lookup destination.

### Actual structure (docs-v2-dev)

```
v2/resources/
(directory exists — full content TBC)
```

Core required sections:
- changelog/ (20 pages — go-livepeer, SDKs, AI runner, etc.)
- documentation-guide/ (15 pages)
- glossary.mdx (site-wide)
- help-center.mdx

**Status: Mostly complete. Primary risk: changelog currency.**

---

## CROSS-TAB MISSING CONNECTIONS

| Gap | From | To | Impact |
|---|---|---|---|
| "What's been built?" bridge | About | Solutions | Evaluator journey breaks — no bridge page |
| Roadmap canonicalisation | Home (stub) + Community (stub) | About (technical-roadmap.mdx) | 3 tabs, all thin — consolidate ownership |
| Developer → self-host path | Developers | Gateways | "You were using Daydream, now self-host" journey undocumented |
| Pool worker journey | GPU Nodes quickstart | GPU Nodes guides | Persona B has no path after dep-x deprecated |
| Remote signer + clearinghouse | Gateways concepts | Gateways guides/payments | New Q4 2025 architecture not in docs at all |

---

## PRIORITY RANKING — CONTENT TO WRITE

### 🔴 P1 — Site breaks without these (journey-blocking)

| # | File path | Tab | What |
|---|---|---|---|
| 1 | `gateways/concepts/payment-modes.mdx` | Gateways | On-chain vs off-chain decision |
| 2 | `gateways/setup/remote-signers.mdx` | Gateways | Remote signer setup (Q4 2025) |
| 3 | `gateways/guides/payments-and-pricing/clearinghouse.mdx` | Gateways | Clearinghouse architecture |
| 4 | `gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx` | Gateways | Off-chain discovery |
| 5 | `orchestrators/quickstart/join-a-pool.mdx` | GPU Nodes | Pool worker path |
| 6 | `orchestrators/concepts/job-types.mdx` | GPU Nodes | AI pipeline types current |
| 7 | `orchestrators/resources/faq.mdx` EXPAND | GPU Nodes | Troubleshooting (confirmed blocker) |
| 8 | `developers/concepts/ai-on-livepeer.mdx` REWRITE | Developers | NaaP/clearinghouse accuracy |
| 9 | `about/network/actors.mdx` REWRITE | About | Merge sub-stubs, make comprehensive |
| 10 | Remove 4 Home stubs from nav | Home | docs.json edit only |

### 🟡 P2 — Tab is degraded without these

| # | File path | Tab | What |
|---|---|---|---|
| 11 | `orchestrators/guides/config-and-optimisation/pricing-strategy.mdx` | GPU Nodes | Competitive pricing |
| 12 | `orchestrators/guides/advanced-operations/run-a-pool.mdx` COMPLETE | GPU Nodes | Pool operation |
| 13 | `gateways/guides/node-pipelines/dual-ai-video.mdx` | Gateways | Dual config |
| 14 | `developers/get-started/setup-paths.mdx` | Developers | Which quickstart? |
| 15 | `developers/guides/ai/authentication.mdx` EXPAND | Developers | Auth flows |
| 16 | `developers/guides/ai/production-checklist.mdx` COMPLETE | Developers | Production |
| 17 | `about/resources/ecosystem-and-products.mdx` | About | Bridge to Solutions |
| 18 | `about/network/actors.mdx` content (post-merge) | About | Comprehensive actors |
| 19 | `delegators/guides/governance/*` VERIFY | LP Token | GovWorks Feb 2025 |
| 20 | `delegators/guides/treasury/*` VERIFY | LP Token | Current proposal process |

### 🟢 P3 — Polish

| # | File path | Tab | What |
|---|---|---|---|
| 21 | `about/resources/knowledge-hub/evaluating-livepeer.mdx` | About | Evaluator path |
| 22 | `about/protocol/core-mechanisms.mdx` COMPLETE | About | Finish unfinished sections |
| 23 | `community/*` Foundation info update | Community | June 2025 Foundation |
| 24 | `home/about-livepeer/roadmap.mdx` | Home | Write or redirect |
| 25 | `delegators/portal.mdx` EXPAND | LP Token | 2.8KB too thin |
