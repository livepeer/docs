# Execution Plan — Get It Done
## Ordered against actual docs-v2-dev branch state

---

## PHASE 0 — Nav surgery (30 min, no content writing)

Remove from docs.json — dead ends in nav right now:

```
v2/home/get-started/ai-pipelines.mdx           Coming Soon
v2/home/get-started/build-on-livepeer.mdx      Coming Soon
v2/home/get-started/stream-video.mdx           Coming Soon
v2/home/get-started/use-livepeer.mdx           Coming Soon
v2/about/network/livepeer-actors/orchestrators.mdx
v2/about/network/livepeer-actors/gateways.mdx
v2/about/network/livepeer-actors/delegators.mdx
v2/about/network/livepeer-actors/end-users.mdx
v2/about/resources/knowledge-hub/contributor-orientation.mdx
```

One PR. docs.json only. No content.

---

## PHASE 1 — P1 content (in dependency order, run parallel)

Each = one Codex worktree, one feature branch, one PR. Do not combine.

### Round 1 — No dependencies, all parallel

**ORC-A: `v2/orchestrators/concepts/job-types.mdx`** — NEW
- Source: `ai-workloads-overview.mdx`, `ai-workloads-sources.md`, go-livepeer AI subnet
- Content: transcoding vs AI, per-pipeline VRAM table, realtime vs batch explained
- Target: ~8KB

**ORC-B: `v2/orchestrators/resources/faq.mdx`** — NEW
- Source: `gpu-nodes-ia-planning.md` pain points, `local-gateways-discord.txt`
- Content: 20 Q&As — startup errors, port forwarding, active set, pricing, AI VRAM
- Target: ~12KB

**GW-A: `v2/gateways/concepts/payment-modes.mdx`** — NEW
- Source: `Remote_signers.md`, `local-gateways-discord.txt`, `gateways-ia-planning.md`
- Content: on-chain vs off-chain explained, remote signer intro, decision matrix
- Target: ~8KB

**DEV-A: `v2/developers/concepts/ai-on-livepeer.mdx`** — REWRITE
- Source: `ai-workloads-sources.md`, `local-gateways-discord.txt` (NaaP/clearinghouse)
- Content: AI network architecture, pipelines, hosted vs self-hosted, realtime vs batch
- Target: ~10KB

### Round 2 — After Round 1 PRs open for review

**ORC-C: `v2/orchestrators/quickstart/join-a-pool.mdx`** — NEW
- Source: `setup-paths-sources.md` (Titan Node repo, OrchestratorSiphon), `gpu-nodes-ia-planning.md` Persona B
- Content: pool worker vs solo, install as worker, connect to pool, verify
- Target: ~8KB

**ORC-D: `v2/orchestrators/quickstart/setup-paths.mdx`** — NEW
- Source: `setup-paths-sources.md`, `gpu-nodes-ia-planning.md`
- Content: decision table + path cards: solo/pool/AI-only/enterprise
- Target: ~6KB

**ORC-E: `v2/orchestrators/setup/publish-offerings.mdx`** — NEW
- Source: go-livepeer docs, orchestrator-offerings context
- Content: on-chain activation via livepeer_cli, set service URI, stake LPT, go live
- Target: ~8KB

**GW-B: `v2/gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx`** — NEW
- Source: `local-gateways-discord.txt` (j0sh quotes), j0sh livepeer-python-gateway examples
- Content: on-chain list endpoint, static list, custom discovery, Python examples
- Target: ~8KB

### Round 3 — After GW-A (payment-modes) merged

**GW-C: `v2/gateways/setup/remote-signers.mdx`** — NEW
- Source: `Remote_signers.md`, `local-gateways-discord.txt` (EliteEncoder hosted signer)
- Content: what remote signers are, hosted vs self-hosted, go-livepeer flags
- Target: ~10KB

### Round 4 — After GW-A + GW-C merged

**GW-D: `v2/gateways/guides/payments-and-pricing/clearinghouse.mdx`** — NEW
- Source: `local-gateways-discord.txt` ("that would basically be the clearinghouse"), `Remote_signers.md`
- Content: components (remote signer + auth + accounting + discovery), NaaP reference
- Target: ~12KB

---

## PHASE 2 — P2 content

Run after P1 PRs in review. Same pattern: one brief, one worktree, one PR.

| ID | File | What |
|---|---|---|
| P2-1 | `v2/about/network/actors.mdx` | REWRITE — merge 4 sub-stubs, ~15KB comprehensive |
| P2-2 | `v2/about/concepts/ecosystem-products.mdx` | NEW — "what's been built on Livepeer?" |
| P2-3 | `v2/orchestrators/setup/monitor.mdx` | EXPAND — 2.5KB → Grafana/Prometheus full guide |
| P2-4 | `v2/orchestrators/setup/data-centre-setup.mdx` | NEW — enterprise multi-node |
| P2-5 | `v2/orchestrators/guides/ai-and-job-workloads/ai-pipelines.mdx` | EXPAND — aiModels.json schema, containers, warm loading |
| P2-6 | `v2/orchestrators/guides/config-and-optimisation/pricing-strategy.mdx` | NEW — competitive pricing |
| P2-7 | `v2/orchestrators/guides/advanced-operations/run-a-pool.mdx` | EXPAND — pool operator |
| P2-8 | `v2/gateways/setup/configure/dual.mdx` | NEW — dual AI+video config |
| P2-9 | `v2/developers/get-started/setup-paths.mdx` | EXPAND — "which quickstart?" decision tree |
| P2-10 | `v2/developers/guides/ai/authentication.mdx` | EXPAND — auth flows |
| P2-11 | `v2/developers/guides/ai/production-checklist.mdx` | COMPLETE — pre-launch |
| P2-12 | `v2/delegators/guides/governance/processes.mdx` | VERIFY — GovWorks Feb 2025 |

---

## PHASE 3 — Currency + IA cleanup

- LP Token: verify tokenomics, treasury proposals (3 files — SME review with Mehrdad)
- Community: Foundation updates across all pages + implement final IA (renames)
- Home: roadmap.mdx — write or redirect
- About: actors.mdx sub-stubs merged → P2-1 handles this

---

## SOURCE FILES FOR CODEX AGENTS

All research is done. Do not re-research. Use these:

| Need | File |
|---|---|
| GPU operator personas (A–E) | `/mnt/project/gpu-nodes-ia-planning.md` |
| Gateway operator personas (A–C) | `/mnt/project/gateways-ia-planning.md` |
| Community audience + purpose | `/mnt/project/community-tab-02-audience-and-purpose.md` |
| Community final IA | `/mnt/project/community-tab-05-final-ia-and-pages.md` |
| Remote signer architecture | `/mnt/project/Remote_signers.md` |
| Gateway Discord intelligence | `/mnt/project/local-gateways-discord.txt` |
| Staking/rewards sources | `/mnt/project/staking-rewards-sources.md` |
| Pool + siphon setup sources | `/mnt/project/setup-paths-sources.md` |
| AI workloads overview | `/mnt/project/ai-workloads-overview.mdx` |
| AI workloads sources | `/mnt/project/ai-workloads-sources.md` |
| Content strategy rules | `/mnt/skills/user/content-strategy/SKILL.md` |
| Copy rules | `/mnt/skills/user/copy-rules/SKILL.md` |
| Page authoring | `/mnt/skills/user/page-authoring/SKILL.md` |
