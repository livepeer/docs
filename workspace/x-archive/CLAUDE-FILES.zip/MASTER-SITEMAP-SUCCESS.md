# Master Site Map — Inventory & Status
## docs-v2-dev branch, read 2026-04-07

> Companion to FIRST-PRINCIPLES-SITEMAP.md  
> This is the inventory view: what exists, what's its status, what's missing.

---

## SUMMARY COUNTS

| Tab | Published files (approx) | P1 gaps | P2 gaps | Ship? |
|---|---|---|---|---|
| Home | 19 | 1 | 2 | 🔴 |
| About | 34 | 0 | 3 | 🔴 |
| GPU Nodes | 82 | 5 | 7 | 🔴 |
| Gateways | 87 (incl. views) | 4 | 3 | 🔴 |
| Developers | 51 | 1 | 3 | 🔴 |
| LP Token | 25 | 0 | 0 | 🟡 verify |
| Community | 18 | 0 | 2 | 🟡 update |
| Solutions | 109 | 0 | 1 | 🟡 thin |
| Resources | 53 | 0 | 0 | ✅ |

---

## HOME

| File | KB | Status |
|---|---|---|
| mission-control.mdx | 6.3 | ✅ |
| primer.mdx | 10.6 | ✅ |
| get-started.mdx | 7.5 | ✅ |
| trending.mdx | 6.4 | ⚠️ stale risk |
| about-livepeer/vision.mdx | 8.8 | ✅ |
| about-livepeer/evolution.mdx | 7.9 | ✅ |
| about-livepeer/ecosystem.mdx | 25.7 | ⚠️ Foundation update |
| about-livepeer/benefits.mdx | 9.9 | ✅ |
| about-livepeer/roadmap.mdx | 1.8 | 🔴 STUB |
| get-started/ai-pipelines.mdx | 0.5 | 🔴 STUB IN NAV |
| get-started/build-on-livepeer.mdx | 0.4 | 🔴 STUB IN NAV |
| get-started/stream-video.mdx | 0.5 | 🔴 STUB IN NAV |
| get-started/use-livepeer.mdx | 0.4 | 🔴 STUB IN NAV |
| solutions/verticals.mdx | 13 | ✅ |
| solutions/applications.mdx | 3.7 | ⚠️ |
| solutions/showcase.mdx | 2.4 | ⚠️ |
| solutions/landscape.mdx | 1.2 | 🔴 thin |

---

## ABOUT

| File | KB | Status |
|---|---|---|
| concepts/mental-model.mdx | 21 | ✅ GOLD |
| concepts/livepeer-overview.mdx | 10.7 | ✅ |
| concepts/core-concepts.mdx | 9.7 | ✅ |
| **concepts/ecosystem-products.mdx** | — | 🔴 MISSING |
| network/overview.mdx | 6.8 | ✅ |
| network/actors.mdx | 5 | 🔴 THIN (rewrite) |
| network/livepeer-actors/*.mdx (×4) | 1.5–1.7 | 🔴 STUBS IN NAV |
| network/job-lifecycle.mdx | 10.4 | ✅ |
| network/marketplace.mdx | 6.5 | ✅ |
| network/technical-architecture.mdx | 6.2 | ✅ |
| network/interfaces.mdx | 5.9 | ✅ |
| protocol/overview.mdx | 14.5 | ✅ |
| protocol/core-mechanisms.mdx | 25 | ⚠️ incomplete |
| protocol/livepeer-token.mdx | 13.3 | ✅ |
| protocol/economics.mdx | 10.4 | ✅ |
| protocol/governance-model.mdx | 15.8 | ✅ |
| protocol/treasury.mdx | 16.7 | ✅ |
| protocol/blockchain-contracts.mdx | 59 | ✅ GOLD |
| protocol/technical-architecture.mdx | 9.9 | ✅ |
| protocol/design-philosophy.mdx | 11.4 | ✅ |
| resources/glossary.mdx | 51 | ✅ |
| resources/faq.mdx | 2.9 | 🔴 thin |
| resources/knowledge-hub/evaluating-livepeer.mdx | 1.5 | 🔴 STUB |
| resources/knowledge-hub/contributor-orientation.mdx | 1.5 | 🔴 STUB |
| resources/knowledge-hub/gateways-vs-orchestrators.mdx | 2.7 | ⚠️ thin |
| resources/knowledge-hub/livepeer-whitepaper.mdx | 4 | ✅ |
| resources/reference/livepeer-contract-addresses.mdx | — | ✅ |
| resources/reference/technical-roadmap.mdx | 8 | ✅ |
| resources/reference/network-metrics.mdx | 1.6 | 🔴 thin |

---

## GPU NODES / ORCHESTRATORS

| File | KB | Status |
|---|---|---|
| portal.mdx | 6.7 | ✅ |
| navigator.mdx | 12 | ✅ |
| concepts/role.mdx | 15 | ✅ |
| concepts/architecture.mdx | 19.5 | ✅ |
| concepts/incentive-model.mdx | 18.6 | ✅ |
| concepts/capabilities.mdx | 13.8 | ✅ |
| **concepts/job-types.mdx** | — | 🔴 MISSING P1 |
| quickstart/video-transcoding.mdx | 5.3 | ✅ |
| quickstart/AI-prompt-start.mdx | 10.2 | ✅ |
| quickstart/guide.mdx | 5.1 | ⚠️ thin |
| quickstart/tutorial.mdx | 1.4 | 🔴 STUB |
| **quickstart/join-a-pool.mdx** | — | 🔴 MISSING P1 |
| **quickstart/setup-paths.mdx** | — | 🔴 MISSING P1 |
| **quickstart/realtime-ai-quickstart.mdx** | — | 🔴 MISSING |
| **quickstart/batch-ai-quickstart.mdx** | — | 🔴 MISSING |
| setup/install.mdx | 17 | ✅ |
| setup/configure.mdx | 15.6 | ✅ |
| setup/connect.mdx | 13.1 | ✅ |
| setup/verify.mdx | 16.7 | ✅ |
| setup/prepare.mdx | 3.3 | ⚠️ thin |
| setup/monitor.mdx | 2.5 | 🔴 thin P2 |
| setup/guide.mdx | 3.3 | ⚠️ thin |
| **setup/publish-offerings.mdx** | — | 🔴 MISSING P1 |
| **setup/data-centre-setup.mdx** | — | 🔴 MISSING P2 |
| guides/operator-considerations/* | — | ✅ |
| guides/deployment-details/* | — | ✅ |
| guides/ai-and-job-workloads/ai-pipelines.mdx | — | 🔴 thin P2 |
| **guides/ai-and-job-workloads/hosting-models.mdx** | — | 🔴 MISSING |
| **guides/config-and-optimisation/pricing-strategy.mdx** | — | 🔴 MISSING P2 |
| guides/monitoring-and-tooling/* | — | ⚠️ |
| guides/staking-and-rewards/* | — | ✅ |
| guides/payments-and-pricing/* | — | ✅ |
| guides/advanced-operations/run-a-pool.mdx | — | 🔴 thin P2 |
| **guides/advanced-operations/remote-workers.mdx** | — | 🔴 MISSING |
| **guides/tutorials/pool-worker.mdx** | — | 🔴 MISSING |
| resources/glossary.mdx | 89.7 | ✅ |
| resources/operator-terms.mdx | 22 | ✅ |
| **resources/faq.mdx** | — | 🔴 MISSING P1 |
| **resources/cli-flags.mdx** | — | 🔴 MISSING P3 |
| **resources/community-pools.mdx** | — | 🔴 MISSING P3 |
| **resources/aimodels-schema.mdx** | — | 🔴 MISSING |

---

## GATEWAYS

| File | KB | Status |
|---|---|---|
| portal.mdx | 5.6 | ✅ |
| navigator.mdx | 18.9 | ✅ |
| concepts/role.mdx | 16.7 | ✅ |
| concepts/architecture.mdx | 15 | ✅ |
| concepts/capabilities.mdx | 11.3 | ✅ |
| concepts/business-model.mdx | 11 | ✅ |
| **concepts/payment-modes.mdx** | — | 🔴 MISSING P1 |
| quickstart/ (composable structure) | — | ✅ |
| setup/prepare.mdx | 14.1 | ✅ GOLD |
| setup/guide.mdx | 14.7 | ✅ |
| setup/monitor.mdx | 17.5 | ✅ |
| setup/install.mdx | 2.8 | ⚠️ thin shell |
| setup/configure.mdx | 2.2 | ⚠️ thin shell |
| setup/connect.mdx | 4.9 | ✅ |
| setup/verify.mdx | 2.4 | ⚠️ thin shell |
| setup/configure/ (AI, video, pricing views) | — | ✅ |
| **setup/configure/dual.mdx** | — | 🔴 MISSING P2 |
| **setup/remote-signers.mdx** | — | 🔴 MISSING P1 |
| guides/operator-considerations/* | — | ✅ |
| guides/deployment-details/* | — | ✅ |
| guides/monitoring-and-tooling/* | — | ✅ |
| guides/node-pipelines/* | — | ⚠️ |
| guides/payments-and-pricing/payment-guide.mdx | — | ✅ |
| **guides/payments-and-pricing/remote-signers.mdx** | — | 🔴 MISSING |
| **guides/payments-and-pricing/clearinghouse.mdx** | — | 🔴 MISSING P1 |
| guides/advanced-operations/scaling.mdx | — | ✅ |
| guides/advanced-operations/orchestrator-selection.mdx | — | ✅ |
| **guides/advanced-operations/orchestrator-discovery-offchain.mdx** | — | 🔴 MISSING P1 |
| guides/roadmap-and-funding/* | — | ✅ |
| guides/tutorials/go-production.mdx | — | ⚠️ incomplete |
| resources/ (AI-API, CLI-HTTP, AI-Worker) | — | ✅ |

---

## DEVELOPERS

| File | KB | Status |
|---|---|---|
| portal.mdx | 5.3 | ✅ |
| navigator.mdx | 8.4 | ✅ |
| concepts/ai-on-livepeer.mdx | — | 🔴 REWRITE P1 |
| concepts/developer-stack.mdx | — | ✅ |
| concepts/oss-stack.mdx | — | ✅ |
| concepts/running-a-gateway.mdx | — | ✅ |
| concepts/video.mdx | — | ✅ |
| get-started/setup-paths.mdx | — | ⚠️ thin P2 |
| get-started/ai-quickstart.mdx | — | ✅ |
| get-started/transcoding-quickstart.mdx | — | ✅ |
| get-started/comfystream.mdx | — | ✅ |
| get-started/contributor.mdx | — | ✅ |
| build/byoc.mdx | — | ✅ |
| build/comfystream.mdx | — | ✅ |
| build/model-support.mdx | — | ✅ |
| build/sdk-gateway.mdx | — | ✅ |
| build/workload-fit.mdx | — | ⚠️ thin |
| guides/ai/authentication.mdx | — | 🔴 thin P2 |
| guides/ai/production-checklist.mdx | — | 🔴 incomplete P2 |
| guides/ai/troubleshooting.mdx | — | ✅ |
| guides/video/* | — | ✅ |
| guides/tutorials/* | — | ✅ |
| guides/opportunities/* | — | ✅ |
| resources/* | — | ✅ |

---

## LP TOKEN / DELEGATORS

All pages exist. 3 need currency verification with Mehrdad:
- `concepts/tokenomics.mdx` — post-AI subnet numbers
- `guides/governance/processes.mdx` — GovWorks Feb 2025 process
- `guides/treasury/proposals.mdx` — current proposal submission

Everything else: ✅

---

## COMMUNITY

All pages exist. Need:
- Foundation June 2025 update across: community-portal.mdx, faq.mdx, governance-and-foundation.mdx
- workstreams → route to live Forum source
- Final IA renames per canonical plan (community-tab-05-final-ia-and-pages.md)

---

## SOLUTIONS

studio/ and streamplace/ ✅ comprehensive  
daydream/, embody/, frameworks/ ⚠️ thin — need quickstart added  
**Missing:** Bridge from About (`about/concepts/ecosystem-products.mdx`)

---

## RESOURCES

✅ Publishable. Keep changelogs current.
