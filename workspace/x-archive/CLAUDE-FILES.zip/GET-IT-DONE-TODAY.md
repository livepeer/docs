# Get It Done Today
## Ordered actions — docs-v2-dev branch

---

## RIGHT NOW (no content writing)

**docs.json — remove from nav:**
```
v2/home/get-started/ai-pipelines.mdx
v2/home/get-started/build-on-livepeer.mdx
v2/home/get-started/stream-video.mdx
v2/home/get-started/use-livepeer.mdx
v2/about/network/livepeer-actors/orchestrators.mdx
v2/about/network/livepeer-actors/gateways.mdx
v2/about/network/livepeer-actors/delegators.mdx
v2/about/network/livepeer-actors/end-users.mdx
v2/about/resources/knowledge-hub/contributor-orientation.mdx
```
One PR. 30 minutes.

---

## P1 CONTENT — ORDER OF EXECUTION

### Round 1 (parallel, no dependencies)

| ID | Branch | File | Source material |
|---|---|---|---|
| ORC-A | `content/orc-job-types` | `v2/orchestrators/concepts/job-types.mdx` NEW | `ai-workloads-overview.mdx`, `ai-workloads-sources.md` |
| ORC-B | `content/orc-faq` | `v2/orchestrators/resources/faq.mdx` NEW | `gpu-nodes-ia-planning.md` pain points, `local-gateways-discord.txt` |
| GW-A | `content/gw-payment-modes` | `v2/gateways/concepts/payment-modes.mdx` NEW | `Remote_signers.md`, `local-gateways-discord.txt`, `gateways-ia-planning.md` |
| DEV-A | `content/dev-ai-concept` | `v2/developers/concepts/ai-on-livepeer.mdx` REWRITE | `ai-workloads-sources.md`, `local-gateways-discord.txt` |

### Round 2 (while Round 1 in review)

| ID | Branch | File | Source material |
|---|---|---|---|
| ORC-C | `content/orc-join-pool` | `v2/orchestrators/quickstart/join-a-pool.mdx` NEW | `setup-paths-sources.md`, `gpu-nodes-ia-planning.md` Persona B |
| ORC-D | `content/orc-setup-paths` | `v2/orchestrators/quickstart/setup-paths.mdx` NEW | `setup-paths-sources.md`, `gpu-nodes-ia-planning.md` |
| ORC-E | `content/orc-publish` | `v2/orchestrators/setup/publish-offerings.mdx` NEW | go-livepeer docs |
| GW-B | `content/gw-orch-discovery` | `v2/gateways/guides/advanced-operations/orchestrator-discovery-offchain.mdx` NEW | `local-gateways-discord.txt`, j0sh python-gateway examples |

### Round 3 (after GW-A merged)

| ID | Branch | File | Source material |
|---|---|---|---|
| GW-C | `content/gw-remote-signers` | `v2/gateways/setup/remote-signers.mdx` NEW | `Remote_signers.md`, PRs #3791/#3822, EliteEncoder hosted signer |

### Round 4 (after GW-A + GW-C merged)

| ID | Branch | File | Source material |
|---|---|---|---|
| GW-D | `content/gw-clearinghouse` | `v2/gateways/guides/payments-and-pricing/clearinghouse.mdx` NEW | `local-gateways-discord.txt`, `Remote_signers.md` |

---

## RULES

- One Codex worktree per brief
- One feature branch per brief  
- One PR per brief
- Base: `docs-v2-dev` pulled fresh before each task
- `SKIP_VERIFICATION=1 git commit` for pre-existing drift outside task scope
- Direct push to `docs-v2-dev` blocked — all changes via PR

---

## CONTENT BRIEF TEMPLATE (per page)

```
Who reads this:    [one specific person at one moment in their journey]
What they need:    [single accomplishment]
Page type:         [concept | tutorial | how-to | reference]
Reader question:   [one concrete question, not "overview of X"]
Promise:           [after reading, the reader can: ___]
In scope:          [exactly what this page covers]
Out of scope:      [what it doesn't cover + where that lives]
Primary sources:   [files listed above for each brief]
Next page:         [where reader goes after this]
```

---

## QUALITY GATE (every page before merge)

```
□ Opening: subject → what page does → constraint (3 sentences, no anti-patterns)
□ Primary audience named, intro written for them
□ Every factual claim has a primary source
□ Clear "next step" at end
□ Reader with stated prerequisites can complete task without leaving page
□ Trade-offs named (concept/economics/architecture pages)
```

All 6 pass = merge. Any fail = not ready.
