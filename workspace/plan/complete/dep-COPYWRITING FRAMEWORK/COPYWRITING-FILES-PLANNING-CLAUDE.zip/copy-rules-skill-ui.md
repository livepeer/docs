# Copy Rules — Livepeer Docs

Apply these rules to every sentence written for Livepeer documentation. No exceptions.

---

## The master test

Before any sentence is written, ask:
Does this sentence give the operator something they can act on, believe, or use to make a decision — stated directly, with no qualifications, contrasts, or conditions?
If no: rewrite or delete.

---

## Banned words

Never use these in body prose:

effectively, essentially, basically, meaningful, significant, real (as intensifier), various, several, simply, obviously, clearly, just (as minimiser)

---

## Banned phrases

Never use any of these:

- "This page covers / explains / describes"
- "This section covers"
- "In this guide"
- "The reason is straightforward"
- "Understanding X is essential"
- "It is important to note"
- "As mentioned above"
- "among other factors" / "and so on" / "etc."
- "low but not zero"
- "not just [X]"
- "rather than"
- "what it takes"
- "once [X] is stable"
- "it should be noted"
- "not preference"
- "depends on various factors"
- "can generate" / "may produce" in value claims

---

## Banned constructions

**`not [X]` in value statements**
Defines value by contrast. Rewrite as a positive assertion. Delete the contrast.

**`if [condition]` in body prose**
Conditional gatekeeping. State the condition as a fact or remove it.
Exception: code blocks and prerequisite lists.

**`[value statement] — if [condition]`**
Undercuts the value in the same breath. Split into two sentences. Value first. Requirement second.

**`rather than`**
Contrast-by-diminishment. Delete the contrast clause. State the positive directly.

**`This page [verb]`**
Announces content instead of delivering it. Delete. Start with the content.

**`what it takes`**
Hurdle framing. State the requirements directly.

**`consistently` without a number**
Vague standard. Add a threshold or rewrite.

**`can/may [verb]` in value claims**
Weakened assertion. Assert directly or delete.

---

## Structural rules (summary)

- One paragraph, one job
- Lead sentence states the fact; remaining sentences extend or evidence it
- Final sentence: fact, number, or next step — never a hedge or restatement
- Prose that restates a table or diagram is deleted
- High-value URLs and commands appear in body copy — not only inside accordions
- Every path introduced is developed on the page or linked

---

## Currency

All monetary examples use USD. If content is region-scoped, declare the region once at section opening.

---

## REVIEW flags

`{/* REVIEW: */}` flags must never appear in rendered content. Any page with an unresolved REVIEW flag in a decision-critical position (table cell, numbered step, decision matrix) is blocked from merge.
