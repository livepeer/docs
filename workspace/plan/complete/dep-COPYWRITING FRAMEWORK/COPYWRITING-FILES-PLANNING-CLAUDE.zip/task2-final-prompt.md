# Agent Implementation Prompt — Copy Governance Framework
**Livepeer Docs Copy Framework — Codex Task**
**Version 4.0 — March 2026**

---

## Pre-flight: run these yourself first and record outputs

Run each command. The outputs replace the [RECORDED: ...] placeholders in the prompt below before you send it.

```bash
# 1. Get valid @needs IDs
grep -r "@needs" tools/scripts/ | head -20

# 2. Read existing PR template
git show docs-v2:.github/pull_request_template.md

# 3. Check ai-tools directory
git ls-tree -r docs-v2 --name-only | grep ai-tools | head -20

# 4. Check docs-guide directory and index generator
git ls-tree docs-v2 docs-guide/
node tools/scripts/generate-docs-guide-indexes.js --help

# 5. Check tools/lib
git ls-tree docs-v2 tools/lib/

# 6. Check tasks/reports
git ls-tree docs-v2 tasks/reports/
```

Record the outputs. Fill in the four [RECORDED: ...] placeholders in the prompt below before sending.

---

## Documents to attach

- Doc 1 — Framework L0–L8 (for README generation)
- Doc 7 — Phase 1: brief template, banned reference files, `lint-copy.js`, PR checklist
- Doc 8 — Phase 3: `lint-patterns.js`, `pattern-observer.js`, two SKILL.md files
- Doc 9 — Phase 2: `lint-structure.js`, three SKILL.md files
- Doc 10 — Test suite: fixture files, expected JSON files
- Doc 11 — Root `SKILL.md`, `review-gate.md`, `copy-rules.md`, `invocation-guide.md`
- Doc 12 — Documentation skill scope (for `skill-docs.md`)

---

## The prompt

```
Base branch: docs-v2
Pull docs-v2 before creating any files.

TASK: Create the copy governance framework files as specified in the
attached documents. Where instructions in this prompt differ from the
attached documents, this prompt takes precedence.

---

CONTEXT FROM PRE-FLIGHT

@needs IDs confirmed in active use:
[RECORDED: paste output of grep -r "@needs" tools/scripts/ | head -20 here]

Existing PR template structure:
[RECORDED: paste output of git show docs-v2:.github/pull_request_template.md here]

ai-tools/ directory contents:
[RECORDED: paste output of git ls-tree -r docs-v2 --name-only | grep ai-tools | head -20 here]

tools/lib/ contents:
[RECORDED: paste output of git ls-tree docs-v2 tools/lib/ here]

---

STEP 0 — READ AND REPORT

Before creating any files, read the following and output a STEP 0 REPORT:

1. Read tests/unit/style-guide.test.js
   Extract every rule enforced. Format: Rule | Type (word/phrase/pattern)

2. Read tests/unit/docs-authoring-rules.test.js
   Same format.

3. Read tests/unit/frontmatter-taxonomy.test.js
   List every frontmatter field currently validated.

4. Read tests/run-pr-checks.js
   Report exactly how test suites are registered (the pattern to follow).

5. Run: git ls-tree docs-v2 tasks/reports/
   Report structure.

6. Run: node tools/scripts/generate-docs-guide-indexes.js --help
   Report whether docs-guide/tooling/ files are picked up automatically
   or require a manifest entry.

Output the STEP 0 REPORT. Then stop and wait for confirmation.

After the STEP 0 REPORT you will receive instructions confirming:
- Which words/phrases from Doc 7 P1-B overlap with existing tests and must be removed
- Whether frontmatter checks should be stripped from lint-structure.js
- Whether docs-guide/tooling/ requires a manifest entry after adding the brief template

Do not proceed to Commit 1 until you receive that confirmation.

---

COMMIT 1 — Reference files

tools/lib/copy-governance/banned-words.txt
  Source: Doc 7, P1-B, "Reference File 1"
  Apply overlap removals confirmed after Step 0 report.
  Path is tools/lib/copy-governance/ — NOT tools/scripts/lib/

tools/lib/copy-governance/banned-phrases.txt
  Source: Doc 7, P1-B, "Reference File 2"
  Apply overlap removals confirmed after Step 0 report.

ai-tools/ai-skills/docs-copy/reference/banned-words.txt
  Identical content to tools/lib/copy-governance/banned-words.txt

ai-tools/ai-skills/docs-copy/reference/banned-phrases.txt
  Identical content to tools/lib/copy-governance/banned-phrases.txt

Commit message: "feat(copy-framework): add banned word and phrase reference files"

---

COMMIT 2 — Scripts

For each script below:
- Add the full JSDoc header block using the exact format from tests/run-all.js lines 1–12
- Use @needs IDs from the CONTEXT FROM PRE-FLIGHT section above
- Update all require('./lib/...') paths to require('../../lib/copy-governance/...')
- If frontmatter checks in lint-structure.js were confirmed overlapping after Step 0, remove them

tools/scripts/lint-copy.js
  Source: Doc 7, P1-B
  @purpose-statement: Enforce banned word and phrase rules on MDX content files.
  @pipeline: P1, P2, P3

tools/scripts/lint-structure.js
  Source: Doc 9, P2-D
  @purpose-statement: Enforce structural rules on MDX content files.
  @pipeline: P2, P3

tools/scripts/lint-patterns.js
  Source: Doc 8, P3-A
  @purpose-statement: Enforce Tier 2 copy pattern rules on MDX content files.
  @pipeline: P3

tools/scripts/pattern-observer.js
  Source: Doc 8, P3-B
  @purpose-statement: Aggregate copy pattern violations across a tab or full v2 tree and emit a diagnostic report.
  @pipeline: P3
  Update all output paths to tasks/reports/copy-governance/

Commit message: "feat(copy-framework): add lint scripts with required headers"

---

COMMIT 3 — Test suite

Create tests/unit/copy-lint.test.js
  Must export { runTests({ stagedOnly }) } returning { errors: [], warnings: [] }
  Must follow the exact structural pattern of an existing tests/unit/*.test.js file
  Implements fixture-based checks from Doc 10 as unit tests
  When stagedOnly is true: scope to staged MDX files only
  Do NOT create tests/copy-lint/run-all.js — that path is forbidden

Create tests/copy-lint-fixtures/ (development reference only — not wired to runner)
  tests/copy-lint-fixtures/fixtures/pass/ — all pass fixtures from Doc 10
  tests/copy-lint-fixtures/fixtures/fail/ — all fail fixtures from Doc 10
  tests/copy-lint-fixtures/expected/ — all JSON files from Doc 10

Update tests/run-all.js
  Add with other requires at top:
    const copyLintTests = require('./unit/copy-lint.test');

  Add in runAllTests() immediately after the Style Guide Tests block:
    console.log('\n✍️  Running Copy Lint Tests...');
    const copyLintResult = normalizeSuiteResult(copyLintTests.runTests({ stagedOnly }));
    totalErrors += copyLintResult.errors.length;
    totalWarnings += copyLintResult.warnings.length;
    console.log(`   ${copyLintResult.errors.length} errors, ${copyLintResult.warnings.length} warnings`);

Update tests/run-pr-checks.js
  Register copyLintTests following the exact pattern reported in Step 0 item 4.
  Scope to changed MDX files when stagedOnly is true.

Commit message: "feat(copy-framework): add copy-lint test suite, wire into runner"

---

COMMIT 4 — SKILL.md files and README

ai-tools/ai-skills/docs-copy/SKILL.md
  Source: Doc 11, root SKILL.md section

ai-tools/ai-skills/docs-copy/README.md
  Generate from Doc 1. Include:
  - L0–L8 layer summary table
  - File index: every file in this directory and skills/ subdirectory
  - Start-here section linking to SKILL.md and reference/invocation-guide.md

ai-tools/ai-skills/docs-copy/skills/copy-rules.md
  Source: Doc 11, copy-rules section
  Update any require paths to tools/lib/copy-governance/

ai-tools/ai-skills/docs-copy/skills/structure-rules.md
  Source: Doc 9, P2-A

ai-tools/ai-skills/docs-copy/skills/value-prop-check.md
  Source: Doc 9, P2-B

ai-tools/ai-skills/docs-copy/skills/persona-routing.md
  Source: Doc 9, P2-C

ai-tools/ai-skills/docs-copy/skills/review-gate.md
  Source: Doc 11, review-gate.md section

ai-tools/ai-skills/docs-copy/skills/iteration-diagnostic.md
  Source: Doc 8, P3-C

ai-tools/ai-skills/docs-copy/skills/pattern-observer.md
  Source: Doc 8, P3-D

ai-tools/ai-skills/docs-copy/skills/skill-docs.md
  Source: Doc 12, "Skill file" section

ai-tools/ai-skills/docs-copy/reference/invocation-guide.md
  Source: Doc 11, invocation-guide.md section

Commit message: "feat(copy-framework): add SKILL.md files and README"

---

COMMIT 5 — Brief template and PR checklist

docs-guide/tooling/content-brief-template.md
  Source: Doc 7, P1-A
  After creating:
    Run: node tools/scripts/generate-docs-guide-indexes.js --write
    Run: node tests/unit/docs-guide-sot.test.js
    If manifest entry is required (confirmed in Step 0 item 6): add it first.
    If SOT test fails: stop and report. Do not proceed.

.github/pull_request_template.md
  The existing content is in the CONTEXT FROM PRE-FLIGHT section above.
  Integrate the L5 checklist from Doc 7, P1-D into the existing structure.
  Do not duplicate any item already present.
  Do not remove or reorder existing content.

Commit message: "feat(copy-framework): add brief template, integrate L5 into PR checklist"

---

COMMIT 6 — Report directory

tasks/reports/copy-governance/.gitkeep

Commit message: "feat(copy-framework): add copy-governance report directory"

---

VERIFICATION

Run each and report full output:

1. node tests/run-all.js --staged
   Expected: copy-lint suite appears, zero new errors from framework files

2. node tests/unit/copy-lint.test.js
   Expected: all fixture tests pass

3. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
   Expected: zero errors

4. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
   Expected: BANNED_WORD errors matching tests/copy-lint-fixtures/expected/banned-words.json

5. node tests/unit/script-docs.test.js --staged
   Expected: all four new scripts pass header validation

6. node tests/unit/docs-guide-sot.test.js
   Expected: pass

If any check fails: report the specific output and stop.
Do not attempt to fix script logic or test infrastructure.

---

FORBIDDEN

- Do not modify any existing .mdx content files in v2/
- Do not modify docs.json
- Do not modify navigation-exclusions.json
- Do not modify the .allowlist file
- Do not create tests/copy-lint/run-all.js
- Do not create .github/workflows/lint-copy.yml
- Do not create tools/scripts/lib/ — use tools/lib/copy-governance/ instead
- Do not merge content from multiple source documents into one file
- Do not reformat or rewrite file contents from the attached documents
```

---

## After deployment: adding new rules

**New banned word or phrase:**
1. Edit `tools/lib/copy-governance/banned-words.txt` or `banned-phrases.txt`
2. Mirror the change to `ai-tools/ai-skills/docs-copy/reference/`
3. Add a fail fixture and expected JSON in `tests/copy-lint-fixtures/`
4. Run `node tests/unit/copy-lint.test.js`

**New Tier 2 pattern:**
1. Add pattern object to `PATTERNS` array in `tools/scripts/lint-patterns.js`
2. Add fail fixture and expected JSON
3. Run `node tests/unit/copy-lint.test.js`
