# Phrase Mapping — Weak Patterns and Preferred Replacements
**docs-guide/quality-testing/phrase-mapping.md**
**Living document — add from every review pass**
**Version 1.0 — March 2026**

---

## How to use this file

When reviewing a page and finding a weak construction not already on the banned list, add it here with:
- The pattern (can be a specific phrase or a structural pattern)
- Why it fails
- The preferred replacement approach
- An example from real content where available

This file feeds the banned-phrases.txt reference list. Patterns that recur across three or more pages are promoted to banned status.

---

## Structural pattern failures

| Weak pattern | Why it fails | Preferred replacement |
|---|---|---|
| `What changes from [X]:` | Frames content as secondary to X; assumes reader knows X; not value-prop first | `How [this option] runs:` or state the mechanism directly as prose |
| `Unlike [X], this...` | Contrast-by-diminishment; positions this option as a variant | State what this option does; omit the comparison |
| `The [X] split separates what [Y] runs together.` | Mechanism first; reader doesn't know why they care | `[X] lets you [benefit]. [Then: how it works.]` |
| `[X] also uses...` | Positions option as an afterthought relative to previous option | Open the section with the option's own value proposition |
| `Use this when: [list]` as the first content in a section | Leads with conditions instead of value; makes the reader do the matching work | State the primary use case as a sentence in the opening, then conditions as supporting detail |
| `The critical difference from [X]:` | Comparative framing mid-section; assumes reader already understands X fully | State the property directly: `[This option] keeps reward calling independent of GPU state.` |
| `Other differences from [X]:` | Residual-list framing; implies content is secondary or leftover | Give each point its own sentence with its own value statement |

---

## Description field failures

| Weak pattern | Why it fails | Preferred replacement |
|---|---|---|
| `The [N] alternatives to [X] - [list].` | Lists content; announces rather than delivers value | State the decision the page enables: `Choose the right deployment path for your hardware, stake position, and operational requirements.` |
| `How to [do X] in Livepeer.` | Task-framing without operator benefit | `[Outcome] — how to configure [X] for [operator goal].` |
| `[X], [Y], and [Z] for [audience].` | Noun dump; no verb, no value | Lead with the outcome or the problem solved |

---

## Section opening failures

| Weak pattern | Why it fails | Preferred replacement |
|---|---|---|
| Opens with a command: `livepeer -transcoder ...` | Mechanism before benefit | One sentence of benefit/outcome, then the command |
| Opens with a process name: `A pool worker runs go-livepeer -transcoder...` | Technical definition before operator value | `The pool worker path earns from GPU compute without acquiring LPT. [Then: how it works.]` |
| Opens with a flag name | Assumes reader cares about the flag; they care about what the flag achieves | State the goal, then introduce the flag as the mechanism |

---

## Jargon introduced without definition

Patterns found in review — add to nearest `glossary.mdx`:

| Term | Where found | Correct definition |
|---|---|---|
| O-T Split | setup-options.mdx | Orchestrator-Transcoder Split: running the Orchestrator process (protocol, routing, keystore) and Transcoder process (GPU work) on separate machines |
| Siphon | setup-options.mdx | OrchestratorSiphon: a lightweight Python tool that handles on-chain operations (reward calling, fee withdrawal, governance voting) independently from the GPU machine |
| pool worker | setup-options.mdx | {/* REVIEW: confirm correct terminology with community — may not be standard Livepeer terminology */} |

---

## Promoted to banned list (no longer tracked here)

These patterns appeared in 3+ pages and have been added to `tools/lib/copy-governance/banned-phrases.txt`:

| Pattern | Date promoted |
|---|---|
| `This page covers` | Framework v1.0 |
| `The reason is straightforward` | Framework v1.0 |
| `Understanding X is essential` | Framework v1.0 |
| `rather than` | Framework v1.0 |
| `not just [X]` | Framework v1.0 |
