# Agent Implementation Prompt — Copy Governance Framework
**Livepeer Docs Copy Framework — Codex Task**
**Version 4.0 — March 2026**

---

## Documents to attach

Attach all of the following before running:

| Document | Contents |
|---|---|
| Doc 1 | Framework L0–L8 (for README generation) |
| Doc 7 | Phase 1: brief template, banned reference files, `lint-copy.js`, PR checklist |
| Doc 8 | Phase 3: `lint-patterns.js`, `pattern-observer.js`, two SKILL.md files |
| Doc 9 | Phase 2: `lint-structure.js`, three SKILL.md files |
| Doc 10 | Test suite: fixture files, expected JSON files |
| Doc 11 | Root `SKILL.md`, `review-gate.md`, `copy-rules.md`, `invocation-guide.md` |
| Doc 12 | Documentation skill scope: `skill-docs.md` content |

---

## The prompt

```
Base branch: docs-v2
Pull docs-v2 before creating any files.

TASK: Implement the copy governance framework files as specified in the
attached documents. Where these instructions differ from the attached
documents, these instructions take precedence.

---

STEP 0 — READ AND REPORT

Do not create any files until Step 0 is complete and confirmed.

Run and read each of the following. Output a single STEP 0 REPORT
covering all items.

1. git pull origin docs-v2 — confirm clean.

2. Read tests/unit/style-guide.test.js
   Extract every rule it enforces.
   Output as table: Rule | Type (word / phrase / pattern)

3. Read tests/unit/docs-authoring-rules.test.js
   Same table format.

4. Read tests/unit/frontmatter-taxonomy.test.js
   List every frontmatter field it validates.

5. Read .github/pull_request_template.md
   List every existing section heading and checklist item.

6. Run: grep -r "@needs" tools/scripts/ | head -20
   List all @needs IDs currently in use.

7. Run: git ls-tree docs-v2 ai-tools/
   Report what exists.

8. Run: git ls-tree docs-v2 tools/lib/
   Report what exists.

9. Run: git ls-tree docs-v2 tasks/reports/
   Report full structure.

10. Run: node tools/scripts/generate-docs-guide-indexes.js --help
    Report whether it scans automatically or requires manifest entries.

11. Read tests/run-pr-checks.js
    Report exactly how test suites are registered.

After producing the STEP 0 REPORT, stop and wait for confirmation.

---

STEP 0 DECISIONS — YOU WILL RECEIVE THESE AFTER THE REPORT

The following will be confirmed after reviewing the Step 0 report:

A. OVERLAP DECISION: which words/phrases from Doc 7 P1-B already exist
   in style-guide.test.js or docs-authoring-rules.test.js. Remove those
   from the reference files — do not duplicate existing enforcement.

B. FRONTMATTER DECISION: whether lint-structure.js frontmatter checks
   duplicate frontmatter-taxonomy.test.js. If yes, remove them from
   lint-structure.js before committing.

C. NEEDS IDS: the @needs IDs to use in all four script headers.

D. DOCS-GUIDE REGISTRATION: whether content-brief-template.md requires
   a manifest entry after file creation.

You will receive A–D as explicit instructions before Commit 1 begins.

---

COMMIT 1 — Reference files

tools/lib/copy-governance/banned-words.txt
  → Content from Doc 7, P1-B, "Reference File 1"
  → Apply overlap removal per Decision A

tools/lib/copy-governance/banned-phrases.txt
  → Content from Doc 7, P1-B, "Reference File 2"
  → Apply overlap removal per Decision A

ai-tools/ai-skills/docs-copy/reference/banned-words.txt
  → Identical content to tools/lib/copy-governance/banned-words.txt

ai-tools/ai-skills/docs-copy/reference/banned-phrases.txt
  → Identical content to tools/lib/copy-governance/banned-phrases.txt

Commit message: "feat(copy-framework): add banned word and phrase reference files"

---

COMMIT 2 — Scripts

For each script below:
- Add the full JSDoc header block in the exact format of tests/run-all.js lines 1–12
- Use the @needs IDs from Decision C
- Update all require('./lib/...') paths to require('../../lib/copy-governance/...')
- Apply Decision B to lint-structure.js before committing

tools/scripts/lint-copy.js
  → Header + full file content from Doc 7, P1-B
  → @category: validator
  → @scope: tools/scripts
  → @owner: docs
  → @purpose-statement: Enforce banned word and phrase rules on MDX content files.
  → @pipeline: P1, P2, P3
  → @usage: node tools/scripts/lint-copy.js [file] [--changed-files] [--warn-only]

tools/scripts/lint-structure.js
  → Header + full file content from Doc 9, P2-D
  → @category: validator
  → @scope: tools/scripts
  → @owner: docs
  → @purpose-statement: Enforce structural rules on MDX content files.
  → @pipeline: P2, P3
  → @usage: node tools/scripts/lint-structure.js [file] [--changed-files] [--warn-only]
  → Apply Decision B (remove frontmatter checks if overlapping)

tools/scripts/lint-patterns.js
  → Header + full file content from Doc 8, P3-A
  → @category: validator
  → @scope: tools/scripts
  → @owner: docs
  → @purpose-statement: Enforce Tier 2 copy pattern rules on MDX content files.
  → @pipeline: P3
  → @usage: node tools/scripts/lint-patterns.js [file] [--changed-files] [--warn-only]

tools/scripts/pattern-observer.js
  → Header + full file content from Doc 8, P3-B
  → @category: reporter
  → @scope: tools/scripts
  → @owner: docs
  → @purpose-statement: Aggregate copy pattern violations across a tab or full v2 tree and emit a diagnostic report.
  → @pipeline: P3
  → @usage: node tools/scripts/pattern-observer.js --tab <name> | --all [--output <file>]
  → Update all output paths to tasks/reports/copy-governance/

Commit message: "feat(copy-framework): add lint scripts with required headers"

---

COMMIT 3 — Test suite

Create tests/unit/copy-lint.test.js
  → Must export: { runTests({ stagedOnly }) }
    returning: { errors: [], warnings: [] }
  → Read an existing tests/unit/*.test.js and match its exact structural pattern
  → Implements fixture-based checks from Doc 10 as the test body
  → When stagedOnly is true: scope checks to staged MDX files only
  → Do NOT create tests/copy-lint/run-all.js

Create tests/copy-lint-fixtures/
  → This directory is a development reference utility — not wired into the runner
  → tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
  → tests/copy-lint-fixtures/fixtures/pass/clean-reference.mdx
  → tests/copy-lint-fixtures/fixtures/pass/clean-concept.mdx
  → tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
  → tests/copy-lint-fixtures/fixtures/fail/banned-phrases.mdx
  → tests/copy-lint-fixtures/fixtures/fail/review-flag.mdx
  → tests/copy-lint-fixtures/fixtures/fail/currency.mdx
  → tests/copy-lint-fixtures/fixtures/fail/empty-table-cell.mdx
  → tests/copy-lint-fixtures/fixtures/fail/missing-frontmatter.mdx
  → tests/copy-lint-fixtures/fixtures/fail/accordion-url-only.mdx
  → tests/copy-lint-fixtures/fixtures/fail/hedge-note.mdx
  → tests/copy-lint-fixtures/fixtures/fail/conditional-if.mdx
  → tests/copy-lint-fixtures/fixtures/fail/not-construction.mdx
  → tests/copy-lint-fixtures/expected/banned-words.json
  → tests/copy-lint-fixtures/expected/banned-phrases.json
  → tests/copy-lint-fixtures/expected/review-flag.json
  → tests/copy-lint-fixtures/expected/currency.json
  → tests/copy-lint-fixtures/expected/empty-table-cell.json
  → tests/copy-lint-fixtures/expected/missing-frontmatter.json
  → tests/copy-lint-fixtures/expected/accordion-url-only.json
  → tests/copy-lint-fixtures/expected/hedge-note.json
  All fixture and expected file contents from Doc 10.

Update tests/run-all.js
  Add with existing requires at top of file:
    const copyLintTests = require('./unit/copy-lint.test');

  Add in runAllTests() immediately after the Style Guide Tests block:
    console.log('\n✍️  Running Copy Lint Tests...');
    const copyLintResult = normalizeSuiteResult(copyLintTests.runTests({ stagedOnly }));
    totalErrors += copyLintResult.errors.length;
    totalWarnings += copyLintResult.warnings.length;
    console.log(`   ${copyLintResult.errors.length} errors, ${copyLintResult.warnings.length} warnings`);

Update tests/run-pr-checks.js
  → Register copyLintTests using the exact registration pattern observed in Step 0 item 11
  → Scope to changed MDX files when stagedOnly is true

Commit message: "feat(copy-framework): add copy-lint test suite, wire into runner"

---

COMMIT 4 — SKILL.md files and README

ai-tools/ai-skills/docs-copy/README.md
  → Generate from Doc 1 summary section
  → Include: L0–L8 layer table, full file index of this directory,
    "start here" section pointing to SKILL.md and invocation-guide.md

ai-tools/ai-skills/docs-copy/SKILL.md
  → Full content from Doc 11, root SKILL.md section

ai-tools/ai-skills/docs-copy/skills/copy-rules.md
  → Full content from Doc 11, copy-rules section
  → Update any require paths to tools/lib/copy-governance/

ai-tools/ai-skills/docs-copy/skills/structure-rules.md
  → Full content from Doc 9, P2-A

ai-tools/ai-skills/docs-copy/skills/value-prop-check.md
  → Full content from Doc 9, P2-B

ai-tools/ai-skills/docs-copy/skills/persona-routing.md
  → Full content from Doc 9, P2-C

ai-tools/ai-skills/docs-copy/skills/review-gate.md
  → Full content from Doc 11, review-gate.md section

ai-tools/ai-skills/docs-copy/skills/iteration-diagnostic.md
  → Full content from Doc 8, P3-C

ai-tools/ai-skills/docs-copy/skills/pattern-observer.md
  → Full content from Doc 8, P3-D

ai-tools/ai-skills/docs-copy/skills/skill-docs.md
  → Full content from Doc 12, skill file section

ai-tools/ai-skills/docs-copy/reference/invocation-guide.md
  → Full content from Doc 11, invocation-guide.md section

Commit message: "feat(copy-framework): add SKILL.md files and README"

---

COMMIT 5 — Brief template and PR checklist

docs-guide/tooling/content-brief-template.md
  → Full content from Doc 7, P1-A
  → After creating, run: node tools/scripts/generate-docs-guide-indexes.js --write
  → Apply Decision D if a manifest entry is required
  → Then run: node tests/unit/docs-guide-sot.test.js
  → If SOT test fails: stop and report the output. Do not proceed.

.github/pull_request_template.md
  → Read the existing file (catalogued in Step 0 item 5)
  → Integrate the L5 checklist from Doc 7, P1-D into the existing structure
  → Do not duplicate any item already listed
  → Do not remove or reorder any existing content

Commit message: "feat(copy-framework): add brief template, integrate L5 into PR checklist"

---

COMMIT 6 — Report directory

tasks/reports/copy-governance/.gitkeep

Commit message: "feat(copy-framework): add copy-governance report directory"

---

VERIFICATION — run after all commits, report full output

1. node tests/run-all.js --staged
   Expected: copy-lint suite appears in output, zero new errors from committed files

2. node tests/unit/copy-lint.test.js
   Expected: all fixture tests pass

3. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
   Expected: zero errors

4. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
   Expected: BANNED_WORD errors matching tests/copy-lint-fixtures/expected/banned-words.json

5. node tests/unit/script-docs.test.js --staged
   Expected: all four new scripts pass header validation

6. node tests/unit/docs-guide-sot.test.js
   Expected: pass

Report the full output of each. If any check fails: stop and report.
Do not attempt to fix script logic or test infrastructure.

---

FORBIDDEN

- Do not modify any existing .mdx content files in v2/
- Do not modify docs.json
- Do not modify navigation-exclusions.json
- Do not modify the .allowlist file
- Do not create tests/copy-lint/run-all.js
- Do not create .github/workflows/lint-copy.yml
- Do not create tools/scripts/lib/ — use tools/lib/copy-governance/ instead
- Do not merge content from multiple source documents into a single file
- Do not reformat or rewrite file contents from the attached documents
```

---

## Adding new items after deployment

**New banned word or phrase:**
1. Edit `tools/lib/copy-governance/banned-words.txt` or `banned-phrases.txt`
2. Mirror to `ai-tools/ai-skills/docs-copy/reference/`
3. Add fail fixture + expected JSON in `tests/copy-lint-fixtures/`
4. Run `node tests/unit/copy-lint.test.js`

**New Tier 2 pattern:**
1. Add pattern object to `PATTERNS` array in `tools/scripts/lint-patterns.js`
2. Add fail fixture + expected JSON
3. Run `node tests/unit/copy-lint.test.js`
