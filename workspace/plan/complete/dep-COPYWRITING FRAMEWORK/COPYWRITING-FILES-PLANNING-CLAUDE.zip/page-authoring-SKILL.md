---
name: page-authoring
version: "1.0"
description: >-
  Comprehensive skill for writing new v2 documentation pages. Covers content standards, UX patterns, component usage, journey mapping, frontmatter, Mermaid theming, page type templates, and all repo-enforced rules. Do not use for prose style rules alone — see copy-rules for those.
---

# SKILL: Page Authoring for Livepeer v2 Docs

This skill contains everything needed to write a new MDX page in the Livepeer v2 documentation. It covers content strategy, UX patterns, component library usage, frontmatter standards, journey mapping, and hard repo rules. All rules are enforced by pre-commit hooks and tests.

---

## 1. HARD RULES (Will Break Build or Fail Review)

### Language
- **UK English spelling** throughout: colour, behaviour, organise, optimise, licence (noun), analyse, centre, programme (non-computing), modelling, labelled, travelled, cancelled, defence, catalogue.
- Exception: code identifiers, CLI flags, and proper nouns retain original spelling (`CenteredContainer`, `--color`, GitHub).

### Typography
- **NO em dashes** anywhere. Use hyphens or rewrite. Repo violation.
- **NO curly/smart quotes**. Straight quotes only.

### Styling
- **ZERO inline styles in MDX files**
- **NO hardcoded hex colours** — use `var(--lp-*)` CSS Custom Properties in JSX
- **NO ThemeData imports** — deprecated
- **NO Tailwind classes in MDX** — only within JSX components

### Imports
- **Absolute paths only**: `/snippets/components/...`
- **File extensions required**: always `.jsx` or `.js`
- **Do NOT import Mintlify globals** — `Card`, `Tabs`, `Tab`, `AccordionGroup`, `Accordion`, `Note`, `Warning`, `Tip`, `Info`, `Danger`, `Steps`, `Step`, `Columns` are globally available
- **Do NOT import React hooks** — globally available
- **JSX files cannot import other JSX files**

### Content Accuracy
- **On-chain vs off-chain = PAYMENT MODE** — describes how the gateway handles payments, NOT the workload type. Never write "off-chain AI gateway".
- **"Dual" = workload configuration** — running both video and AI from one node. NOT a third payment mode.
- **No speculative language** unless explicitly labelled
- **No fabricated metrics** — examples must be labelled "illustrative"

### Frontmatter (Required Fields)

```yaml
---
title: 'Full page title'
sidebarTitle: 'Short nav label'
description: >-
  One-sentence description for SEO and social preview (max ~160 chars).
keywords:
  - livepeer
  - [topic-specific keywords]
'og:image': /snippets/assets/site/og-image/en/[section].png
'og:image:alt': Livepeer Docs social preview image for [Section]
'og:image:type': image/png
'og:image:width': 1200
'og:image:height': 630
pageType: [overview|concept|tutorial|how_to|reference|faq|troubleshooting|changelog|glossary|landing]
audience: [gateway-operator|orchestrator|developer|delegator|general]
purpose: [orientation|evaluation|setup|reference|operations|decision]
status: current
lastVerified: YYYY-MM-DD
---
```

---

## 1b. FRONTMATTER-DRIVEN CONTENT RULES

The combination of `pageType`, `audience`, and `purpose` determines required content structure.
Every page must be written to the rules for its declared combination.

| `pageType` | `purpose` | Required opening | Required structure | Banned |
|---|---|---|---|---|
| `guide` | `orientation` | Problem being solved → options with operator-benefit framing | Options table → each option: benefit → mechanism → requirements → decision aid | Technical internals before benefit; mechanism as opening |
| `guide` | `setup` | Prerequisite state the operator must be in | Numbered steps → expected output per step → verification | Conceptual background at top; benefit framing mid-step |
| `guide` | `operations` | The task being accomplished and its outcome | Step-by-step with expected state after each step | Long concept sections; mechanism-first openings |
| `guide` | `decision` | The decision and its stakes for the operator | Decision criteria → options with operator-framed tradeoffs → decision aid | Technical specs without operator-framed consequence |
| `concept` | `evaluation` | What the operator needs to believe to proceed | Benefit → mechanism → evidence → competitive context | Setup steps; command syntax |
| `concept` | `orientation` | What this thing is and why the operator encounters it | Identity → role in system → what the operator controls | Deep internals; pricing; setup |
| `reference` | any | The exact item being referenced | Signature/flag/value → description → example | Narrative prose; benefit framing |

**Audience modifiers:**

| `audience` | Assumed knowledge | Terminology level |
|---|---|---|
| `orchestrator` | GPU operation, basic crypto, go-livepeer installed | Full Livepeer terminology; no explanation of LPT, ETH, active set |
| `gateway-operator` | Running infrastructure, API integration | Full Livepeer terminology; no explanation of payment modes |
| `developer` | Code, APIs, SDKs | Technical but no assumed Livepeer internals |
| `delegator` | Crypto wallets, staking concepts | No assumed go-livepeer knowledge |
| `general` | No assumed knowledge | Define all terms |

---

## 2. PAGE TYPES AND THEIR PURPOSE

| Type | Question it answers | Must include | Must exclude |
|------|-------------------|--------------|--------------|
| **Landing** | Where do I go? | Value prop, visual nav cards, entry path choosers | Deep technical explanation, setup steps |
| **Overview/Role** | What IS this? | Identity, evolution, sub-roles, mental models, network diagrams | Installation steps, pricing depth |
| **Concept** | How does it WORK? | Internals, layer position, request flow, system interactions | Installation commands, operational playbooks |
| **Tutorial** | How do I start? | Prerequisite checklist, minimum setup, first-job objective, verification | Every edge case, deep background |
| **How-to** | How do I do X? | Step-by-step workflows, expected outcomes, config examples | Conceptual marketing copy |
| **Reference** | What are the exact details? | Flags, commands, parameters, examples, schemas | Setup walkthroughs, conceptual framing |
| **Troubleshooting** | Why is this broken? | Common issue → check → fix format | Broad conceptual explanation |

### The 4-Page Concepts Pattern

Every tab has 4 concepts pages:

| Page | Question | What belongs here |
|------|----------|------------------|
| **Role** | What IS it? | Identity, evolution, sub-roles, mental model analogies |
| **Capabilities** | What can it DO? | Workload types, supported features, selection mechanics |
| **Architecture** | How does it WORK? | Layer position, system interactions, request flow, internal components |
| **Economics** | Should I CARE? | Revenue streams, cost structure, payment flow, pricing config |

---

## 3. UX PATTERNS (Gold Standard)

### Page Skeleton

```mdx
---
[frontmatter]
---

import { LinkArrow } from '/snippets/components/primitives/links.jsx'
import { StyledTable, TableRow, TableCell } from '/snippets/components/layout/tables.jsx'
import { CustomDivider } from '/snippets/components/primitives/divider.jsx'
import { ScrollableDiagram } from '/snippets/components/content/zoomableDiagram.jsx'
import { CenteredContainer, BorderedBox } from '/snippets/components/layout/containers.jsx'

<CenteredContainer style={{ width: '90%' }}>
  <Tip>[One sentence: the single most important thing the reader should know]</Tip>
</CenteredContainer>

---

[2-3 sentence narrative intro establishing context and scope]

<CustomDivider middleText="[Section Label]" />

## [First Major Section]

[Prose — ALWAYS prose before any visual]

[Visual: StyledTable, Mermaid, or code block]

[Prose after visual explaining implications]

<CustomDivider middleText="[Section Label]" />

## [Second Major Section]

[Continue pattern: prose → visual → prose]

<CustomDivider />

## Related Pages

<CardGroup cols={2}>
  <Card title="[Title]" icon="[icon]" href="[path]" arrow horizontal>
    [1-2 sentence description]
  </Card>
</CardGroup>
```

### Rules
- `<CustomDivider middleText="Label" />` between every major section; no middleText on final divider
- Always open with `<CenteredContainer>` + `<Tip>` containing the core value prop
- NEVER place a diagram, table, or code block without preceding prose — **Explain → Show → Interpret**
- Always end with `## Related Pages` in a `<CardGroup cols={2}>` (or `cols={3}` for reference/navigator pages)

---

## 4. COMPONENT USAGE GUIDE

### Import Reference

| Need | Component | Import path |
|------|-----------|-------------|
| Section dividers | `CustomDivider` | `/snippets/components/primitives/divider.jsx` |
| Data tables | `StyledTable`, `TableRow`, `TableCell` | `/snippets/components/layout/tables.jsx` |
| Cross-references | `LinkArrow` | `/snippets/components/primitives/links.jsx` |
| Zoomable diagrams | `ScrollableDiagram` | `/snippets/components/content/zoomableDiagram.jsx` |
| Centred content | `CenteredContainer` | `/snippets/components/layout/containers.jsx` |
| Sequential steps | `StyledSteps`, `StyledStep` | `/snippets/components/layout/steps.jsx` |

### Patterns by Use Case

**Binary comparison:**
```mdx
<Tabs>
  <Tab title="Option A">[Bullet list with feature specs]</Tab>
  <Tab title="Option B">[Bullet list with feature specs]</Tab>
</Tabs>
```

**Detailed spec comparison:**
```mdx
<StyledTable variant="bordered">
  <thead>
    <TableRow header>
      <TableCell header>Factor</TableCell>
      <TableCell header>Option A</TableCell>
      <TableCell header>Option B</TableCell>
    </TableRow>
  </thead>
  <tbody>
    <TableRow>
      <TableCell>**Row label**</TableCell>
      <TableCell>Value</TableCell>
      <TableCell>Value</TableCell>
    </TableRow>
  </tbody>
</StyledTable>
```

**Mental model analogies:**
```mdx
<AccordionGroup>
  <Accordion title="From a Cloud Background?" icon="cloud">
    [Prose analogy]
  </Accordion>
  <Accordion title="From an Ethereum Background?" icon="coin">
    [Prose analogy]
  </Accordion>
</AccordionGroup>
```

**Sequential journey:**
```mdx
<StyledSteps iconColor="#2d9a67" titleColor="var(--accent)">
  <StyledStep title="Step Name" icon="icon-name">
    [Description with LinkArrow cross-references]
  </StyledStep>
</StyledSteps>
```

**Inline cross-reference:**
```mdx
See <LinkArrow href="/v2/path/to/page" label="Page Name" newline={false} /> for details.
```

---

## 5. MERMAID DIAGRAM STANDARDS

### Required Theme Block
Every Mermaid diagram must use:

```
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#1a1a1a', 'primaryTextColor': '#fff', 'primaryBorderColor': '#2d9a67', 'lineColor': '#2d9a67', 'secondaryColor': '#0d0d0d', 'tertiaryColor': '#1a1a1a', 'background': '#0d0d0d', 'fontFamily': 'system-ui' }}}%%
```

### Colour Classes for Dual Pipelines
```
classDef default fill:#1a1a1a,color:#fff,stroke:#2d9a67,stroke-width:2px
classDef video fill:#1a1a1a,color:#fff,stroke:#3b82f6,stroke-width:2px
classDef ai fill:#1a1a1a,color:#fff,stroke:#a855f7,stroke-width:2px
```

### Diagram Types by Content

| Content need | Type | Use for |
|-------------|------|---------|
| Evolution/history | `timeline` | Role pages |
| System layers | `flowchart TB` | Architecture pages |
| Request lifecycle | `sequenceDiagram` | Architecture pages |
| Decision tree | `flowchart TD` | Navigator pages |
| Payment/revenue flow | `flowchart LR` | Economics pages |

Wrap any diagram that may exceed viewport height:
```mdx
<ScrollableDiagram title="Descriptive Title" maxHeight="600px">
  [Mermaid block]
</ScrollableDiagram>
```

---

## 6. WRITING STYLE

### Voice
- Direct, technical, actionable
- Second person ("your gateway", "you configure")
- Present tense for current behaviour, past tense for history
- Active voice preferred

### Structure
- Short paragraphs (2–4 sentences max)
- Bullet lists for 3+ parallel items
- Numbered lists only for sequential steps
- Bold for key terms on first use: **probabilistic micropayment tickets**
- Code formatting for CLI flags, file names, config values: `-maxPricePerUnit`, `aiModels.json`

### Punctuation
- Hyphens (-) for all dashes — NEVER em dashes
- Oxford comma: "video, AI, and BYOC"
- Sentence case headings: "How gateways choose orchestrators"

### Terminology
- "gateway" not "broadcaster"
- "orchestrator" not "transcoder" (unless referring to the transcoder worker process specifically)
- "on-chain gateway" / "off-chain gateway" (payment modes)
- "dual-workload configuration" — NOT "dual mode" or "dual gateway type"
- "active set" (the pool of eligible orchestrators)
- Livepeer (capital L, no hyphen)
- go-livepeer (lowercase g, hyphenated)
- LPT (the token), ETH (the currency), Arbitrum One (the L2 chain)

---

## 7. PRE-COMMIT CHECKS

Validated by git hooks on every commit:
1. Deprecated ThemeData imports — blocked
2. Hardcoded hex theme colours — warned
3. Relative snippets imports — flagged
4. Unnecessary global imports — warned
5. MDX syntax validation
6. JSON syntax validation

```bash
npm test              # All tests
npm run test:style    # Style guide validation
npm run test:mdx      # MDX syntax
npm run test:spell    # UK English spelling
npm run test:quality  # Alt text, links, frontmatter
```

---

## 8. PRE-SUBMIT CHECKLIST

- [ ] All required frontmatter fields present
- [ ] UK English spelling throughout
- [ ] No em dashes anywhere
- [ ] No inline styles in MDX
- [ ] All imports use absolute paths with file extensions
- [ ] No imports of Mintlify globals
- [ ] Opening hook: CenteredContainer + Tip
- [ ] CustomDividers between all major sections
- [ ] Prose before every diagram, table, and code block
- [ ] Related Pages CardGroup at bottom
- [ ] All cross-references use LinkArrow (inline) or Card (navigational)
- [ ] Mermaid diagrams use standard dark theme block
- [ ] On-chain/off-chain described as payment modes only
- [ ] No speculative claims without explicit labels
- [ ] Page answers ONE question matching its page type
- [ ] Content does not duplicate another page's scope
