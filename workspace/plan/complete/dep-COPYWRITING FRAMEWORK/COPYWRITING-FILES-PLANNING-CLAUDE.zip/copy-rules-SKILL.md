---
name: copy-rules
description: >-
  Applies sentence-level copy rules to Livepeer v2 documentation.
  Use when drafting, editing, or reviewing any documentation prose.
  Enforces banned constructions, value-proposition-first structure,
  frontmatter description rules, jargon detection, and the master
  sentence test. Do not use for MDX mechanics — see page-authoring.
---

# SKILL: Copy Rules for Livepeer v2 Docs

Documentation copy must give the operator something they can act on, believe, or use to make a decision — stated directly, with no qualifications, contrasts, or conditions. Apply every rule below to every sentence before it ships.

---

## The master test

Before any sentence is written, ask:
Does this sentence give the operator something they can act on, believe, or use to make a decision — stated directly, with no qualifications, contrasts, or conditions?
If no: rewrite or delete.

---

## Frontmatter description field

The `description` field is SEO copy and social preview text. Rules:

- Opens with the operator outcome or the problem the page solves — not a list of what the page contains
- Maximum 160 characters
- No em-dashes
- No "The X alternatives to..." or "How to..." constructions — these announce content rather than deliver value
- No passive voice

**Banned pattern:** `description: The three alternatives to running go-livepeer as a single-process deployment - pool worker, O-T split, and Siphon.`
**Required pattern:** `description: Choose the right deployment path for your hardware, stake position, and operational requirements.`

---

## Section opening order

Every section describing a deployment option, capability, or path must follow this order:

1. What the operator gets or avoids — the benefit or the problem solved
2. Technical mechanism that produces it
3. Requirements or constraints

Never open a section with a command, flag name, process name, or technical description. The mechanism is not the value.

**Banned:** `A pool worker runs go-livepeer -transcoder against an existing pool operator's Orchestrator address.`
**Required:** `The pool worker path earns from GPU compute without acquiring LPT or managing on-chain operations. [Then: mechanism. Then: requirements.]`

---

## Jargon and undefined terms

Any term that is not standard English, standard Linux/Go tooling, or a term defined in the Livepeer glossary must be:

1. Defined in full on first use in body prose
2. Defined before it appears in a heading, table cell, or diagram label

**Banned:** Using "O-T Split" as a section heading before defining what O-T means.
**Required:** Define the term in the opening sentence of its section, then use the abbreviation.

When a new coined term or abbreviation is introduced on a page, add it to the `glossary.mdx` file in the parent folder of the page being reviewed. If no glossary exists in that folder, flag with `{/* REVIEW: add to nearest glossary.mdx */}`.

---

## Comparative headers and lead-ins

Section headers and bold lead-ins must not use comparative or differential framing.

**Banned patterns:**
- "What changes from [X]:"
- "Unlike [X],"
- "Compared to [X],"
- "The difference from [X]:"
- "How this differs from [X]:"

These assume the reader knows X and frame the current option as secondary. State what this option does directly.

**Banned:** `**What changes from the single-process deployment:**`
**Required:** `**How the O-T split runs:**`

---

## Banned words

Never use in body prose:

effectively, essentially, basically, meaningful, significant, real (as intensifier), various, several, simply, obviously, clearly, just (as minimiser)

---

## Banned phrases

- "This page covers / explains / describes"
- "This section covers"
- "In this guide"
- "The reason is straightforward"
- "Understanding X is essential"
- "It is important to note"
- "As mentioned above"
- "among other factors" / "and so on" / "etc."
- "low but not zero"
- "not just [X]"
- "rather than"
- "what it takes"
- "once [X] is stable"
- "it should be noted"
- "not preference"
- "depends on various factors"
- "can generate" / "may produce" in value claims

---

## Banned constructions

**`not [X]` in value statements**
Defines value by contrast. Rewrite as a positive assertion. Delete the contrast.

**`if [condition]` in body prose**
Conditional gatekeeping. State the condition as a fact or remove it.
Exception: code blocks and prerequisite lists.

**`[value statement] — if [condition]`**
Undercuts the value in the same breath. Split into two sentences. Value first. Requirement second.

**`rather than`**
Contrast-by-diminishment. Delete the contrast clause. State the positive directly.

**`This page [verb]`**
Announces content instead of delivering it. Delete. Start with the content.

**`what it takes`**
Hurdle framing. State the requirements directly.

**`consistently` without a number**
Vague standard. Add a threshold or rewrite.

**`can/may [verb]` in value claims**
Weakened assertion. Assert directly or delete.

---

## Structural rules

- One paragraph, one job
- Lead sentence states the operator benefit; remaining sentences explain the mechanism, then the requirements
- Final sentence: fact, number, or next step — never a hedge or restatement
- Prose that restates a table or diagram is deleted
- High-value URLs and commands appear in body copy — not only inside accordions
- Every path introduced is developed on the page or linked

---

## Currency

All monetary examples use USD. If content is region-scoped, declare the region once at section opening.

---

## REVIEW flags

`{/* REVIEW: */}` flags must never appear in rendered content. Any page with an unresolved REVIEW flag in a decision-critical position is blocked from merge.
