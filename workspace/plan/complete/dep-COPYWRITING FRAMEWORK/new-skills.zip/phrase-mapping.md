# Phrase Mapping — Weak Patterns and Preferred Replacements
**docs-guide/quality-testing/phrase-mapping.md**
**Living document — add entries from review passes**

---

## How to use this file

When a review pass finds a recurring weak construction not on the banned list, add a row here. This file feeds into the copy-rules SKILL.md and the lint script banned-phrases.txt. A pattern that appears 3+ times across different pages should be promoted to the banned list.

Format: pattern | why it fails | preferred replacement

---

## Comparative and differential framing

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| "What changes from X" | Frames the reader relative to something they may not have | State what this option does directly |
| "Unlike X" | Defines by contrast, not by value | State the benefit; let the contrast be implicit |
| "Compared to X" | Same as above | Lead with the outcome; reference the alternative only if essential |
| "Differences from X" | Differential framing, not value framing | State what this path delivers |
| "The key difference is" | Signals comparison-first thinking | State the thing itself |

---

## Announcement and throat-clearing

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| "This section walks you through" | Announces instead of delivers | Delete; start with the content |
| "Before we begin" | Preamble | Delete; state the prerequisite directly |
| "Now that you understand X" | Patronising | Delete; proceed to the next point |
| "As you can see" | Redundant | Delete |
| "In order to" | Verbose | "To" |
| "It is worth noting that" | Throat-clearing | Delete; state the point |

---

## Mechanism before benefit

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| "[Tool] runs [flag] against [address]" as opening sentence | Opens with mechanism, not outcome | Open with what the operator gets: "Earn from GPU compute without acquiring LPT or managing on-chain operations." |
| "[Component] handles [list of operations]" as opening | Describes the tool, not the operator | Open with why the operator cares |
| "The [thing] separates what [other thing] runs together" | Defines by structural difference | State what the operator gains from the separation |

---

## Vague decision language

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| "Use this when:" followed by multiple conditions | Reads as a checklist, not a decision | One sentence stating the primary fit condition |
| "This may be appropriate if" | Hedged recommendation | "Use this when [specific condition]" |
| "It depends on your situation" | Refuses to make the decision | Give the decision matrix |
| "There are several options" | Vague quantity, no direction | Name the options immediately |

---

## Undefined terms introduced without definition

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| Abbreviation used before definition (e.g. "O-T split" as heading) | Reader has no referent | Write out in full on first prose use: "Orchestrator-Transcoder split (O-T split)" |
| Coined term in table cell before prose definition | Table is scanned before read | Define in prose intro before the table |
| Technical flag name as subject of opening sentence | Assumes reader knows the flag | Name the capability; introduce the flag as the implementation |

---

## Frontmatter description anti-patterns

| Pattern | Why it fails | Preferred replacement |
|---|---|---|
| "The X alternatives to running Y as a Z" | Lists content, not value | "Choose the right deployment path for your GPU setup and staking situation." |
| "How to configure X" as description | Describes the page type, not the outcome | State the outcome the operator reaches |
| "Overview of X, Y, and Z" | Table of contents as description | One sentence of operator value |

---

## Entries to promote to banned list (3+ occurrences confirms promotion)

| Pattern | Occurrences | Files | Promote? |
|---|---|---|---|
| "What changes from [X]" | 2 | setup-options.mdx | Monitor |
