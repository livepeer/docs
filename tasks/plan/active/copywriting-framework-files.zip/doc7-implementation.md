# Implementation — Highest Value Items
**Livepeer Docs Copy Framework — Document 7**
**Version 1.0 — March 2026**

---

## Scope

This document implements the four Phase 1 items in full, ready for immediate use:

- **P1-A:** Brief template with L0/L1 gates
- **P1-B:** Banned word/phrase reference files + lint-copy.js
- **P1-C:** copy-rules SKILL.md
- **P1-D:** L5 PR checklist

Each section contains the actual artefact, not a description of it.

---

---

# P1-A: Brief Template with L0/L1 Gates

**File:** `content-brief-template.md` (replaces existing template)
**Usage:** Required for every new content brief before any drafting or Codex task launch.

---

```markdown
# Content Brief — [PAGE TITLE]

**Tab:** [GPU Nodes / Gateways / Developers / Other]
**Page type:** [guide / evaluation / concept / reference / how-to]
**Estimated audience:** [describe in functional terms: hardware profile, goal, LPT position]
**Brief author:**
**Date:**

---

## ⛔ GATE: L0 — Value Proposition
Complete all four before proceeding. If any cannot be answered, stop.
Escalate to product owner. Do not draft until answered.

**Q1 — Operator outcome**
What does this product, feature, or section do for the operator?
One sentence. No conditionals. No `if`, `can`, `may`, `depends on`.

> Answer:

---

**Q2 — Featured (majority) path**
Which operator profile is already succeeding with this, and what does their
setup look like? This is the default story. Edge cases are variants.

> Answer:

---

**Q3 — Reader's real alternative**
What would the reader do instead of this?
Defines the competitive context this page must address.

> Answer:

---

**Q4 — Required belief**
What does the reader need to believe to take the next step?
One sentence. A belief, not a mechanism.

> Answer:

---

**L0 self-check before proceeding:**
- [ ] Q1 contains no conditional (if / can / may / depends on)
- [ ] Q2 describes the majority path, not an edge case
- [ ] Q3 is specific, not blank or vague
- [ ] Q4 is a belief statement, not a mechanism description

If any box is unchecked: stop. Return to product owner.

---

## ⛔ GATE: L1 — Persona Path Mapping
Complete before drafting. Every row must be served by the page
or explicitly routed to a linked page.

| Operator profile (hardware / LPT / goal) | Primary question on arrival | What this page must give them | Served here or linked? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

---

## Content Sequence Plan (L2)

Mark the sequence before writing. This is the order sections appear on the page.

- [ ] **1. Operator outcome** — value kept, one sentence, no conditionals
- [ ] **2. Featured path** — majority model, described in full
- [ ] **3. Variants** — alternative paths with specific entry requirements
- [ ] **4. Economics** — concrete figures, no hedging
- [ ] **5. Decision aid** — complete, no empty cells, no REVIEW flags
- [ ] **6. Staged action path** — numbered, zero to first outcome
- [ ] **7. Next page link** — one link, correct next step for primary reader

---

## Scope

**In scope:**


**Out of scope (explicit):**


---

## SME Review Items
List any claims that require SME verification before publishing.
These are NOT placeholders — each must be resolved before the page merges.

| Claim | SME required | Status |
|---|---|---|
| | | Unverified |

---

## Research Sources
List sources used before drafting. Do not draft without completing this section.


---

## Forbidden
List files this brief must NOT touch (scope protection):


---

## Step 0 — Verification (Codex)
Before writing any content, Codex must verify:
1. The base branch is current (`docs-v2`)
2. Target file paths exist as expected
3. No conflicting in-progress tasks on the same files
4. L0 and L1 sections above are complete

If any Step 0 check fails: stop and report. Do not proceed.
```

---

---

# P1-B: Banned Reference Files + lint-copy.js

## Reference File 1: banned-words.txt

**Path:** `tools/scripts/lib/banned-words.txt`

```
effectively
essentially
basically
meaningful
significant
real
various
several
simply
obviously
clearly
```

> Note: `just` and `real` as minimisers/intensifiers are pattern-matched in context,
> not exact-matched, to avoid false positives in technical phrases.

---

## Reference File 2: banned-phrases.txt

**Path:** `tools/scripts/lib/banned-phrases.txt`

```
This page covers
This page explains
This page describes
This section covers
This section explains
In this guide
The reason is straightforward
Understanding X is essential
It is important to note
As mentioned above
among other factors
and so on
low but not zero
not just
rather than
what it takes
once X is stable
it should be noted
not preference
depends on various
can generate
may produce
```

---

## lint-copy.js

**Path:** `tools/scripts/lint-copy.js`

```javascript
#!/usr/bin/env node

/**
 * lint-copy.js
 * Livepeer Docs Copy Framework — L4 enforcement
 *
 * Tier 1: Exact banned word and phrase matches — exits with code 1 (blocks merge)
 * Tier 2: Pattern matches — exits with code 0 but prints warnings (human sign-off required)
 *
 * Usage:
 *   node tools/scripts/lint-copy.js [file or glob]
 *   node tools/scripts/lint-copy.js --changed-files   (reads from git diff)
 *
 * Options:
 *   --tier1-only    Run Tier 1 checks only
 *   --warn-only     Never exit 1 (use for local preview)
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ─── Configuration ────────────────────────────────────────────────────────────

const BANNED_WORDS = fs
  .readFileSync(path.join(__dirname, 'lib/banned-words.txt'), 'utf8')
  .split('\n')
  .map(w => w.trim())
  .filter(Boolean);

const BANNED_PHRASES = fs
  .readFileSync(path.join(__dirname, 'lib/banned-phrases.txt'), 'utf8')
  .split('\n')
  .map(p => p.trim())
  .filter(Boolean);

// Tier 2 pattern checks — warning only
const TIER2_PATTERNS = [
  {
    id: 'CONDITIONAL_IF',
    label: '"if" in body prose — check for conditional gatekeeping',
    // Matches "if" outside code fences and JSX comment blocks
    regex: /(?<!\/\/.*)\bif\b(?![^`\n]*`[^`\n]*$)/gim,
    exclude: /```[\s\S]*?```|{\/\*[\s\S]*?\*\/}/g,
  },
  {
    id: 'NOT_CONSTRUCTION',
    label: '"not [noun/verb]" — restate as positive claim',
    regex: /\bnot\s+[a-z]/gim,
    exclude: /```[\s\S]*?```|{\/\*[\s\S]*?\*\/}/g,
  },
  {
    id: 'WEAKENED_VALUE',
    label: '"can/may [verb]" in apparent value claim — assert directly or delete',
    regex: /\b(can|may)\s+[a-z]+/gim,
    exclude: /```[\s\S]*?```|{\/\*[\s\S]*?\*\/}/g,
  },
  {
    id: 'SELF_UNDERMINING_VALUE',
    label: '"[value] — if" construction — split into two sentences',
    regex: /—\s+if\b/gim,
    exclude: /```[\s\S]*?```/g,
  },
  {
    id: 'CONSISTENTLY_NO_NUMBER',
    label: '"consistently" without adjacent number — add threshold or rewrite',
    // Flag "consistently" not followed by a digit within 60 chars
    regex: /\bconsistently\b(?!.{0,60}\d)/gim,
    exclude: /```[\s\S]*?```/g,
  },
  {
    id: 'CURRENCY_NON_USD',
    label: 'Non-USD currency outside declared regional scope — use USD',
    regex: /[£€¥]/gm,
    exclude: null,
  },
  {
    id: 'REVIEW_FLAG_RENDERED',
    label: 'Unresolved REVIEW flag in rendered content — BLOCKS MERGE',
    regex: /\{\/\*\s*REVIEW:/gm,
    exclude: null,
    tier1: true, // Escalate this Tier 2 pattern to Tier 1 block
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getFiles() {
  const args = process.argv.slice(2);
  if (args.includes('--changed-files')) {
    const diff = execSync('git diff --cached --name-only --diff-filter=ACM', {
      encoding: 'utf8',
    });
    return diff
      .split('\n')
      .filter(f => f.endsWith('.mdx') || f.endsWith('.md'))
      .filter(fs.existsSync);
  }
  const target = args.find(a => !a.startsWith('--')) || 'v2/**/*.mdx';
  // Simple glob expansion — for production use, replace with glob package
  if (fs.existsSync(target)) return [target];
  return [];
}

function stripCodeAndComments(content) {
  return content
    .replace(/```[\s\S]*?```/g, '[CODE_BLOCK]')
    .replace(/`[^`]+`/g, '[INLINE_CODE]')
    .replace(/\{\/\*[\s\S]*?\*\/\}/g, '[JSX_COMMENT]');
}

function getLines(content) {
  return content.split('\n');
}

// ─── Checks ───────────────────────────────────────────────────────────────────

function checkBannedWords(content, filePath) {
  const errors = [];
  const lines = getLines(content);
  const stripped = getLines(stripCodeAndComments(content));

  lines.forEach((line, i) => {
    const cleanLine = stripped[i];
    BANNED_WORDS.forEach(word => {
      const regex = new RegExp(`\\b${word}\\b`, 'i');
      if (regex.test(cleanLine)) {
        errors.push({
          tier: 1,
          file: filePath,
          line: i + 1,
          id: 'BANNED_WORD',
          label: `"${word}" — delete or restate directly`,
          text: line.trim().slice(0, 80),
        });
      }
    });
  });
  return errors;
}

function checkBannedPhrases(content, filePath) {
  const errors = [];
  const lines = getLines(content);
  const stripped = getLines(stripCodeAndComments(content));

  lines.forEach((line, i) => {
    const cleanLine = stripped[i];
    BANNED_PHRASES.forEach(phrase => {
      if (cleanLine.toLowerCase().includes(phrase.toLowerCase())) {
        errors.push({
          tier: 1,
          file: filePath,
          line: i + 1,
          id: 'BANNED_PHRASE',
          label: `"${phrase}" — see banned phrases list`,
          text: line.trim().slice(0, 80),
        });
      }
    });
  });
  return errors;
}

function checkTier2Patterns(content, filePath) {
  const warnings = [];
  const lines = getLines(content);

  TIER2_PATTERNS.forEach(pattern => {
    let cleanContent = content;
    if (pattern.exclude) {
      cleanContent = content.replace(pattern.exclude, match =>
        ' '.repeat(match.length)
      );
    }
    const cleanLines = getLines(cleanContent);

    cleanLines.forEach((line, i) => {
      if (pattern.regex.test(line)) {
        warnings.push({
          tier: pattern.tier1 ? 1 : 2,
          file: filePath,
          line: i + 1,
          id: pattern.id,
          label: pattern.label,
          text: lines[i].trim().slice(0, 80),
        });
      }
      pattern.regex.lastIndex = 0;
    });
  });
  return warnings;
}

// ─── Runner ───────────────────────────────────────────────────────────────────

function run() {
  const args = process.argv.slice(2);
  const warnOnly = args.includes('--warn-only');
  const tier1Only = args.includes('--tier1-only');
  const files = getFiles();

  if (files.length === 0) {
    console.log('lint-copy: no files to check.');
    process.exit(0);
  }

  let tier1Count = 0;
  let tier2Count = 0;

  files.forEach(filePath => {
    const content = fs.readFileSync(filePath, 'utf8');

    const t1Errors = [
      ...checkBannedWords(content, filePath),
      ...checkBannedPhrases(content, filePath),
    ];

    const t2Warnings = tier1Only ? [] : checkTier2Patterns(content, filePath);

    // Escalated Tier 2s (e.g. REVIEW_FLAG_RENDERED) count as Tier 1
    const allTier1 = [
      ...t1Errors,
      ...t2Warnings.filter(w => w.tier === 1),
    ];
    const allTier2 = t2Warnings.filter(w => w.tier === 2);

    if (allTier1.length > 0) {
      console.error(`\n❌  ${filePath} — ${allTier1.length} BLOCKING error(s):\n`);
      allTier1.forEach(e => {
        console.error(`  [L${e.line}] ${e.id}: ${e.label}`);
        console.error(`        → "${e.text}"`);
      });
      tier1Count += allTier1.length;
    }

    if (allTier2.length > 0) {
      console.warn(`\n⚠️   ${filePath} — ${allTier2.length} warning(s) (human sign-off required):\n`);
      allTier2.forEach(w => {
        console.warn(`  [L${w.line}] ${w.id}: ${w.label}`);
        console.warn(`        → "${w.text}"`);
      });
      tier2Count += allTier2.length;
    }
  });

  console.log(`\nlint-copy complete: ${tier1Count} blocking, ${tier2Count} warnings across ${files.length} file(s).`);

  if (tier1Count > 0 && !warnOnly) {
    console.error('\nMerge blocked. Resolve all blocking errors before re-submitting.');
    process.exit(1);
  }

  process.exit(0);
}

run();
```

---

---

# P1-C: copy-rules SKILL.md

**Path:** `ai-tools/ai-skills/docs-copy/skills/copy-rules.md`

```markdown
---
name: copy-rules
version: 1.0
description: >
  Sentence-level copy rules for Livepeer documentation.
  Load this skill before any content drafting, editing, or review task.
  Apply every rule to every sentence before it is written or submitted.
---

# Copy Rules — L4 Enforcement

## The master test
Before any sentence ships, ask:
Does this sentence give the operator something they can act on, believe,
or use to make a decision — stated directly, no qualifications, no contrasts,
no conditions?
If no: rewrite or delete.

---

## Banned words
Do not use these words in body prose under any circumstance.
If you find yourself reaching for one, restate the sentence without it.

effectively, essentially, basically, meaningful, significant, real (as intensifier),
various, several, simply, obviously, clearly, just (as minimiser)

---

## Banned phrases
Do not use any of the following in any form:

- "This page covers / explains / describes"
- "This section covers"
- "In this guide"
- "The reason is straightforward"
- "Understanding X is essential"
- "It is important to note"
- "As mentioned above"
- "among other factors"
- "and so on" / "etc."
- "low but not zero"
- "not just [X]"
- "rather than"
- "what it takes"
- "once [X] is stable"
- "it should be noted"
- "not preference"
- "depends on various factors"
- "can generate" / "may produce" in value claims

---

## Banned constructions

**`not [X]` in value statements**
Defines value by what it is not. Forces the reader to hold two things to understand one.
Rewrite as a positive assertion. Delete the contrast.

**`if [condition]` in body prose**
Conditional gatekeeping. Makes the reader responsible for a knowledge gap the docs should close.
State the condition as a fact, or remove it. Exception: code blocks and prerequisite lists.

**`[value statement] — if [condition]`**
Undercuts the value statement in the same breath.
Split into two sentences. Value first. Requirements second. No dash.

**`rather than`**
Contrast-by-diminishment. Same failure as `not [X]`.
Delete the contrast clause. State the positive directly.

**`This page [verb]`**
Announces content instead of delivering it.
Delete. The page is already open. Start with the content.

**`what it takes`**
Hurdle framing. Implies the reader may not qualify.
State the requirements directly.

**`consistently` without a number**
Vague operational standard.
Add the number or rewrite.

**`can/may [verb]` in value claims**
Weakened assertion.
Assert directly or delete the claim.

---

## Currency rule
All monetary examples use USD by default.
If content is explicitly region-scoped, declare the region once at section opening
and use local currency consistently within that scope only.
Mixed currencies within one example are banned.

---

## REVIEW flags
`{/* REVIEW: */}` flags are internal signals only.
They must never appear in rendered content.
Any page with an unresolved REVIEW flag in a decision-critical position
(table cell, numbered step, decision matrix) is blocked from merge.

---

## Structural rules (summary)
Full rules in structure-rules.md. Apply these minimally here:

- One paragraph, one job
- Lead sentence states the fact; remaining sentences extend or evidence it
- Final sentence: fact, number, or next step — never a hedge or restatement
- Tables and diagrams stand alone; prose restating either is deleted
- High-value URLs and commands appear in body copy — not only inside accordions

---

## What this skill does not govern
- Content accuracy (SME review, separate gate)
- Page structure and sequence (load structure-rules.md)
- Value proposition definition (load value-prop-check.md)
- Persona routing (load persona-routing.md)
```

---

---

# P1-D: L5 PR Checklist

**File:** `.github/pull_request_template.md` (docs-v2 addition)

```markdown
## Copy Governance Gate — L5

Complete before requesting review. Every item must be checked or the PR is not ready.

### Auto-checked by CI (lint-copy.js + lint-structure.js)
- [ ] No Tier 1 banned words or phrases
- [ ] No unresolved `{/* REVIEW: */}` flags in rendered content
- [ ] No non-USD currency outside declared regional scope
- [ ] No empty cells in decision tables
- [ ] `pageType`, `audience`, `lastVerified` present in frontmatter

### Human review required

**Sequence (L2)**
- [ ] Page opens with operator outcome — value kept, no conditionals
- [ ] Majority operator path is featured before variants
- [ ] Introduced paths are developed on-page or linked

**Completeness (L3)**
- [ ] Decision aids (tables, matrices, flowcharts) are complete — no placeholders
- [ ] Every warning or consequence is followed by a prevention action and link
- [ ] Primary actions and URLs appear in body copy (not only in accordions)

**Tone (L4)**
- [ ] No sentence ends on a hedge, disclaimer, or restatement
- [ ] No section ends with a Note that apologises rather than forward-points

**Brief compliance**
- [ ] L0 (Q1–Q4) was completed before drafting
- [ ] L1 persona mapping table was completed before drafting

---

**If any structural item fails:** fix before requesting review — do not ask reviewer to identify the issue.

**If the same section fails review twice:** do not attempt a third fix. Escalate to documentation lead for L6 diagnostic.
```
