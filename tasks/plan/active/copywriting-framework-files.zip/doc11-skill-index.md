# SKILL.md Root Index & Composable Skill File Set
**Livepeer Docs Copy Framework — Document 11**
**Version 1.0 — March 2026**

---

## Directory structure

```
ai-tools/ai-skills/docs-copy/
├── SKILL.md                              # Root index — load this first
├── skills/
│   ├── copy-rules.md                     # L4 — sentence banned list
│   ├── structure-rules.md                # L2/L3 — sequence and paragraph rules
│   ├── value-prop-check.md               # L0 — pre-brief VP gate
│   ├── persona-routing.md                # L1 — functional routing rules
│   ├── review-gate.md                    # L5 — publish gate checklist
│   ├── iteration-diagnostic.md           # L6 — fix-cycle routing
│   └── pattern-observer.md               # L7 — cross-session pattern analysis
└── reference/
    ├── banned-words.txt
    ├── banned-phrases.txt
    └── invocation-guide.md               # When to load which skills
```

---

# Root: SKILL.md

**Path:** `ai-tools/ai-skills/docs-copy/SKILL.md`

```markdown
---
name: docs-copy-framework
version: 1.0
description: >
  Copy and content governance framework for Livepeer documentation.
  Enforces product-first, persona-first writing standards across all page types.
  Load this file first. It will tell you which skills to load for your task.
---

# Livepeer Docs Copy Framework

## Load this first

Before any content task, read the invocation guide below.
Load only the skills relevant to your task — do not load all skills for every task.

---

## Invocation guide

| Task | Skills to load |
|---|---|
| Writing a new brief | value-prop-check.md → persona-routing.md |
| Drafting a new page | value-prop-check.md + structure-rules.md + copy-rules.md |
| Editing existing content | copy-rules.md + structure-rules.md |
| Copy review only | copy-rules.md |
| Structural review only | structure-rules.md |
| Pre-merge gate check | review-gate.md |
| Section failing review twice | iteration-diagnostic.md |
| Pattern recurring across pages | pattern-observer.md |

---

## Layer map

| Layer | Skill file | Purpose |
|---|---|---|
| L0 | value-prop-check.md | VP definition gate before brief |
| L1 | persona-routing.md | Functional routing for multi-profile pages |
| L2–L3 | structure-rules.md | Page sequence and paragraph discipline |
| L4 | copy-rules.md | Sentence banned list and master test |
| L5 | review-gate.md | Publish gate checklist |
| L6 | iteration-diagnostic.md | Fix-cycle failure routing |
| L7 | pattern-observer.md | Cross-session pattern analysis |

---

## What this framework does not govern

- Content accuracy — SME review gate (separate)
- SEO keyword strategy — separate workstream
- Translation and localisation — separate pipeline
- Visual design and component choices — Design Governance Framework
```

---

# review-gate.md — L5 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/review-gate.md`

```markdown
---
name: review-gate
version: 1.0
description: >
  L5 publish gate. Load before any pre-merge review.
  Apply every item as a binary pass/fail.
  A page with any failing item does not merge.
invoke_when:
  - "pre-merge check"
  - "publish gate"
  - "ready to merge"
  - "review before PR"
---

# Publish Gate — L5

Apply every item below. Mark pass or fail.
A single fail blocks merge.

---

## Auto-checked by CI scripts

These are caught by lint-copy.js, lint-structure.js, or lint-patterns.js.
Confirm CI passes before starting the human checklist.

- [ ] No Tier 1 banned words (lint-copy.js)
- [ ] No Tier 1 banned phrases (lint-copy.js)
- [ ] No unresolved `{/* REVIEW: */}` flags in rendered content (lint-structure.js)
- [ ] No non-USD currency outside declared regional scope (lint-copy.js)
- [ ] No empty cells in decision tables (lint-structure.js)
- [ ] `pageType`, `audience`, `lastVerified` present in frontmatter (lint-structure.js)

---

## Human review required

### Sequence (L2)
- [ ] Page opens with operator outcome — kept value, one sentence, no conditionals
- [ ] Majority operator path is fully described before variants appear
- [ ] Every introduced path is developed on-page or linked

### Completeness (L3)
- [ ] Every decision aid is complete — no placeholders, no REVIEW flags
- [ ] Every warning or consequence is followed by a prevention action and link
- [ ] Primary actions and URLs appear in body copy — not only inside accordions or Notes

### Tone (L4)
- [ ] No sentence ends on a hedge, disclaimer, or restatement
- [ ] No section ends with a Note that apologises rather than forward-points
- [ ] No diagram and table carry identical information

### Brief compliance
- [ ] L0 Q1–Q4 was completed before drafting (check brief)
- [ ] L1 persona mapping table was completed before drafting (check brief)

---

## Fail escalation

If the same section fails this gate twice:
Do not attempt a third fix at sentence level.
Load iteration-diagnostic.md and run the L6 diagnostic.

If a pattern appears across 3+ pages or fails 2+ fix cycles:
Load pattern-observer.md and run the L7 analysis.
```

---

# invocation-guide.md

**Path:** `ai-tools/ai-skills/docs-copy/reference/invocation-guide.md`

```markdown
# Invocation Guide

## Single-skill tasks

**Copy review only**
Load: copy-rules.md
When: editing prose, reviewing a draft for banned constructions,
      quick pre-commit check

**Structural review only**
Load: structure-rules.md
When: reviewing page sequence, checking paragraph discipline,
      verifying tables and diagrams are not redundant

**Pre-merge gate**
Load: review-gate.md
When: any page is ready for PR submission

---

## Multi-skill tasks

**Writing a new brief**
Load in order:
1. value-prop-check.md  (answer L0 before anything else)
2. persona-routing.md   (map operator profiles)

Do not proceed to drafting until both are complete.

**Drafting a new page**
Load in order:
1. value-prop-check.md  (confirm L0 is answered)
2. structure-rules.md   (apply sequence before writing)
3. copy-rules.md        (apply to every sentence)

**Full editorial review**
Load: structure-rules.md + copy-rules.md + review-gate.md

**Failing review — second pass**
Load: iteration-diagnostic.md
Run the L6 decision tree before attempting any further edits.

**Pattern recurring across pages**
Load: pattern-observer.md
Run L7 analysis. Produce escalation output. Do not fix sentences.

---

## Skill combination rules

- value-prop-check.md always loads before structure-rules.md
- copy-rules.md always loads before review-gate.md
- iteration-diagnostic.md never loads alongside copy-rules.md alone —
  it requires a structural diagnosis, not a sentence fix
- pattern-observer.md is a diagnostic skill — it produces an escalation
  output, not a draft or edit

---

## What not to load

Do not load all skills for every task. Loading irrelevant skills produces
conflicting or redundant guidance. Use the invocation table in SKILL.md.
```
