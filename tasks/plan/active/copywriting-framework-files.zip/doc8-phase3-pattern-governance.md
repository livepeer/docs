# Implementation — Phase 3: Pattern Governance
**Livepeer Docs Copy Framework — Document 8**
**Version 1.0 — March 2026**

---

## Scope

Phase 3 delivers systemic pattern detection across the full documentation set.
Four artefacts, all ready to commit:

- **P3-A:** `lint-patterns.js` — Tier 2 CI pattern checks
- **P3-B:** `pattern-observer.js` — cross-tab aggregation and report generator
- **P3-C:** `iteration-diagnostic.md` — SKILL.md for L6 routing
- **P3-D:** `pattern-observer.md` — SKILL.md for L7 cross-session analysis

**Prerequisite:** Phase 1 and Phase 2 stable. 20+ pages merged under framework.

---

---

# P3-A: lint-patterns.js — Tier 2 CI Checks

**Path:** `tools/scripts/lint-patterns.js`

```javascript
#!/usr/bin/env node

/**
 * lint-patterns.js
 * Livepeer Docs Copy Framework — Tier 2 pattern enforcement
 *
 * Tier 2 patterns require human sign-off — they warn but do not block merge alone.
 * Exception: patterns escalated to Tier 1 (REVIEW flags, self-undermining value)
 * block merge unconditionally.
 *
 * Run after lint-copy.js (which handles exact banned word/phrase matches).
 *
 * Usage:
 *   node tools/scripts/lint-patterns.js [file or glob]
 *   node tools/scripts/lint-patterns.js --changed-files
 *
 * Options:
 *   --warn-only     Never exit 1
 *   --summary       Print summary table only, no per-line detail
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ─── Pattern definitions ──────────────────────────────────────────────────────

const PATTERNS = [
  {
    id: 'CONDITIONAL_IF',
    tier: 2,
    label: '"if" in body prose — conditional gatekeeping',
    fix: 'State the condition as a fact, or remove it.',
    // Matches "if" not inside code fences, inline code, or JSX comments
    test: (line) => /\bif\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line) || isYaml(line),
  },
  {
    id: 'NOT_CONSTRUCTION',
    tier: 2,
    label: '"not [word]" — contrast-by-diminishment',
    fix: 'Restate as a positive claim. Delete the contrast.',
    test: (line) => /\bnot\s+[a-z]/i.test(line),
    skip: (line) => isCode(line) || isComment(line) || isYaml(line),
  },
  {
    id: 'NOT_JUST',
    tier: 2,
    label: '"not just" — contrast-by-diminishment',
    fix: 'Delete or restate as additive.',
    test: (line) => /\bnot just\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'RATHER_THAN',
    tier: 2,
    label: '"rather than" — contrast-by-diminishment',
    fix: 'Delete the contrast clause. State the positive directly.',
    test: (line) => /\brather than\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'WEAKENED_VALUE',
    tier: 2,
    label: '"can/may [verb]" in apparent value claim — weakened assertion',
    fix: 'Assert directly or delete.',
    test: (line) => /\b(can|may)\s+[a-z]+/i.test(line),
    skip: (line) => isCode(line) || isComment(line) || isYaml(line),
  },
  {
    id: 'SELF_UNDERMINING_VALUE',
    tier: 1, // Escalated — blocks merge
    label: '"[value] — if" construction — value undercut in same sentence',
    fix: 'Split into two sentences. Value first. Requirement second.',
    test: (line) => /—\s*if\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'DEPENDS_ON',
    tier: 2,
    label: '"depends on" — hedged claim',
    fix: 'State the specific variable.',
    test: (line) => /\bdepends on\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'CONSISTENTLY_NO_NUMBER',
    tier: 2,
    label: '"consistently" without adjacent number — vague standard',
    fix: 'Add a threshold number or rewrite.',
    // Warn only if no digit appears within 60 chars of "consistently"
    test: (line) => /\bconsistently\b/i.test(line) && !/\bconsistently\b.{0,60}\d/.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'AMONG_OTHER',
    tier: 2,
    label: '"among other [factors/things]" — incomplete claim',
    fix: 'Name the factors or delete the clause.',
    test: (line) => /\bamong other\b/i.test(line),
    skip: (line) => isCode(line) || isComment(line),
  },
  {
    id: 'THIS_PAGE_VERB',
    tier: 2,
    label: '"This page/section [verb]" — page announcement',
    fix: 'Delete. Start with the content.',
    test: (line) => /^(this page|this section|this guide)\s+\w+/i.test(line.trim()),
    skip: (line) => isCode(line) || isComment(line) || isYaml(line),
  },
  {
    id: 'DANGLING_CLAIM',
    tier: 2,
    label: 'Sentence ending with "is different" or "is the same" — unsupported claim',
    fix: 'Show the difference. Link to a page that does.',
    test: (line) => /is (different|the same)\.?\s*$/i.test(line.trim()),
    skip: (line) => isCode(line) || isComment(line),
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isCode(line) {
  return /^\s*(```|~~~|`[^`]|\s{4})/.test(line);
}

function isComment(line) {
  return /^\s*(\{\/\*|\/\/|<!--)/.test(line);
}

function isYaml(line) {
  return /^[a-zA-Z_-]+:/.test(line.trim());
}

function inFrontmatter(lines, index) {
  let fmCount = 0;
  for (let i = 0; i < index; i++) {
    if (lines[i].trim() === '---') fmCount++;
  }
  return fmCount < 2;
}

function inCodeFence(lines, index) {
  let inFence = false;
  for (let i = 0; i < index; i++) {
    if (/^\s*```/.test(lines[i])) inFence = !inFence;
  }
  return inFence;
}

function getFiles() {
  const args = process.argv.slice(2);
  if (args.includes('--changed-files')) {
    const diff = execSync('git diff --cached --name-only --diff-filter=ACM', {
      encoding: 'utf8',
    });
    return diff
      .split('\n')
      .filter(f => f.endsWith('.mdx') || f.endsWith('.md'))
      .filter(fs.existsSync);
  }
  const target = args.find(a => !a.startsWith('--'));
  if (target && fs.existsSync(target)) return [target];
  return [];
}

// ─── Runner ───────────────────────────────────────────────────────────────────

function checkFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  const results = [];

  lines.forEach((line, i) => {
    if (inFrontmatter(lines, i)) return;
    if (inCodeFence(lines, i)) return;

    PATTERNS.forEach(pattern => {
      if (pattern.skip && pattern.skip(line)) return;
      if (pattern.test(line)) {
        results.push({
          tier: pattern.tier,
          file: filePath,
          line: i + 1,
          id: pattern.id,
          label: pattern.label,
          fix: pattern.fix,
          text: line.trim().slice(0, 80),
        });
      }
    });
  });

  return results;
}

function run() {
  const args = process.argv.slice(2);
  const warnOnly = args.includes('--warn-only');
  const summaryOnly = args.includes('--summary');
  const files = getFiles();

  if (files.length === 0) {
    console.log('lint-patterns: no files to check.');
    process.exit(0);
  }

  let tier1Count = 0;
  let tier2Count = 0;
  const patternCounts = {};

  files.forEach(filePath => {
    const results = checkFile(filePath);
    const t1 = results.filter(r => r.tier === 1);
    const t2 = results.filter(r => r.tier === 2);

    tier1Count += t1.length;
    tier2Count += t2.length;

    results.forEach(r => {
      patternCounts[r.id] = (patternCounts[r.id] || 0) + 1;
    });

    if (!summaryOnly) {
      if (t1.length > 0) {
        console.error(`\n❌  ${filePath} — ${t1.length} BLOCKING pattern(s):\n`);
        t1.forEach(r => {
          console.error(`  [L${r.line}] ${r.id}: ${r.label}`);
          console.error(`        Fix: ${r.fix}`);
          console.error(`        → "${r.text}"`);
        });
      }
      if (t2.length > 0) {
        console.warn(`\n⚠️   ${filePath} — ${t2.length} pattern warning(s) (human sign-off required):\n`);
        t2.forEach(r => {
          console.warn(`  [L${r.line}] ${r.id}: ${r.label}`);
          console.warn(`        Fix: ${r.fix}`);
          console.warn(`        → "${r.text}"`);
        });
      }
    }
  });

  // Summary table
  console.log(`\n── Pattern Summary (${files.length} file(s)) ──────────────────`);
  console.log(`Blocking (Tier 1): ${tier1Count}`);
  console.log(`Warnings (Tier 2): ${tier2Count}`);
  if (Object.keys(patternCounts).length > 0) {
    console.log('\nTop patterns:');
    Object.entries(patternCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .forEach(([id, count]) => console.log(`  ${id.padEnd(30)} ${count}`));
  }
  console.log('────────────────────────────────────────────────────');

  if (tier1Count > 0 && !warnOnly) {
    console.error('\nMerge blocked. Resolve Tier 1 patterns before re-submitting.');
    process.exit(1);
  }

  process.exit(0);
}

run();
```

---

---

# P3-B: pattern-observer.js — Cross-Tab Aggregation

**Path:** `tools/scripts/pattern-observer.js`

```javascript
#!/usr/bin/env node

/**
 * pattern-observer.js
 * Livepeer Docs Copy Framework — L7 Pattern Observer
 *
 * Runs lint-copy.js and lint-patterns.js across a full tab or the entire v2/ tree.
 * Aggregates results into a pattern report with recurrence counts and L7 diagnostics.
 *
 * Not run per-PR. Run on a schedule (per tab completion, then monthly)
 * or manually by the documentation lead.
 *
 * Usage:
 *   node tools/scripts/pattern-observer.js --tab orchestrators
 *   node tools/scripts/pattern-observer.js --tab gateways
 *   node tools/scripts/pattern-observer.js --all
 *   node tools/scripts/pattern-observer.js --all --output reports/pattern-report.md
 *
 * Output: Markdown report with pattern frequencies, L7 diagnostic, and escalation calls.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ─── L7 Diagnostic thresholds ─────────────────────────────────────────────────

// Pattern ID → escalation category if count exceeds threshold
const ESCALATION_MAP = {
  // These patterns everywhere → VP not strong enough to stand alone
  NOT_CONSTRUCTION:        { threshold: 5,  escalation: 'PRODUCT_CLARITY', reason: 'Writer reaching for contrast because no clear positive value claim exists.' },
  NOT_JUST:                { threshold: 3,  escalation: 'PRODUCT_CLARITY', reason: 'Contrast-by-diminishment signals undefined value proposition.' },
  WEAKENED_VALUE:          { threshold: 5,  escalation: 'PRODUCT_CLARITY', reason: 'Hedged value claims suggest writer does not believe the VP being asserted.' },
  SELF_UNDERMINING_VALUE:  { threshold: 2,  escalation: 'PRODUCT_CLARITY', reason: 'Self-undermining constructions indicate L0 Q1 was not cleanly answered.' },

  // Clustered in one section → undefined reader for that section
  CONDITIONAL_IF:          { threshold: 5,  escalation: 'ARCHITECTURE',    reason: 'Conditionals cluster around sections serving multiple undefined personas simultaneously.' },
  DEPENDS_ON:              { threshold: 3,  escalation: 'ARCHITECTURE',    reason: 'Hedge language indicates section is covering multiple operator profiles without routing.' },

  // Everywhere → pages have no clear single job
  THIS_PAGE_VERB:          { threshold: 3,  escalation: 'ARCHITECTURE',    reason: 'Page announcements indicate pages without a defined single purpose.' },
  DANGLING_CLAIM:          { threshold: 3,  escalation: 'ARCHITECTURE',    reason: 'Unsupported claims indicate missing linked content or incomplete briefs.' },

  // Copy internalisation gap
  RATHER_THAN:             { threshold: 4,  escalation: 'COPY',            reason: 'Writer has not internalised the no-contrast rule.' },
  AMONG_OTHER:             { threshold: 4,  escalation: 'COPY',            reason: 'Incomplete claims indicate copy-level discipline gap.' },
  CONSISTENTLY_NO_NUMBER:  { threshold: 4,  escalation: 'COPY',            reason: 'Vague standards indicate copy-level precision gap.' },
};

const ESCALATION_ACTIONS = {
  PRODUCT_CLARITY: 'Route to L0. VP questions must be re-answered with product owner before further drafting on affected pages.',
  ARCHITECTURE:    'Route to L1/L2. Page scope or IA needs restructuring. Review persona path mapping for affected section.',
  COPY:            'Route to L4/L5. Rule reinforcement pass. Flag for copy editor review.',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getTabFiles(tab) {
  const tabPath = path.join('v2', tab);
  if (!fs.existsSync(tabPath)) {
    console.error(`Tab path not found: ${tabPath}`);
    process.exit(1);
  }
  return getAllMdx(tabPath);
}

function getAllFiles() {
  return getAllMdx('v2');
}

function getAllMdx(dir) {
  const results = [];
  if (!fs.existsSync(dir)) return results;
  fs.readdirSync(dir, { withFileTypes: true }).forEach(entry => {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...getAllMdx(fullPath));
    } else if (entry.name.endsWith('.mdx') || entry.name.endsWith('.md')) {
      results.push(fullPath);
    }
  });
  return results;
}

function runLintOnFiles(files, scriptName) {
  // Write file list to temp file for script to read
  const tmpList = '/tmp/lint-file-list.txt';
  fs.writeFileSync(tmpList, files.join('\n'));
  try {
    const output = execSync(
      `node tools/scripts/${scriptName} --warn-only --summary`,
      { encoding: 'utf8', env: { ...process.env, LINT_FILE_LIST: tmpList } }
    );
    return output;
  } catch (err) {
    return err.stdout || '';
  }
}

function collectPatternCounts(files) {
  // Run lint-patterns in warn-only mode, parse output for pattern counts
  const counts = {};
  const perFile = {};

  files.forEach(filePath => {
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const lines = content.split('\n');

      // Simple pattern check inline (mirrors lint-patterns.js logic)
      lines.forEach((line, i) => {
        if (/^\s*```/.test(line)) return; // skip code
        if (/^\{\/\*/.test(line.trim())) return; // skip JSX comments

        const checks = [
          { id: 'CONDITIONAL_IF',        test: /\bif\b/i },
          { id: 'NOT_CONSTRUCTION',       test: /\bnot\s+[a-z]/i },
          { id: 'NOT_JUST',               test: /\bnot just\b/i },
          { id: 'RATHER_THAN',            test: /\brather than\b/i },
          { id: 'WEAKENED_VALUE',         test: /\b(can|may)\s+[a-z]+/i },
          { id: 'SELF_UNDERMINING_VALUE', test: /—\s*if\b/i },
          { id: 'DEPENDS_ON',             test: /\bdepends on\b/i },
          { id: 'CONSISTENTLY_NO_NUMBER', test: /\bconsistently\b(?!.{0,60}\d)/i },
          { id: 'AMONG_OTHER',            test: /\bamong other\b/i },
          { id: 'THIS_PAGE_VERB',         test: /^(this page|this section|this guide)\s+\w+/i },
          { id: 'DANGLING_CLAIM',         test: /is (different|the same)\.?\s*$/i },
        ];

        checks.forEach(({ id, test }) => {
          if (test.test(line)) {
            counts[id] = (counts[id] || 0) + 1;
            if (!perFile[id]) perFile[id] = new Set();
            perFile[id].add(filePath);
          }
        });
      });
    } catch (_) {}
  });

  return { counts, perFile };
}

// ─── Report generator ─────────────────────────────────────────────────────────

function generateReport({ tab, files, counts, perFile, date }) {
  const tabLabel = tab || 'all tabs';
  const lines = [];

  lines.push(`# Pattern Observer Report`);
  lines.push(`**Scope:** ${tabLabel}`);
  lines.push(`**Date:** ${date}`);
  lines.push(`**Files scanned:** ${files.length}`);
  lines.push('');
  lines.push('---');
  lines.push('');

  // Pattern frequency table
  lines.push('## Pattern Frequency');
  lines.push('');
  lines.push('| Pattern | Count | Files affected | Threshold | Escalation |');
  lines.push('|---|---|---|---|---|');

  const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  sorted.forEach(([id, count]) => {
    const def = ESCALATION_MAP[id];
    const threshold = def ? def.threshold : '—';
    const escalation = def && count >= def.threshold ? `⚠️ ${def.escalation}` : 'None';
    const fileCount = perFile[id] ? perFile[id].size : 0;
    lines.push(`| ${id} | ${count} | ${fileCount} | ${threshold} | ${escalation} |`);
  });

  lines.push('');
  lines.push('---');
  lines.push('');

  // L7 diagnostic
  const escalations = { PRODUCT_CLARITY: [], ARCHITECTURE: [], COPY: [] };
  let hasEscalation = false;

  Object.entries(counts).forEach(([id, count]) => {
    const def = ESCALATION_MAP[id];
    if (def && count >= def.threshold) {
      escalations[def.escalation].push({ id, count, reason: def.reason });
      hasEscalation = true;
    }
  });

  lines.push('## L7 Diagnostic Output');
  lines.push('');

  if (!hasEscalation) {
    lines.push('No patterns exceed escalation thresholds. Framework operating within expected parameters.');
  } else {
    ['PRODUCT_CLARITY', 'ARCHITECTURE', 'COPY'].forEach(type => {
      if (escalations[type].length === 0) return;
      lines.push(`### ${type.replace('_', ' ')} — ${ESCALATION_ACTIONS[type]}`);
      lines.push('');
      lines.push('**Triggering patterns:**');
      escalations[type].forEach(({ id, count, reason }) => {
        lines.push(`- **${id}** (${count} occurrences): ${reason}`);
      });
      lines.push('');
    });
  }

  lines.push('---');
  lines.push('');
  lines.push('## Affected Files by Pattern');
  lines.push('');

  sorted.forEach(([id, count]) => {
    if (!perFile[id] || perFile[id].size === 0) return;
    lines.push(`### ${id} (${count})`);
    [...perFile[id]].sort().forEach(f => lines.push(`- \`${f}\``));
    lines.push('');
  });

  return lines.join('\n');
}

// ─── Main ─────────────────────────────────────────────────────────────────────

function run() {
  const args = process.argv.slice(2);
  const tabArg = args.find((_, i) => args[i - 1] === '--tab');
  const outputArg = args.find((_, i) => args[i - 1] === '--output');
  const all = args.includes('--all');

  if (!tabArg && !all) {
    console.error('Usage: pattern-observer.js --tab <name> | --all [--output <file>]');
    process.exit(1);
  }

  const files = tabArg ? getTabFiles(tabArg) : getAllFiles();
  console.log(`Scanning ${files.length} files...`);

  const { counts, perFile } = collectPatternCounts(files);
  const report = generateReport({
    tab: tabArg || null,
    files,
    counts,
    perFile,
    date: new Date().toISOString().split('T')[0],
  });

  if (outputArg) {
    fs.mkdirSync(path.dirname(outputArg), { recursive: true });
    fs.writeFileSync(outputArg, report);
    console.log(`Report written to ${outputArg}`);
  } else {
    console.log(report);
  }
}

run();
```

---

---

# P3-C: iteration-diagnostic.md — L6 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/iteration-diagnostic.md`

```markdown
---
name: iteration-diagnostic
version: 1.0
description: >
  L6 iteration diagnostic skill. Load when a section has failed the L5 gate.
  Routes the failure to the correct repair layer. Do not attempt a third
  sentence-level fix without running this diagnostic first.
invoke_when:
  - "this section keeps failing review"
  - "same error after second fix"
  - "why does this keep failing"
---

# Iteration Diagnostic — L6

## When to use this skill
A section has failed the L5 gate twice. Do not attempt a third fix at
the sentence level. Run this diagnostic to identify what layer the
failure is actually at.

---

## Step 1: Classify the failure

**Is the same error class appearing in a different sentence?**

YES → go to Pattern Failure below
NO  → go to New Error Class below

---

## Pattern Failure

The same banned construction or structural error recurs after a fix.

**Is it appearing in multiple sections of the page?**

YES:
The writer has not internalised the rule.
This is a copy problem, not a structural one.
ACTION: Rule reinforcement pass. Do not redraft — apply L4 rules
sentence by sentence to the existing content. Route to copy editor
if the writer is an agent.

NO (single section keeps failing):

Is the failing section an evaluation or decision section?
YES → PERSONA FAILURE. Go to Persona Check.
NO  → VALUE PROP FAILURE. Go to VP Check.

---

## New Error Class

A different error is appearing after the fix.

**Was this section covered by an L0 question in the brief?**

NO:
SCOPE FAILURE.
This section should not exist on this page, or belongs on another page.
ACTION: Return to brief. Identify which page owns this content need.
Do not redraft here.

YES (covered by L0 but still failing):

Does the section describe the majority operator path?
NO  → PATH PRIORITY FAILURE.
      The majority path must be the featured path.
      Restructure — do not rewrite sentences.
YES → Go to VP Check.

---

## Persona Check

Triggered when: evaluation or decision content keeps producing
hedges, conditionals, or "depends on" constructions after multiple passes.

Work through these in order:

1. Does the section address more than one operator profile simultaneously?
   YES: Split the section. One profile per block. Stop here.

2. Is the section written from the product outward rather than the
   operator's question inward?
   YES: Rewrite from the operator's question. State the question as
   the opening sentence. Stop here.

3. Does the operator profile this section serves exist in the L1
   persona mapping table in the brief?
   NO: Kill the section. It is serving an imagined reader.
   Route the content need to a new brief if genuine.

4. Is the primary question this section answers written in the brief?
   NO: Stop. Write the question. Redraft the section as its answer.

---

## VP Check

Triggered when: body copy drifts into mechanism description,
contrast language, or cost-before-value sequences across passes.

Work through these in order:

1. Can the L0 Q1 outcome statement for this page be said in one
   sentence without a conditional?
   NO: The value prop is not defined. Return to L0.
       No further drafting until L0 Q1 is answered clean.

2. Is the operator outcome stated before the mechanism that produces it?
   NO: Reorder. Outcome first. Stop here.

3. Does the majority path in this section match the majority real-world
   operator documented in L0 Q2?
   NO: Restructure around the actual majority. Stop here.

4. Would an operator reading this section know what to do next
   without visiting Discord?
   NO: The section is incomplete. Add the staged action path.

---

## Output of this diagnostic

After completing the relevant check, produce one of three escalation calls:

**COPY PROBLEM**
Route to L4/L5. Writer applies rule reinforcement pass.
Re-enter gate at L5.

**ARCHITECTURE PROBLEM**
Route to L1/L2. Review persona mapping and content sequence.
Redraft affected sections. Re-enter at L3.

**PRODUCT CLARITY PROBLEM**
Route to L0. VP questions re-answered with product owner.
No further drafting on this page until L0 is complete.
Re-enter at L2 after L0 is resolved.

---

## Escalation rule
Two failed fix passes on the same section = run this diagnostic.
Do not attempt a third sentence-level fix without completing it.
```

---

---

# P3-D: pattern-observer.md — L7 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/pattern-observer.md`

```markdown
---
name: pattern-observer
version: 1.0
description: >
  L7 pattern observer skill. Load when the same error class has appeared
  across 3+ pages, or when pattern-observer.js has produced a report
  requiring interpretation. This skill reads across sessions and pages
  to determine what recurrence means — not how to fix individual sentences.
invoke_when:
  - "why does this keep coming up"
  - "same pattern across multiple pages"
  - "interpret the pattern report"
  - "pattern observer report"
---

# Pattern Observer — L7

## What this skill does

It reads recurrence to find cause. A pattern that survives multiple
fix cycles is not a copy problem — it is a signal. This skill
interprets that signal and produces an escalation call.

This skill does not produce fixes. It produces one of three outputs:
- COPY PROBLEM
- ARCHITECTURE PROBLEM
- PRODUCT CLARITY PROBLEM

---

## The four observer questions

Ask these in order for any recurring pattern.

---

### Q1: Frequency
Where is this pattern appearing?

In one section type only → structural or IA problem → likely ARCHITECTURE
Everywhere across the tab → value prop or persona definition problem → likely PRODUCT CLARITY
In isolated individual pages → writer internalisation gap → likely COPY

---

### Q2: Author behaviour
Is the writer reaching for this construction, or falling back to it?

**Reaching** (the writer is actively choosing it, apparently to solve a
communication problem):
The framework is not giving them a way to say what they need to say.
This is a signal that either the VP is undefined (they have nothing
positive to assert) or the persona is undefined (they are covering
multiple readers at once).
→ Escalate to ARCHITECTURE or PRODUCT CLARITY.

**Falling back** (the writer uses it despite knowing the rule,
because it feels natural):
Rule not internalised. Discipline problem.
→ COPY PROBLEM.

---

### Q3: What is the pattern protecting?

Remove the construction mentally. What would the copy have to claim,
without qualification, if it were gone?

If that claim feels uncertain or uncomfortable:
The value prop is unresolved upstream. The construction is protecting
the writer from asserting something they do not believe is true.
→ PRODUCT CLARITY PROBLEM.

If the claim is clear but the writer avoided stating it directly:
Voice or confidence problem. The VP exists but the writer is
hedging defensively.
→ COPY PROBLEM (with L0 verification pass to confirm VP is in fact clean).

---

### Q4: What does the reader lose if this is never fixed?

Nothing — they just read worse prose:
Sentence-level fix. Low priority. COPY PROBLEM.

They cannot evaluate whether to commit to the path described:
This is blocking conversion. High priority.
Escalate to product owner, not copy editor.
→ PRODUCT CLARITY PROBLEM.

They cannot find the right path for their situation:
This is a routing failure. High priority.
→ ARCHITECTURE PROBLEM.

---

## Pattern interpretation table

Use this table as a starting reference before applying the four questions.

| Recurring pattern | L7 reading |
|---|---|
| `not [X]` persists after fixes | VP not strong enough to stand alone — writer reaches for contrast because there is no clear positive to lead with |
| Conditionals cluster in one section | Section is serving an undefined reader — hedges cover multiple personas simultaneously |
| `This page covers` persists | Pages do not have a defined single job — writer announces because scope is uncertain |
| Cost or warning before value persists | Writer does not believe the VP being asserted |
| Majority path is buried as a footnote or aside | IA built around edge cases or product structure, not operator reality |
| Dangling claims persist | Missing linked content or incomplete briefs — staged action paths absent |

---

## Output format

After running the four questions, produce this output:

```
PATTERN OBSERVER OUTPUT
Pattern:        [pattern ID(s)]
Frequency:      [count / pages affected]
Q1 reading:     [one sentence]
Q2 reading:     [reaching / falling back + one sentence]
Q3 reading:     [claim identified + assessment]
Q4 reading:     [reader impact + priority]
Escalation:     [COPY / ARCHITECTURE / PRODUCT CLARITY]
Action:         [specific next step per L8 repair routing]
```

---

## L8 repair routing (quick reference)

**COPY PROBLEM**
L4 rule reinforcement pass → re-enter at L5.

**ARCHITECTURE PROBLEM**
L1 persona map review → L2 sequence audit →
redraft affected sections → re-enter at L3.

**PRODUCT CLARITY PROBLEM**
L0 VP questions re-answered with product owner →
L1 persona map updated if VP shift changes audience →
full page redraft → re-enter at L2.
```
