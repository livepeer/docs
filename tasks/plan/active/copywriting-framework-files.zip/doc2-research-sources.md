# Research Sources & Primary Takeaways
**Livepeer Docs Copy Framework — Supporting Evidence**
**Version 1.0 — March 2026**

---

## Purpose

This document records the external frameworks and standards that informed the Livepeer Docs Copy Framework. For each source, the primary takeaway — the specific principle extracted and applied — is noted. References back to framework layers are included.

---

## Primary Frameworks

---

### 1. Diátaxis — Information Architecture and Page Type Discipline
**Source:** diataxis.fr — Daniele Procida
**Type:** Information architecture framework

#### What it is
Diátaxis separates documentation into four types, each with a distinct purpose and writing mode:
- **Tutorials** — learning-oriented. The reader acquires a skill.
- **How-to guides** — task-oriented. The reader achieves a goal.
- **Reference** — information-oriented. The reader consults facts.
- **Explanation** — understanding-oriented. The reader builds a mental model.

#### Primary takeaways applied to this framework

**Every page has one job.**
Diátaxis's core discipline is that mixing page types produces pages that serve no reader well. An explanation embedded in a how-to guide interrupts the task. A tutorial buried in a reference page obscures the fact.
→ *Applied in L2 (content sequence rules) and L3 (one paragraph, one job).*

**Know what question each page is answering.**
Before writing, state the question the page answers. If it cannot be stated in one sentence, the page scope is wrong.
→ *Applied in L1 (persona path mapping) — every row in the mapping table must answer a stated question.*

**Every page must have a clear onward path.**
Diátaxis pages are not islands. Each has an explicit next step appropriate to the reader's current position in the documentation system.
→ *Applied in L2 (step 7: next page) and L5 (gate item: no introduced path without routing).*

**If the content may be stale, update it — do not apologise for it inline.**
Inline disclaimers about accuracy undermine the reader's trust at the point they most need it. Temporal metadata belongs in version fields.
→ *Applied in L4 (banned: inline disclaimers) and L5 (gate item: no hedge at end of section).*

---

### 2. Google Technical Writing Courses
**Source:** developers.google.com/tech-writing
**Type:** Sentence-level clarity standard

#### What it is
Google's official technical writing courses teach clear documentation through: active voice, short sentences, precise word choice, and self-editing discipline. Designed for engineers writing documentation for engineers.

#### Primary takeaways applied

**Active voice, direct assertion.**
Passive constructions obscure agency and weaken claims. "The node earns ETH" is stronger than "ETH is earned by the node."
→ *Applied throughout L4 (banned list includes all weakened value constructions).*

**Remove filler before publishing.**
Google's self-editing pass targets: throat-clearing openers, redundant pairs (basic and fundamental), and announcements of what the page will do.
→ *Applied in L4: `This page covers`, `The reason is straightforward`, `Understanding X is essential`.*

**Be precise with numbers.**
Vague qualifiers ("low", "significant", "consistently") are always replaceable with numbers. If the number is unknown, flag it as unknown — do not substitute a vague qualifier.
→ *Applied in L4 (banned: `meaningful`, `real`, `significant`, `consistently` without a number) and L5 (gate: unresolved REVIEW flags in decision-critical positions).*

**Short sentences over compound sentences.**
Every conjunction is a potential split. Compound sentences that contain both a value claim and a condition should be split.
→ *Applied in L4: `[value] — if [condition]` is banned. Split into two sentences.*

---

### 3. Microsoft Writing Style Guide
**Source:** docs.microsoft.com/style-guide
**Type:** Product-facing tone, terminology, and procedure standard

#### What it is
Microsoft's style guide governs product documentation tone, UI language, procedure writing, and terminology consistency. Particularly strong for step-by-step instructions and interface language.

#### Primary takeaways applied

**Procedures are written in imperative, second person.**
"Select the GPU tier" not "The operator should select the GPU tier." Instructions are commands, not descriptions.
→ *Applied in L3 (paragraph rules: staged action paths are imperative) and L4 (banned: third-person generalisations on action-oriented pages).*

**Describe the goal before the procedure.**
Every how-to section opens with what the reader will achieve, then how. Mechanism before outcome is a structural inversion.
→ *Applied in L2 (mandatory sequence: operator outcome first).*

**Avoid unnecessary conditions in procedures.**
"If you have an NVIDIA GPU, you can run transcoding" should be "To run transcoding, you need an NVIDIA GPU." Conditions become prerequisites stated once, not hedges repeated throughout.
→ *Applied in L4: `if [condition]` banned in body prose.*

**One idea per sentence in procedures.**
Compound procedural sentences create ambiguity about what is required and what is optional.
→ *Applied in L3: one paragraph, one job.*

---

### 4. Red Hat Modular Documentation
**Source:** redhat-documentation.github.io/modular-docs
**Type:** Reusable product documentation structure

#### What it is
Red Hat's modular documentation standard defines three module types — concept, procedure, and reference — each self-contained and reusable. Built on user-story-based documentation: every module is written to answer a specific user question.

#### Primary takeaways applied

**Write to a specific user story, not a general audience.**
Every module begins with a defined user (role + goal). Writing to "operators" in general produces copy that serves no operator specifically.
→ *Applied in L1 (persona path mapping table) and L7 (pattern observer: hedges clustering in one section indicate undefined reader).*

**Single-source, don't repeat.**
Content that exists on a linked page should not be reproduced on the current page. Reproduction creates maintenance debt and dilutes the clarity of each page's purpose.
→ *Applied in L3: tables and diagrams stand alone; prose restating a table row is deleted. L4: pages that re-explain content from linked prerequisite pages fail the gate.*

**Prerequisites are stated explicitly at module opening.**
A module that assumes knowledge must declare that assumption. A module that re-explains that knowledge instead is structurally wrong.
→ *Applied in L2 (prerequisites stated, not restated) and L4 (banned: re-delivery of content from a linked page).*

---

### 5. DITA (Darwin Information Typing Architecture)
**Source:** docs.oasis-open.org/dita
**Type:** Enterprise documentation taxonomy and reuse system

#### What it is
DITA is a structured content standard for large-scale technical documentation. Its information typing discipline (topic, task, concept, reference) enforces separation of content concerns. Most relevant for systems with hundreds of pages and multiple content types.

#### Primary takeaways applied

**Information typing prevents scope creep.**
When a page type is undefined, writers fill it with whatever they know. Typing a page as concept, task, or reference constrains what belongs there.
→ *Applied in L2 (content sequence rules per page type) and L5 (gate: page must have a defined type that matches its content).*

**Taxonomy built around real use cases, not product structure.**
DITA's task topics are defined by what the user does, not by how the product is organised. Documentation that mirrors the product's internal architecture instead of the user's workflow fails the user.
→ *Applied in L7 (pattern observer: if majority path is buried, the IA was built around edge cases or product structure, not operator reality).*

---

### 6. Public SKILL.md Standards
**Sources:**
- `github/awesome-copilot` — documentation-writer skill (Diátaxis Documentation Expert)
- `metabase/metabase` — docs-review skill against writing style guide
- `getsentry/skills` — blog-writing-guide for technical voice
- `zocomputer/skills` — copywriting SKILL.md for conversion copy
- OpenAI `openai/skills` — agent skills as folders of instructions, scripts, and resources
- Anthropic `anthropics/skills` — basic skill as SKILL.md with YAML frontmatter and instructions

#### Primary takeaways applied

**Skills are executable constraints, not suggestions.**
A SKILL.md is read by an agent before it acts. It must be written as executable rules, not guidelines. Vague guidance ("write clearly") produces inconsistent output. Specific rules ("banned words: not, rather than, if") produce consistent output.
→ *Applied in L4 design: the banned list is formatted as a machine-readable ruleset, not a style preference.*

**Frontmatter as machine-readable metadata.**
YAML frontmatter (`pageType`, `audience`, `purpose`) allows automated tooling to classify pages and enforce type-appropriate rules without human review of every page.
→ *Applied in L5 (gate) and Document 4 (script enforcement design).*

**Separate skill files for separate concerns.**
A single monolithic SKILL.md that attempts to govern everything produces agent confusion. Separate skills for copy rules, structural rules, and audit rules are independently invokable and composable.
→ *Applied in Document 4 (implementation design: separate skill files per layer).*

---

## Applied Rules Traceability

| Rule in framework | Source framework | Specific principle |
|---|---|---|
| One page, one job | Diátaxis | Page type discipline |
| Operator outcome before mechanism | Microsoft Style Guide | Goal before procedure |
| No inline disclaimers | Diátaxis | Stale content is updated, not apologised for |
| Banned: `This page covers` | Google Technical Writing | No throat-clearing openers |
| Banned: `if [condition]` in body prose | Microsoft Style Guide | Conditions become stated prerequisites |
| Banned: `not [X]` | Google Technical Writing | Direct assertion; no contrast-by-diminishment |
| Banned: vague intensifiers | Google Technical Writing | Replace with numbers |
| Single-source; no prose restating tables | Red Hat Modular Docs | Single-source principle |
| User story at module opening | Red Hat Modular Docs | Write to specific user, not general audience |
| Page type defines content scope | DITA | Information typing |
| IA built around user workflows | DITA | Task topics by user action, not product structure |
| Banned list as machine-readable rules | SKILL.md standards | Executable constraints over guidelines |
| Separate skill files per concern | SKILL.md standards | Composable, independently invokable skills |
