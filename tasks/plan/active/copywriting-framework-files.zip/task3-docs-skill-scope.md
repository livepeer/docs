# Documentation Skill — Scope
**Livepeer Docs Copy Framework — Document 12**
**Version 1.0 — March 2026**

---

## Purpose

One documentation skill covering the `docs-copy` framework and all future skills
added under `ai-tools/ai-skills/`. Enforced by a test suite that validates every
skill file on every commit. Writers and agents have a single entry point.

---

## What it governs

**Skill file completeness:**
Every `.md` file under `ai-tools/ai-skills/` must have valid YAML frontmatter with:
- `name` — unique identifier, kebab-case
- `version` — semver string
- `description` — minimum 20 words, plain English, no jargon
- `invoke_when` — at least one trigger phrase (array)

**README completeness:**
Every skill directory must have a `README.md` containing:
- What the skill does (one paragraph)
- Layer map or file index (table)
- Invocation instructions (how to load, what task to load it for)

**Cross-reference integrity:**
Every skill file that references another skill (e.g. "load copy-rules.md") must
reference a file that exists at that path.

**No circular references:**
A skill must not require loading itself, and skill A must not require skill B
if skill B requires skill A.

---

## What it does not govern

- Skill content quality (framework correctness — human review)
- Banned word enforcement on skill files (copy-rules.md governs content, not tooling)
- Naming beyond kebab-case requirement

---

## Enforcement design

**Test file:** `tests/unit/skill-docs.test.js`
**Pattern:** same `{ runTests({ stagedOnly }) }` export as all other test suites
**Wired into:** `tests/run-all.js` (one `require` + one `normalizeSuiteResult` block)
**Scope:** all `.md` files under `ai-tools/ai-skills/`

**Tier 1 (blocking):**
- Missing `name`, `version`, `description`, or `invoke_when` in frontmatter
- `description` under 20 words
- `invoke_when` is empty array or missing
- Cross-reference to a non-existent skill file
- Directory with no `README.md`

**Tier 2 (warning):**
- `description` over 100 words (likely too broad — split the skill)
- `version` not updated when file content changes (detected by git diff heuristic)
- `invoke_when` triggers that duplicate another skill's triggers exactly

---

## The `should we enforce docs for every new skill?` question

**No — do it once, enforce automatically.**

A per-skill documentation phase adds overhead to every skill creation task
and creates inconsistent output depending on who writes the brief.

The test suite enforces the standard automatically. Any skill file created
without valid frontmatter fails on first commit. No manual documentation phase needed.

The one-time cost is writing `skill-docs.test.js` and adding the README
requirement to the agent prompt for new skills. After that: automatic.

---

## Skill file: `skills/skill-docs.md`

This skill governs the creation of new skill files.
Agents load it when creating any new skill under `ai-tools/ai-skills/`.

```markdown
---
name: skill-docs
version: 1.0
description: >
  Governs the required structure for all skill files under ai-tools/ai-skills/.
  Load when creating or editing any skill file. Ensures test suite compliance
  on first commit.
invoke_when:
  - "create a new skill"
  - "add a skill file"
  - "write a SKILL.md"
---

# Skill Documentation Rules

Every skill file must have YAML frontmatter with these fields:

name: [kebab-case unique identifier]
version: [semver: 1.0, 1.1, 2.0]
description: >
  [Plain English. Minimum 20 words. Maximum 100 words.
   Describes what the skill does and when to use it.
   No jargon. No self-reference ("this skill...")]
invoke_when:
  - "[trigger phrase 1]"
  - "[trigger phrase 2]"

Every skill directory must have a README.md with:
- One paragraph: what this skill set does
- A table: file name | layer | purpose
- Invocation instructions: which file to load for which task

Cross-references to other skill files must use exact relative paths.
Run tests/unit/skill-docs.test.js before committing any new skill file.
```

---

---

# Agent Prompt: Documentation Skill Implementation

```
Base branch: docs-v2
Pull docs-v2 before creating any files.

TASK: Implement the skill documentation enforcement system.
Two deliverables: one skill file, one test suite.

---

STEP 0 — VERIFY

1. Confirm ai-tools/ai-skills/ exists and note existing structure.
2. Confirm tests/unit/ contains at least one test file that exports
   { runTests({ stagedOnly }) } — read it as the pattern to follow.
3. Confirm tests/run-all.js structure — identify where to register new suite.
4. Confirm tests/run-pr-checks.js — identify where to register new suite.

Stop and report if any path is unexpected.

---

COMMIT 1 — Skill file

ai-tools/ai-skills/docs-copy/skills/skill-docs.md

Content:

---
name: skill-docs
version: 1.0
description: >
  Governs the required structure for all skill files under ai-tools/ai-skills/.
  Load when creating or editing any skill file. Ensures test suite compliance
  on first commit without a manual documentation phase.
invoke_when:
  - "create a new skill"
  - "add a skill file"
  - "write a SKILL.md"
  - "new skill for"
---

# Skill Documentation Rules

Every skill file must have YAML frontmatter with these exact fields:

  name: [kebab-case unique identifier]
  version: [semver: 1.0, 1.1, 2.0]
  description: >
    [Plain English. Minimum 20 words. Maximum 100 words.
     Describes what the skill does and when to use it.
     No jargon.]
  invoke_when:
    - "[trigger phrase 1]"

Every skill directory must have a README.md containing:
- One paragraph: what this skill set does
- Table: file | layer | purpose
- Invocation instructions: which file to load for which task

Cross-references to other skill files must use exact relative paths.
Before committing any new skill file, run:
  node tests/unit/skill-docs.test.js

---

Commit message: "feat(skill-docs): add skill documentation rules skill"

---

COMMIT 2 — Test suite

tests/unit/skill-docs.test.js

The file must:
- Export { runTests({ stagedOnly }) } returning { errors: [], warnings: [] }
- Follow the exact pattern of an existing tests/unit/*.test.js file
- When stagedOnly is true: only check staged files under ai-tools/ai-skills/
- When stagedOnly is false: check all files under ai-tools/ai-skills/

Tier 1 checks (errors — blocking):
- Any .md file under ai-tools/ai-skills/ that is missing name, version,
  description, or invoke_when in YAML frontmatter
- description field under 20 words
- invoke_when is empty or missing entries
- A skill file references another file (contains "load [filename].md" or
  similar) where that file does not exist at the referenced path
- Any ai-tools/ai-skills/ subdirectory that contains .md files but
  has no README.md

Tier 2 checks (warnings — non-blocking):
- description field over 100 words
- invoke_when triggers that exactly match another skill file's triggers

Commit message: "feat(skill-docs): add skill documentation test suite"

---

COMMIT 3 — Wire into runners

Update tests/run-all.js:
  Add: const skillDocsTests = require('./unit/skill-docs.test');
  Add in runAllTests() after the existing skill/governance block (or after
  componentGovernance if no skill block exists):

  console.log('\n📘 Running Skill Documentation Tests...');
  const skillDocsResult = normalizeSuiteResult(skillDocsTests.runTests({ stagedOnly }));
  totalErrors += skillDocsResult.errors.length;
  totalWarnings += skillDocsResult.warnings.length;
  console.log(`   ${skillDocsResult.errors.length} errors, ${skillDocsResult.warnings.length} warnings`);

Update tests/run-pr-checks.js:
  Register skillDocsTests following the exact pattern of existing suites in that file.

Commit message: "feat(skill-docs): wire skill-docs test into run-all and run-pr-checks"

---

VERIFICATION

Run and report full output:

1. node tests/unit/skill-docs.test.js
   Expected: pass on all existing skill files

2. node tests/run-all.js --staged
   Expected: skill-docs suite appears, zero errors

3. node tests/unit/script-docs.test.js --staged
   Expected: no new failures from committed files

If any check fails: stop and report. Do not self-fix test infrastructure.

---

FORBIDDEN
- Do not modify any .mdx content files
- Do not modify docs.json or navigation-exclusions.json
- Do not modify the .allowlist file
- Do not create a separate CI workflow for this suite
```
