# Livepeer Docs Copy & Content Framework
**Version 1.0 — March 2026**
**Classification: Internal working standard**

---

## Purpose

This framework governs all prose, structure, and copy decisions across the Livepeer documentation system. It applies to every page type: conceptual, evaluative, procedural, and reference.

Its function is not stylistic. It is a quality gate — a structured set of constraints that prevent the most common failure modes in technical product documentation before they reach a reader.

The framework has eight layers. Layers 0–1 run before drafting. Layers 2–4 govern the writing itself. Layers 5–8 govern review, iteration, and repair.

---

## Summary of Layers

| Layer | Name | When it runs |
|---|---|---|
| L0 | Value Proposition Definition | Before brief is written |
| L1 | Persona Path Mapping | Before brief is written |
| L2 | Content Sequence Rules | Before drafting |
| L3 | Paragraph Rules | During drafting |
| L4 | Sentence Banned List | During drafting and review |
| L5 | Publish Gate | Before merge |
| L6 | Iteration Diagnostic Loop | After first failed gate |
| L7 | Pattern Observer | After second failed gate or pattern recurrence |
| L8 | Repair Routing | Output of L7 |

---

## Layer 0 — Value Proposition Definition

**Runs:** Once per section tab or major page cluster. Before any brief is written.
**Owner:** Product owner or documentation lead.

Before a single word of copy is drafted, four questions must be answered in writing. These answers are not published. They constrain every layer below.

---

### The Four Questions

**Q1. What does this product or feature actually do for the operator?**
State the outcome the operator keeps, not the mechanism they operate. One sentence. No conditionals.

> Example: `Livepeer lets GPU operators earn ETH from compute capacity that would otherwise sit idle, without centralised intermediaries extracting margin.`

**Q2. Who is already succeeding with this, and what does their operation look like?**
Defines the aspirational model. The majority real-world path — not an edge case — is the default story.

> Example: `The majority of active operators run hybrid workloads: video transcoding for stable baseline income, AI inference for higher per-job fees on capable hardware. This is the featured path.`

**Q3. What is the reader's real alternative?**
Defines the competitive context. Shapes what the docs must prove.

> Example: `Centralised GPU clouds (Vast.ai, RunPod) with margin extraction and no protocol upside; mining alternatives with declining yields; idle hardware earning nothing.`

**Q4. What does the reader need to believe to take the next step?**
Every page moves the reader toward one belief. State it.

> Example: `Their specific hardware can earn at a rate that clears their cost base, and the path to first earnings is achievable without expert-level knowledge.`

---

### L0 Failure Conditions

L0 is incomplete if any of the following are true:

- Q1 contains a conditional (`if`, `depends on`, `can`)
- Q2 describes an edge case operator as the primary model
- Q3 is left blank or vague
- Q4 is a mechanism statement, not a belief statement

If L0 cannot be completed, no drafting begins. The gap is a product clarity problem, not a writing problem.

---

## Layer 1 — Persona Path Mapping

**Runs:** Once per page. Before drafting.
**Owner:** Documentation lead or brief author.

Map the page to operator reality — hardware, stake position, goal — using functional identifiers, not named personas.

### Mapping Table Format

| Operator profile | Primary question on arrival | What this page must give them |
|---|---|---|
| Single GPU, limited LPT | Can I earn without a large stake? | Pool worker path and AI entry path, both concrete |
| Multi-GPU, existing node | How do I add AI workloads? | Hybrid path as featured model, staged |
| Fleet or data centre operator | What are the economics at scale? | Per-GPU unit economics, Gateway relationship model |
| AI-first, no prior Livepeer | What hardware and which pipelines? | Capability-first routing, no stake prerequisite |

### Rules

- Every row in the mapping table must be served by the page or routed to a linked page.
- Operator profiles use hardware, LPT position, and goal as identifiers. Named personas (A, B, C) are planning tools only — they never appear in published copy or routing language.
- If the page cannot serve all mapped profiles, the page scope is wrong. Split or restructure before drafting.

---

## Layer 2 — Content Sequence Rules

**Runs:** Before drafting begins. Defines page structure.

### Mandatory Sequence for Evaluation and Guide Pages

1. **Operator outcome** — the value kept, stated directly, one sentence, no conditionals
2. **Featured path** — the majority real-world operating model, described in full
3. **Variants** — alternative paths with specific entry requirements
4. **Economics** — cost and revenue, concrete figures, no hedging
5. **Decision aid** — complete, no empty cells, no unresolved flags
6. **Staged action path** — numbered, zero to first outcome
7. **Next page** — one link, the correct next step for the primary reader

### Banned Sequences

- Cost structure before value proposition
- Warning or caveat before opportunity
- Variant paths before the primary path is fully described
- Decision aid with missing data, placeholder text, or unresolved review flags
- Any section that introduces a path without routing it

---

## Layer 3 — Paragraph Rules

**Runs:** During drafting.

- One paragraph, one job. If you cannot label the paragraph's job in three words, split it.
- Lead sentence states the fact. Remaining sentences extend or evidence it.
- Final sentence must be a fact, a number, or a next step — never a hedge, a restatement, or a conditional.
- Tables and diagrams stand alone. Any prose sentence that restates a table row or diagram node is deleted.
- Every introduced path is either developed on the page or linked to a page that develops it.
- High-value URLs and commands appear in body copy. Accordions contain depth, not primary actions.
- Diagram and table combinations: each must show something the other cannot. If they carry identical information, remove one.

---

## Layer 4 — Sentence Banned List

**Runs:** During drafting and at every review pass.

### Banned Constructions

| Construction | Why banned | Replacement |
|---|---|---|
| `not [X]` | Defines value by contrast. Forces reader to hold two things to understand one. | State what it is. Delete the contrast. |
| `not just [X]` | Dismisses a valid option to elevate another. Condescending. | Delete or restate as additive. |
| `rather than` | Contrast-by-diminishment. Same failure mode as `not`. | Delete the contrast clause. State the positive directly. |
| `if [condition]` | Conditional gatekeeping. Makes the reader responsible for a knowledge gap the docs should close. | State the condition as a fact, or remove it. |
| `depends on` | Hedges every claim into uselessness. | State the specific variable. |
| `This page [verb]` / `This section covers` | Announces content instead of delivering it. | Delete. Start with the content. |
| `what it takes` | Hurdle framing. Implies the reader may not qualify. | State the requirements directly. |
| `[value] — if [condition]` | Undercuts the value statement in the same breath. | Split into two sentences. Value first. Requirements second. No dash. |
| `effectively` / `essentially` | False precision. Signals the writer is not confident in the claim. | State the thing directly or delete. |
| `meaningful` / `real` / `significant` | Intensifiers with no information content. | Replace with a number or delete. |
| `consistently` without a number | Vague operational standard. | Add the number or rewrite. |
| `among other factors` | Incomplete claim. Generates reader questions. | Name the factors or delete the clause. |
| `low but not zero` | Restates information already conveyed by numbers. | Give the number. Delete the qualifier. |
| `The X path does not` | Negative comparative. | State what X does. Drop the negative. |
| `can generate` / `may produce` | Weakened value claim. | Assert or delete. |
| `[value] — not preference` | Defends against a criticism nobody made. | Delete. |
| `once [X] is stable` | Delays value on a condition the reader cannot measure. | State the prerequisite as a concrete step. |

### Currency Rule

All monetary examples use USD by default. If content is explicitly region-scoped, state the region once at the section opening and use local currency consistently within that scope. Mixed currencies within a single example are banned.

### Review Flags in Published Copy

`{/* REVIEW: */}` flags are internal signals. They must never appear in rendered content. A page with an unresolved REVIEW flag in a decision-critical position (table cell, decision matrix, numbered step) is blocked from publish until the flag is resolved.

---

## Layer 5 — Publish Gate

**Runs:** Before any page merges to the branch.
**Owner:** Human reviewer.

A page fails the gate if any of the following are true:

- [ ] L0 questions were not answered in the brief before drafting
- [ ] The majority operator path is not the featured path on the page
- [ ] Any sentence uses a banned construction from L4
- [ ] Any decision aid contains an empty cell, placeholder text, or unresolved REVIEW flag
- [ ] Any path introduced on the page has no development or outbound link
- [ ] Any primary action, URL, or command is only accessible inside a collapsed accordion or Note component
- [ ] Any monetary figure uses non-USD currency without explicit regional scope
- [ ] The page opens with cost, warning, or conditional before value
- [ ] Any diagram and table combination carry identical information
- [ ] Any section ends on a hedge, disclaimer, or restatement

---

## Layer 6 — Iteration Diagnostic Loop

**Triggers:** Any page fails L5.

### Decision Tree

```
L5 FAILURE
│
├── Is the same error class appearing in a different sentence?
│   │
│   ├── YES → PATTERN FAILURE
│   │   │
│   │   ├── Appearing in multiple sections?
│   │   │   ├── YES → Writer has not internalised the rule
│   │   │   │         ACTION: Rule reinforcement pass. Route to copy editor.
│   │   │   │
│   │   │   └── NO → Single section keeps failing
│   │   │             │
│   │   │             ├── Evaluation or decision section?
│   │   │             │   ├── YES → PERSONA FAILURE → L7 Persona Check
│   │   │             │   └── NO  → VALUE PROP FAILURE → L7 VP Check
│   │
│   └── NO → New error class appearing
│             │
│             ├── Section not covered by L0 question?
│             │   ├── YES → SCOPE FAILURE
│             │   │         ACTION: Return to brief. Section may not belong on this page.
│             │   │
│             │   └── NO → Covered by L0 but still failing
│             │             │
│             │             ├── Section describes majority operator path?
│             │             │   ├── NO → PATH PRIORITY FAILURE
│             │             │   │        ACTION: Restructure. Majority path must be featured.
│             │             │   │
│             │             │   └── YES → L7 VP Check
```

### Escalation Rule

Two failed fix passes on the same section triggers L7. The writer does not attempt a third sentence-level fix. The failure is diagnosed at the layer above.

---

## Layer 7 — Pattern Observer

**Triggers:** Any pattern appears across 3+ pages, or any single error class survives 2 fix cycles.

The pattern observer does not fix. It reads across sessions, pages, and fix cycles to determine what recurrence means.

### The Four Observer Questions

**1. Frequency**
Is this pattern appearing in one section type or everywhere?
- One section type → structural or IA problem
- Everywhere → value prop or persona definition problem

**2. Author Behaviour**
Is the writer reaching for this construction, or falling back to it?
- Reaching: they are solving a real communication problem the framework is not helping with. Escalate to architecture review.
- Falling back: rule not internalised. Copy editing fix.

**3. What is the pattern protecting?**
What would the copy have to claim, without qualification, if this pattern were removed?
- Claim feels uncertain or uncomfortable → value prop is unresolved upstream
- Claim is clear but avoided → voice or confidence problem

**4. What does the reader lose if this is never fixed?**
- Nothing, they just read worse prose → sentence-level fix, low priority
- They cannot evaluate whether to commit → blocking conversion. Escalate to product owner, not copy editor.

### Pattern Interpretation Table

| Recurring pattern | Linear diagnosis | Pattern observer reading |
|---|---|---|
| `not X` / contrast language persists | Writer hasn't internalised rule | Value prop is not strong enough to stand alone — writer reaches for contrast because there is no clear positive to lead with |
| Conditionals and hedges cluster in one section | Sentence-level fix needed | Section is serving an undefined reader — hedges are the writer covering multiple personas simultaneously |
| `This page covers` persists | Banned construction | Pages do not have a clear single job — writer announces because scope is uncertain |
| Cost or warning language before value persists | Sequence error | Writer does not believe the value prop they are being asked to write |
| Hybrid or majority path keeps being buried | Path priority error | The IA taxonomy was built around edge cases, not majority operator reality |

### Observer Output

The observer produces one of three escalation calls:

- **Copy problem** → route to L4/L5. Writer self-corrects with rule reinforcement.
- **Architecture problem** → route to L1/L2. Page scope or IA needs restructuring.
- **Product clarity problem** → route to L0. Value proposition must be redefined before any copy work continues.

---

## Layer 8 — Repair Routing

**Triggered by:** L7 escalation output.

```
COPY PROBLEM
└── L4 rule reinforcement pass
    └── Re-enter at L5

ARCHITECTURE PROBLEM
└── L1 persona map review
    └── L2 sequence audit
        └── Redraft affected sections
            └── Re-enter at L3

PRODUCT CLARITY PROBLEM
└── L0 VP questions re-answered (with product owner, not writer)
    └── L1 persona map updated if VP shift changes audience
        └── Full page redraft
            └── Re-enter at L2
```

### The Master Sentence Test

Applied to every sentence before it ships:

> Does this sentence give the operator something they can act on, believe, or use to make a decision — stated directly, with no qualifications, contrasts, or conditions?

If no: rewrite or delete.
