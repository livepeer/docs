# Copywriting Governance Framework — Phased Rollout Plan
**Livepeer Docs Copy Framework — Document 6**
**Version 2.0 — March 2026**

---

## Purpose

Defines the effort-impact phasing for implementing the full L0–L8 copy governance framework across the Livepeer documentation system. Prioritised by value delivered per unit of effort, not by technical sequence alone.

---

## Effort-Impact Matrix

| Initiative | Effort | Impact | Phase |
|---|---|---|---|
| Brief template with L0/L1 gates | Low | High — stops bad content at source | 1 |
| Banned word/phrase lint script | Low | High — catches most common errors automatically | 1 |
| copy-rules SKILL.md | Low | High — constrains agent drafts from first use | 1 |
| L5 PR checklist (structural items) | Low | High — human gate before every merge | 1 |
| structure-rules SKILL.md | Medium | High — enforces sequence and paragraph discipline | 2 |
| value-prop-check SKILL.md | Medium | High — L0 gate for all new briefs | 2 |
| Full CI integration (Tier 1 block) | Medium | High — automated enforcement at merge | 2 |
| Frontmatter-driven enforcement depth | Medium | Medium — scales enforcement by page type | 2 |
| persona-routing SKILL.md | Medium | Medium — functional routing in drafts | 2 |
| Pattern observer (cross-page analysis) | High | High — catches systemic IA/VP failures | 3 |
| iteration-diagnostic + repair-routing SKILLs | High | Medium — needed only when L5 fails repeatedly | 3 |
| Tier 2 CI patterns (conditional, `not X`) | High | Medium — higher false-positive risk; needs tuning | 3 |
| L7 scheduled cross-tab reporting | High | High at scale — requires volume of merged content first | 3 |

---

## Phase 1 — Maximum Value, Minimum Infrastructure
**Target: 1–2 weeks. No new tooling dependencies.**

These four items stop the most common errors before they enter the repo, using only text files and a brief template update.

### P1-A: Brief Template — L0/L1 Gates
Add two required sections to the Codex brief template:
- L0: four VP questions (required fields; brief is not submitted without them)
- L1: persona path mapping table (functional identifiers; not named personas)

**Output:** Updated `content-brief-template.md`. Applied to all new briefs from this point.

---

### P1-B: Banned Word/Phrase Lint Script
Build `tools/scripts/lint-copy.js` against the Part B audit in Document 3.
Tier 1 only at this phase: exact banned word and phrase matches.
Run locally before PR; add to CI as warning (not yet blocking) until false-positive rate is validated.

**Output:** `lint-copy.js` + `reference/banned-words.txt` + `reference/banned-phrases.txt`

---

### P1-C: copy-rules SKILL.md
Single skill file covering L4 banned list and the master sentence test.
Loaded by Codex before any content drafting task.
Imports from the same banned reference files as the lint script — single source of truth.

**Output:** `ai-tools/ai-skills/docs-copy/skills/copy-rules.md`

---

### P1-D: L5 PR Checklist
Ten-item structural checklist added to the PR template.
Human reviewer signs off before merge.
Items that are script-checkable are marked as auto; items requiring human judgement are marked as manual.

**Output:** Updated `.github/pull_request_template.md` for docs-v2

---

## Phase 2 — Full Structural Enforcement
**Target: 3–4 weeks. Requires Phase 1 stable.**

Closes the gap between sentence-level rules and structural/sequence failures.

### P2-A: value-prop-check + structure-rules SKILLs
Two skill files covering L0 pre-brief questions and L2/L3 sequence and paragraph rules.
Composable with copy-rules.md — all three loaded for full-framework drafting tasks.

### P2-B: CI Tier 1 blocking
Promote lint-copy.js Tier 1 from warning to merge-blocking once false-positive rate confirmed below 5% on a sample of 20 existing pages.

### P2-C: Frontmatter-driven enforcement depth
CI reads `pageType` from frontmatter and applies:
- `guide` / `evaluation` → full L0+L5 gate
- `concept` → structural items only
- `reference` → Tier 1 lint only

### P2-D: persona-routing SKILL.md
Functional routing rules for multi-profile pages.
Loaded for any page serving more than one operator profile.

### P2-E: lint-structure.js
Checks: empty TableCell in decision context, missing/stale frontmatter fields, REVIEW flags in rendered content.
Tier 1: blocks merge.

---

## Phase 3 — Systemic Pattern Governance
**Target: 6–8 weeks. Requires Phase 2 stable and 20+ pages merged under framework.**

These items are high-effort and high-impact but require volume of framework-governed content before they are meaningful.

### P3-A: Pattern Observer — Scheduled Cross-Tab Report
L7 logic run across all merged pages within a tab. Produces a pattern report identifying:
- Recurring banned constructions (writer internalisation gap)
- Structural recurrence (IA problem)
- Clustered conditionals/hedges (VP definition gap)

Run cadence: per tab at completion, then monthly.

### P3-B: Iteration Diagnostic + Repair Routing SKILLs
L6 and L8 skill files. Invoked only when a section fails L5 twice.
Lower priority than P3-A — most pages should not need them if Phase 1/2 are working.

### P3-C: Tier 2 CI Patterns
Regex-based checks for `if` in body prose, `not [X]` constructions, weakened value claims.
Higher false-positive risk — must be tuned against real content before enabling.
Warn-only; human sign-off required per flag.

### P3-D: L7 Tooling
Lightweight script to aggregate L5 failure types across all pages in a tab and surface recurrence patterns. Input to the human pattern observer session.

---

## What This Phasing Achieves

| After Phase 1 | After Phase 2 | After Phase 3 |
|---|---|---|
| Bad sentences caught in draft by agent | Bad structure caught before merge | Systemic VP and IA problems caught across tabs |
| Brief author held to L0 before drafting | CI blocks Tier 1 violations | Pattern recurrence identified and diagnosed |
| Human gate on every merge | Page type drives enforcement depth | Cross-tab pattern reports inform IA decisions |
| Most common errors eliminated from new content | Structural sequence failures eliminated | Framework self-reinforcing at scale |

---

## Gates Between Phases

**Phase 1 → Phase 2:** lint-copy.js runs clean on 5 pages without false positives. Brief template in active use for at least 3 new briefs.

**Phase 2 → Phase 3:** 20+ pages merged under framework. CI Tier 1 blocking live. L5 gate pass rate above 80% on first submission (i.e., not needing multiple fix cycles).

---

## What Is Out of Scope for This Framework

- Content accuracy / SME verification (separate review gate)
- SEO keyword strategy (separate workstream)
- Translation and localisation (separate pipeline)
- Visual design and component choices (Design Governance Framework)
