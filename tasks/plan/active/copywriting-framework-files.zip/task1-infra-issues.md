# Infrastructure Issues — Pre-Implementation Checklist
**Livepeer Docs Copy Framework**
**Version 1.0 — March 2026**

---

## Critical blockers (must resolve before any file is created)

---

**ISSUE 1 — Script JSDoc headers are enforced and will break CI**

`tests/unit/script-docs.test.js` runs on every commit via pre-commit hook and PR checks.
Every file in `tools/scripts/` must carry the full `@script` header block.

All four new scripts lack these headers as currently written:
- `tools/scripts/lint-copy.js`
- `tools/scripts/lint-structure.js`
- `tools/scripts/lint-patterns.js`
- `tools/scripts/pattern-observer.js`

Required fields (from `run-all.js` example):
```
@script
@category
@purpose
@scope
@owner
@needs          (requirement ID — see below)
@purpose-statement
@pipeline
@usage
```

**Question to answer:** What requirement IDs (`@needs`) should these scripts reference?
The existing runner references `R-R29`. New scripts need valid IDs registered in the
script classification system or CI will reject them.

---

**ISSUE 2 — `tests/run-all.js` cannot be duplicated or bypassed**

The test runner is the canonical entry point for all test suites, wired into
the pre-commit hook at `.githooks/pre-commit`. A separate `tests/copy-lint/run-all.js`
will not be picked up by the hook or CI.

New copy lint tests must follow the existing pattern:
- File location: `tests/unit/copy-lint.test.js`
- Exports: `{ runTests({ stagedOnly }) }` returning `{ errors: [], warnings: [] }`
- Registration: one `require` + one `normalizeSuiteResult` call added to `run-all.js`
- `run-pr-checks.js` also needs the suite added for PR-scoped runs

The standalone fixture runner from Doc 10 (`run-all.js`) must be renamed
`run-copy-lint-fixtures.js` and placed in `tests/` as a development utility only —
not wired into the main runner.

---

**ISSUE 3 — `docs-guide/` has a SOT test that will fail on new unregistered files**

`tests/unit/docs-guide-sot.test.js` validates coverage, README pointers, and generated
index freshness for everything inside `docs-guide/`.

`tools/scripts/generate-docs-guide-indexes.js` generates the docs-guide index.

Adding `content-brief-template.md` to `docs-guide/tooling/` without registering it
will cause the SOT test to fail.

**Questions to answer:**
- Does `docs-guide/tooling/` exist? (zip only contained `component-registry.json` and `.DS_Store`)
- What is the registration mechanism — does the file need an entry in a manifest,
  or does the index generator pick it up automatically by scanning the directory?
- Run `node tools/scripts/generate-docs-guide-indexes.js --write` after adding the
  brief template, then confirm SOT test passes.

---

**ISSUE 4 — CI workflow conflict: `lint-copy.yml` should not be created**

The repo already has `test-suite.yml` as the canonical PR enforcement workflow,
with `tests/run-pr-checks.js` as its entry point (confirmed in `quality-gates.md`).

Creating a separate `lint-copy.yml` workflow creates two overlapping CI surfaces
and violates the single-owner CI contract from `TECH_AUDIT.md` Priority 3.

New checks belong in `test-suite.yml` via `run-pr-checks.js`, not in a new workflow file.

**Action:** Delete `lint-copy.yml` from the implementation plan.
Register the copy-lint suite in `run-pr-checks.js` instead.

---

**ISSUE 5 — `tools/scripts/lib/` subdirectory does not exist**

The `scripts-index.md` shows `tools/scripts/` organises files into:
`dev/`, `test/`, `validators/`, `snippets/`, `remediators/`, `generate-*`

There is no `lib/` subdirectory in the tracked index. Creating it will trigger
the script audit (`audit-scripts.js`) and possibly the docs-guide SOT check.

**Resolution:** Place reference files at one of:
- `tools/scripts/validators/content/` (consistent with existing validator pattern)
- `tools/lib/` (existing lib location — confirmed by `tools/lib/docs-usefulness/` in memory)

`tools/lib/` is the correct location. Update all `require('./lib/...')` paths in scripts
to `require('../../lib/copy-governance/...')` or equivalent.

---

**ISSUE 6 — `frontmatter-taxonomy.test.js` already validates frontmatter**

`tests/unit/frontmatter-taxonomy.test.js` runs in the main suite and PR checks.
`lint-structure.js` duplicates frontmatter field validation (`pageType`, `audience`,
`lastVerified`).

**Risk:** Two tests producing conflicting errors for the same frontmatter field
causes reviewer confusion and inflates error counts in CI summary.

**Question to answer:** What does `frontmatter-taxonomy.test.js` currently validate?
Check before running to confirm whether `lint-structure.js` frontmatter checks
should be removed or scoped to copy-governance-specific fields only.

---

**ISSUE 7 — `style-guide.test.js` and `docs-authoring-rules.test.js` may already cover some banned constructions**

Both suites run in the main runner and cover style and authoring rules for MDX content.
The copy framework banned word/phrase checks may duplicate existing rules.

**Risk:** Same violation flagged twice in CI output — confuses the writer about
which system to fix.

**Questions to answer:**
- What banned words/phrases does `style-guide.test.js` currently check?
- What authoring rules does `docs-authoring-rules.test.js` enforce?
- Identify overlap before running `lint-copy.js` in parallel.
- Either deduplicate (move existing rules into the new reference files as the
  single source) or scope `lint-copy.js` to copy-governance rules not covered elsewhere.

---

**ISSUE 8 — PR template may already have enforcement content from Sprint 2**

`Script_Audit_9_March.md` confirms Sprint 2 added PR template enforcement.
`quality-gates.md` lists it under Sprint 2 completed work.

Appending the L5 checklist without reading the existing template risks:
- Duplicating checklist items already present
- Creating conflicting formatting
- Breaking the PR template enforcement test if it validates structure

**Action:** Read the existing `.github/pull_request_template.md` before modifying.
Integrate L5 items into the existing structure, do not append blindly.

---

**ISSUE 9 — `ai-tools/ai-skills/` directory existence unconfirmed**

The zip contained only `docs-guide/` contents. The `ai-tools/` tree is not confirmed.

**Questions to answer:**
- Does `ai-tools/ai-skills/` exist on `docs-v2`?
- If it does, does it contain existing skill files that would be affected by
  adding `docs-copy/`?
- The TECH_AUDIT layer taxonomy lists `ai-tools/` as an existing surface (E7).
  Confirm the canonical path before the agent creates the directory.

---

**ISSUE 10 — `@needs` requirement IDs must be valid**

The `@needs` field in script headers references requirement IDs registered in the
script classification system. `run-all.js` references `R-R29`.

New scripts added without valid `@needs` IDs will fail `script-docs.test.js`.

**Question to answer:** Are new requirement IDs needed, or can the copy governance
scripts reference an existing umbrella ID? Ask Rick before the agent runs.

---

**ISSUE 11 — `pattern-observer.js` writes to `reports/` — confirm the directory and ownership**

`pattern-observer.js` outputs to `tasks/reports/` or a `reports/` directory.
The HANDOFF-A report confirms `tasks/reports/` is the canonical report location,
with specific ownership per report type.

A new `reports/pattern-report-YYYY-MM-DD.md` output has no registered owner or
location in the current report taxonomy.

**Resolution:** Pattern observer output should go to
`tasks/reports/copy-governance/pattern-report-YYYY-MM-DD.md` and be registered
in the report taxonomy. Confirm with Rick.

---

## Lower risk — confirm before running

**ISSUE 12 — `tasks/scripts/` vs `tools/scripts/`**
New automation scripts belong in `tools/scripts/` (repo automation engine per TECH_AUDIT E8).
`tasks/scripts/` is for task-specific one-off scripts. All four lint scripts: `tools/scripts/`.

**ISSUE 13 — `run-pr-checks.js` scoping**
PR checks run on changed files only (`--staged` flag). Copy lint tests must respect
`stagedOnly` mode or they will scan the full repo on every PR.
The `runTests({ stagedOnly })` signature handles this — confirm implementation.

**ISSUE 14 — Spelling test overlap**
`tests/unit/spelling.test.js` runs on content files. Some banned words (e.g. `basically`,
`obviously`) may already be flagged as informal/non-technical vocabulary.
Check before adding to the banned list to avoid double-flagging.
