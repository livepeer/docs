# Testing Framework Implementation
**Livepeer Docs Copy Framework — Document 10**
**Version 1.0 — March 2026**

---

## Scope

Implements T1–T5 from Doc 5 as executable test infrastructure:

- **T3:** Automated script test suite with fixture files (runs in CI)
- **T4:** Agent compliance test harness
- **T1, T2, T5:** Human review protocols with checklists and scenario scripts

---

# T3: Script Test Suite

## File structure

```
tests/copy-lint/
├── run-all.js                          # Test runner
├── fixtures/
│   ├── pass/
│   │   ├── clean-guide.mdx             # Zero violations expected
│   │   ├── clean-reference.mdx         # Reference page — Tier 1 only
│   │   └── clean-concept.mdx           # Concept page — structural only
│   └── fail/
│       ├── banned-words.mdx            # Tier 1: banned words
│       ├── banned-phrases.mdx          # Tier 1: banned phrases
│       ├── review-flag.mdx             # Tier 1: REVIEW flag in rendered content
│       ├── currency.mdx                # Tier 1: non-USD currency
│       ├── empty-table-cell.mdx        # Tier 1: empty decision table cell
│       ├── missing-frontmatter.mdx     # Tier 1: missing pageType/audience
│       ├── accordion-url-only.mdx      # Tier 2: primary URL gated in accordion
│       ├── hedge-note.mdx              # Tier 2: hedge Note ending section
│       ├── conditional-if.mdx          # Tier 2: if in body prose
│       └── not-construction.mdx        # Tier 2: not [X] construction
└── expected/
    ├── banned-words.json               # Expected error IDs and line numbers
    ├── banned-phrases.json
    └── [one per fail fixture]
```

---

## Fixture files

### pass/clean-guide.mdx

```mdx
---
title: 'Pool Worker Setup'
sidebarTitle: Pool Worker Setup
description: 'Earn ETH from GPU compute by joining an existing Orchestrator pool.'
pageType: guide
audience: orchestrator
purpose: setup
status: current
lastVerified: '2026-03-15'
---

Joining a pool earns ETH from GPU compute without acquiring LPT or managing
on-chain operations. The pool Orchestrator handles registration, reward calling,
and Gateway relationships. You contribute compute and receive a share of job fees.

## Prerequisites

- NVIDIA GPU (any model with NVENC support)
- 100 Mbps stable connection
- go-livepeer installed

## Steps

1. Choose a pool from the active pool list at [tools.livepeer.cloud](https://tools.livepeer.cloud).
2. Run go-livepeer with the pool's Orchestrator address as `-orchAddr`.
3. Verify your worker appears in the pool dashboard within 10 minutes.

See [Pool Worker Reference](/v2/orchestrators/reference/pool-worker) for
full flag documentation.
```

---

### fail/banned-words.mdx

```mdx
---
title: 'Test — Banned Words'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

Pool operators are effectively GPU infrastructure businesses.
The setup is essentially straightforward for experienced operators.
This produces meaningful returns on existing hardware.
Various configuration options are available.
```

**Expected errors:**
- Line 7: `effectively` — BANNED_WORD
- Line 8: `essentially` — BANNED_WORD
- Line 9: `meaningful` — BANNED_WORD
- Line 10: `various` — BANNED_WORD

---

### fail/banned-phrases.mdx

```mdx
---
title: 'Test — Banned Phrases'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

This page covers how commercial operators earn service fees.
The reason is straightforward: fee income scales with volume.
Understanding both revenue streams is essential before modelling ROI.
Revenue depends on various factors including pipeline demand.
```

**Expected errors:**
- Line 7: `This page covers` — BANNED_PHRASE
- Line 8: `The reason is straightforward` — BANNED_PHRASE
- Line 9: `Understanding ... is essential` — BANNED_PHRASE
- Line 10: `depends on various` — BANNED_PHRASE

---

### fail/review-flag.mdx

```mdx
---
title: 'Test — Review Flag'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

<StyledTable>
  <tbody>
    <TableRow>
      <TableCell>Solo video Orchestrator</TableCell>
      <TableCell>{/* REVIEW: confirm active set threshold */}</TableCell>
    </TableRow>
  </tbody>
</StyledTable>
```

**Expected errors:**
- Line 12: `{/* REVIEW:` — REVIEW_FLAG_RENDERED (Tier 1 block)

---

### fail/currency.mdx

```mdx
---
title: 'Test — Currency'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

At £800 for an RTX 4090 and £30 per month in rewards,
the hardware break-even exceeds two years.
```

**Expected errors:**
- Line 7: `£` — CURRENCY_NON_USD (×2)

---

### fail/empty-table-cell.mdx

```mdx
---
title: 'Test — Empty Table Cell'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

## Decision Matrix

<StyledTable>
  <thead>
    <TableRow header>
      <TableCell header>Path</TableCell>
      <TableCell header>LPT required</TableCell>
    </TableRow>
  </thead>
  <tbody>
    <TableRow>
      <TableCell>Solo video Orchestrator</TableCell>
      <TableCell></TableCell>
    </TableRow>
  </tbody>
</StyledTable>
```

**Expected errors:**
- Line 20: `<TableCell></TableCell>` — EMPTY_DECISION_CELL (Tier 1 block)

---

### fail/missing-frontmatter.mdx

```mdx
---
title: 'Test — Missing Frontmatter'
lastVerified: '2026-03-15'
---

Content here.
```

**Expected errors:**
- Line 1: `pageType` missing — MISSING_FRONTMATTER
- Line 1: `audience` missing — MISSING_FRONTMATTER

---

### fail/accordion-url-only.mdx

```mdx
---
title: 'Test — Accordion URL Only'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

Before selecting capabilities, choose wisely.

<Accordion title="Capability selection">
  Check current demand at https://tools.livepeer.cloud/ai/network-capabilities
  before loading any models.
</Accordion>
```

**Expected warnings:**
- Line 11: `https://tools.livepeer.cloud/ai/network-capabilities` — ACCORDION_ONLY_URL (Tier 2)

---

### fail/hedge-note.mdx

```mdx
---
title: 'Test — Hedge Note'
pageType: guide
audience: orchestrator
lastVerified: '2026-03-15'
---

## Commercial Operators

Pool operators manage fleets of GPU workers on behalf of participants.

<Note>
The commercial orchestrator landscape is evolving and may change.
We cannot guarantee accuracy of the operator list above.
</Note>
```

**Expected warnings:**
- Line 12: `is evolving` / `may change` — HEDGE_NOTE (Tier 2 ×2)

---

## Test runner: run-all.js

**Path:** `tests/copy-lint/run-all.js`

```javascript
#!/usr/bin/env node

/**
 * run-all.js
 * Livepeer Docs Copy Framework — test runner
 *
 * Runs lint-copy.js and lint-structure.js against fixture files.
 * Compares output against expected/ JSON files.
 * Exits 0 if all tests pass, 1 if any fail.
 *
 * Usage:
 *   node tests/copy-lint/run-all.js
 *   node tests/copy-lint/run-all.js --verbose
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const FIXTURES_PASS = path.join(__dirname, 'fixtures/pass');
const FIXTURES_FAIL = path.join(__dirname, 'fixtures/fail');
const EXPECTED_DIR = path.join(__dirname, 'expected');

let passed = 0;
let failed = 0;
const verbose = process.argv.includes('--verbose');

function runLint(scriptName, filePath, warnOnly = true) {
  try {
    const flag = warnOnly ? '--warn-only' : '';
    const out = execSync(
      `node tools/scripts/${scriptName} ${filePath} ${flag}`,
      { encoding: 'utf8', stdio: 'pipe' }
    );
    return { stdout: out, stderr: '', exitCode: 0 };
  } catch (err) {
    return { stdout: err.stdout || '', stderr: err.stderr || '', exitCode: err.status || 1 };
  }
}

function extractErrorIds(output) {
  const ids = [];
  const lines = output.split('\n');
  lines.forEach(line => {
    const match = line.match(/\[L\d+\]\s+([A-Z_]+):/);
    if (match) ids.push(match[1]);
  });
  return ids;
}

function test(label, fn) {
  try {
    fn();
    console.log(`  ✅  ${label}`);
    passed++;
  } catch (err) {
    console.error(`  ❌  ${label}`);
    if (verbose) console.error(`      ${err.message}`);
    failed++;
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

// ─── Pass fixtures — expect zero errors ───────────────────────────────────────

console.log('\n── Pass fixtures (expect zero errors) ──────────────────────');

fs.readdirSync(FIXTURES_PASS).forEach(file => {
  const filePath = path.join(FIXTURES_PASS, file);

  test(`${file} — lint-copy produces no errors`, () => {
    const result = runLint('lint-copy.js', filePath);
    const ids = extractErrorIds(result.stdout + result.stderr);
    assert(ids.length === 0, `Expected zero errors, got: ${ids.join(', ')}`);
  });

  test(`${file} — lint-structure produces no errors`, () => {
    const result = runLint('lint-structure.js', filePath);
    const ids = extractErrorIds(result.stdout + result.stderr);
    assert(ids.length === 0, `Expected zero errors, got: ${ids.join(', ')}`);
  });
});

// ─── Fail fixtures — expect specific error IDs ────────────────────────────────

console.log('\n── Fail fixtures (expect specific errors) ──────────────────');

const failFiles = fs.readdirSync(FIXTURES_FAIL);

failFiles.forEach(file => {
  const filePath = path.join(FIXTURES_FAIL, file);
  const expectedFile = path.join(EXPECTED_DIR, file.replace('.mdx', '.json'));

  if (!fs.existsSync(expectedFile)) {
    console.warn(`  ⚠️   ${file} — no expected/ file found, skipping`);
    return;
  }

  const expected = JSON.parse(fs.readFileSync(expectedFile, 'utf8'));

  // Run both scripts
  const copyResult = runLint('lint-copy.js', filePath);
  const structResult = runLint('lint-structure.js', filePath);
  const allOutput = copyResult.stdout + copyResult.stderr +
                    structResult.stdout + structResult.stderr;
  const foundIds = extractErrorIds(allOutput);

  expected.errors.forEach(({ id, required }) => {
    if (required === false) return; // optional — just document
    test(`${file} — produces ${id}`, () => {
      assert(
        foundIds.includes(id),
        `Expected error ID "${id}" not found. Got: [${foundIds.join(', ')}]`
      );
    });
  });

  test(`${file} — produces no unexpected errors`, () => {
    const expectedIds = expected.errors.map(e => e.id);
    const unexpected = foundIds.filter(id => !expectedIds.includes(id));
    assert(
      unexpected.length === 0,
      `Unexpected error IDs: ${unexpected.join(', ')}`
    );
  });
});

// ─── Summary ──────────────────────────────────────────────────────────────────

console.log(`\n── Results ──────────────────────────────────────────────────`);
console.log(`Passed: ${passed}`);
console.log(`Failed: ${failed}`);
console.log(`────────────────────────────────────────────────────────────\n`);

process.exit(failed > 0 ? 1 : 0);
```

---

## Expected output files

### expected/banned-words.json

```json
{
  "fixture": "banned-words.mdx",
  "errors": [
    { "id": "BANNED_WORD", "line": 7, "match": "effectively", "required": true },
    { "id": "BANNED_WORD", "line": 8, "match": "essentially", "required": true },
    { "id": "BANNED_WORD", "line": 9, "match": "meaningful", "required": true },
    { "id": "BANNED_WORD", "line": 10, "match": "various", "required": true }
  ]
}
```

### expected/review-flag.json

```json
{
  "fixture": "review-flag.mdx",
  "errors": [
    { "id": "REVIEW_FLAG_RENDERED", "line": 12, "required": true }
  ]
}
```

### expected/currency.json

```json
{
  "fixture": "currency.mdx",
  "errors": [
    { "id": "CURRENCY_NON_USD", "line": 7, "required": true }
  ]
}
```

### expected/empty-table-cell.json

```json
{
  "fixture": "empty-table-cell.mdx",
  "errors": [
    { "id": "EMPTY_DECISION_CELL", "line": 20, "required": true }
  ]
}
```

### expected/missing-frontmatter.json

```json
{
  "fixture": "missing-frontmatter.mdx",
  "errors": [
    { "id": "MISSING_FRONTMATTER", "match": "pageType", "required": true },
    { "id": "MISSING_FRONTMATTER", "match": "audience", "required": true }
  ]
}
```

### expected/accordion-url-only.json

```json
{
  "fixture": "accordion-url-only.mdx",
  "errors": [
    { "id": "ACCORDION_ONLY_URL", "line": 11, "required": true }
  ]
}
```

### expected/hedge-note.json

```json
{
  "fixture": "hedge-note.mdx",
  "errors": [
    { "id": "HEDGE_NOTE", "line": 12, "required": true }
  ]
}
```

---

## CI integration

Add to `.github/workflows/lint-copy.yml`:

```yaml
  test-suite:
    name: Lint script test suite
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Run fixture tests
        run: node tests/copy-lint/run-all.js
```

Test suite runs on every PR. If a script change breaks a fixture, the suite fails before the script reaches production content.

---

# T4: Agent Compliance Test

## Purpose

Measures the delta between unaided drafts and skill-guided drafts.
Establishes a baseline violation rate. Documents what the SKILL.md files actually prevent.

## Test harness: agent-compliance-test.md

**Path:** `tests/agent-compliance/agent-compliance-test.md`

```markdown
# Agent Compliance Test — T4

## Instructions for test runner

Run this test when:
- SKILL.md files are first introduced
- Any SKILL.md file is updated
- A new Codex task format is introduced

Record results in: tests/agent-compliance/results/YYYY-MM-DD.md

---

## Prompt A — Unaided draft (no skills loaded)

Prompt:
> Write a 200-word evaluation section for a GPU operator considering
> whether to run AI inference workloads on their existing hardware.
> They have an RTX 4090 and no prior Livepeer experience.

Run this prompt with no SKILL.md files loaded.
Save the raw output to: results/YYYY-MM-DD-unaided.md

---

## Prompt B — Skill-guided draft (copy-rules + structure-rules + value-prop-check)

Load:
- ai-tools/ai-skills/docs-copy/skills/copy-rules.md
- ai-tools/ai-skills/docs-copy/skills/structure-rules.md
- ai-tools/ai-skills/docs-copy/skills/value-prop-check.md

Same prompt as Prompt A.
Save the raw output to: results/YYYY-MM-DD-guided.md

---

## Scoring

Run both outputs through lint-copy.js and lint-patterns.js --warn-only.
Record:

| Metric | Unaided | Guided | Delta |
|---|---|---|---|
| Tier 1 violations | | | |
| Tier 2 pattern warnings | | | |
| Banned word hits | | | |
| Banned phrase hits | | | |
| Conditional (`if`) count | | | |
| `not [X]` constructions | | | |
| Opens with operator outcome (Y/N) | | | |
| Majority path featured (Y/N) | | | |

---

## Pass criteria

Guided output must achieve:
- Zero Tier 1 violations
- Tier 2 warnings reduced by at least 50% vs unaided
- Opens with operator outcome (not mechanism or cost)
- No `not [X]` constructions

If guided output fails: SKILL.md files need revision before use in Codex tasks.

---

## Retest trigger

Retest whenever:
- Any skill file is edited
- A new banned word or phrase is added to the reference files
- Tier 2 violation rate in production content rises above 10 per 10 pages
```

---

# T1 + T2 + T5: Human Review Protocols

## T1 — Retrospective Audit Protocol

**Path:** `tests/human-review/t1-retrospective-audit.md`

```markdown
# T1 Retrospective Audit — Human Review Protocol

## Purpose
Validate that existing pages pass L0 and L5.
Identify product clarity gaps before new briefs are written for the same tab.

## Procedure

For each page under audit:

### Step 1: L0 check (10 minutes per page)
Attempt to answer Q1–Q4 from the content as written.
Do not consult the original brief — answer from the page alone.

Record:
- Q1 answerable? (Y/N) If N: product clarity gap.
- Q2 answerable? Is the majority path featured? (Y/N) If N: architecture gap.
- Q3 answerable? (Y/N) If N: product clarity gap.
- Q4 answerable? (Y/N) If N: product clarity gap.

### Step 2: L5 gate (15 minutes per page)
Apply the L5 checklist from the PR template.
Record every failure with layer and rule reference.

### Step 3: Script run (2 minutes per page)
Run lint-copy.js and lint-structure.js.
Record all Tier 1 and Tier 2 outputs.

### Step 4: Classify gaps
For each failure, assign:
- COPY (sentence-level fix)
- ARCHITECTURE (page structure or IA)
- PRODUCT CLARITY (L0 unanswerable)

### Output
One audit report per page:
- L0 completion status
- L5 failures by category and rule
- Script output summary
- Gap classification and recommended repair route (L8)

## Pass criteria for the tab
80%+ of pages pass L0 without escalation.
If below 80%: product clarity session with product owner before new briefs.
```

---

## T2 — Gap Detection Protocol

**Path:** `tests/human-review/t2-gap-detection.md`

```markdown
# T2 Gap Detection — Controlled Failure Test

## Purpose
Verify the framework identifies known structural gaps through the
correct diagnostic route, not incidentally.

## Test scenario

Take a page where a known gap exists (introduced path not developed,
majority path buried, or L0 Q2 unanswerable).

Apply the framework in sequence:
1. L0 check → does it surface the gap at Q2?
2. L5 gate → does it surface the gap as a structural failure?
3. L7 pattern observer questions → does it route to PRODUCT CLARITY?

## Pass criteria
The framework must identify a buried majority path as a PRODUCT CLARITY
escalation (L0 Q2 failure) — not as a COPY problem (L4 sentence fix).

If it routes to COPY: the L7 Q3 question ("what is the pattern protecting?")
needs strengthening. The fail signal for Q3 is too weak to distinguish
structural from surface errors.

## Record
Document the routing path taken for each gap type:
- Buried majority path → expected: PRODUCT CLARITY
- Section serving undefined reader → expected: ARCHITECTURE
- Banned construction recurring → expected: COPY (if isolated) or PRODUCT CLARITY (if widespread)
```

---

## T5 — Iteration Loop Scenario Test

**Path:** `tests/human-review/t5-iteration-loop.md`

```markdown
# T5 Iteration Loop — Scenario Test

## Purpose
Confirm that two failed fix passes escalate correctly through L6/L7
rather than looping at L4 indefinitely.

## Scenario

Take a section with a known structural problem
(e.g. cost before value, abandoned path, undefined reader).

Pass 1: Apply sentence-level fixes only (L4).
Re-run L5 gate. Record: does it still fail?

Pass 2: Apply sentence-level fixes again.
Re-run L5 gate. Record: does it still fail?

After pass 2 failure: run iteration-diagnostic.md (L6).
Record: which branch does it route to?
Run pattern-observer.md (L7) if pattern recurrence indicated.
Record: escalation output (COPY / ARCHITECTURE / PRODUCT CLARITY).

## Pass criteria
After two sentence-level passes, the loop routes to L2 (architecture)
or L0 (product clarity) — not back to L4.

If it routes to L4 a third time: L6 diagnostic tree needs an additional
branch checking whether the section's structural problem was ever addressed.

## Record
For each scenario run:
- Section type (evaluation / decision / procedure)
- Error class that persisted
- Pass 1 result
- Pass 2 result
- L6 routing output
- L7 escalation output (if triggered)
- Correct route (Y/N)
```
