# Testing Framework
**Livepeer Docs Copy Framework — Document 5**
**Version 1.0 — March 2026**

---

## Purpose

This document defines how the framework is validated — both as a system (does it work?) and against existing content (does existing content pass?). It also defines the human review cycle: who reviews, what they review, how many passes, and what constitutes done.

---

## Test Categories

| Category | What it tests | Method |
|---|---|---|
| T1: Retrospective audit | Do existing pages pass L0 and L5? | Human review against framework |
| T2: Gap detection | Does the framework identify known structural gaps? | Controlled test against known failures |
| T3: Script enforcement | Do lint scripts catch all Tier 1/2 patterns? | Automated test suite |
| T4: Agent compliance | Does the SKILL.md produce compliant drafts? | Agent output audit |
| T5: Iteration loop | Does L6/L7 route correctly when fixes fail? | Scenario testing |

---

## T1: Retrospective Audit — Existing Pages

### Purpose
Validate that L0 answers exist and are correct for pages already drafted. Confirm that framework identification of gaps matches ground truth.

### Test 1a — operator-rationale.mdx and business-case.mdx

**Procedure:**
1. Apply L0 questions to both files as if writing the brief now.
2. Document whether Q1–Q4 can be answered from the content as written.
3. Flag any question that cannot be answered — this indicates a product clarity gap, not a copy gap.
4. Apply L5 gate checklist to both files.
5. Record every failure with the specific layer and rule.

**Expected findings (hypothesis to test):**
- Q2 (featured majority path) cannot be answered correctly for either file — the hybrid operator model is not featured
- L5 failures: REVIEW flag in decision table, cost before value sequence, at least 8 banned constructions per file
- The hybrid path gap will be identified as a product clarity problem (L0 Q2), not a copy problem

**Pass criteria:**
The framework identifies the hybrid path gap as a Q2 failure before any copy-level analysis. If the framework only surfaces it as a copy issue (buried footnote, missing link), the L7 pattern observer is not working correctly.

**This test answers:** Would our framework have caught the hybrid path problem before drafting began?

---

### Test 1b — GPU Nodes tab (pre-brief)

**Procedure:**
1. Attempt to answer L0 Q1–Q4 for the GPU Nodes tab before any brief is written.
2. Document which questions can be answered and which cannot.
3. If Q2 (featured majority path) cannot be answered: this is the first output — a product clarity problem that blocks drafting.

**Pass criteria:**
L0 cannot be completed without a defined majority operator path. This should produce a clear escalation to the product owner rather than a draft brief with gaps.

**This test answers:** Does L0 function as an actual gate, or does drafting proceed around it?

---

## T2: Gap Detection — Controlled Failure Test

### Purpose
Verify that the framework identifies known structural problems — specifically the hybrid path gap — through the correct diagnostic route, not incidentally.

### Test 2a — Hybrid path as L7 trigger

**Setup:**
Take the current `business-case.mdx`. Count occurrences of the hybrid model being introduced but not developed. Apply L7 pattern observer questions.

**Expected route:**
1. Pattern: introduced path not routed — appears once (Issue 5.3)
2. L7 Q1 (frequency): appears in one section → structural problem
3. L7 Q3 (what is the pattern protecting?): removing the footnote forces the claim that hybrid IS the primary model — this feels uncomfortable because L0 Q2 was never answered for this page
4. L7 Q4 (reader loss): reader cannot evaluate the most common operating model → blocking conversion → escalate to product owner
5. Output: product clarity problem → L8 repair → L0 re-answer with product owner

**Pass criteria:**
The framework routes this as a product clarity problem (L0), not a copy problem (L4). If it routes to L4, the L7 interpreter needs adjustment.

---

### Test 2b — Recurrence detection

**Setup:**
Introduce a known banned construction (`not [X]`) into three separate pages. Run the pattern observer.

**Expected route:**
1. L5 gate: flags on all three pages
2. L6: same error class, multiple sections → writer hasn't internalised rule
3. L7 Q2 (author behaviour): falling back, not reaching → rule reinforcement, not architecture problem
4. Output: copy problem → L4/L5

**Pass criteria:**
Framework distinguishes between a writer internalisation problem and a value prop problem for the same construction.

---

## T3: Script Enforcement Tests

### Test suite structure

```
tests/copy-lint/
├── fixtures/
│   ├── banned-words-pass.mdx       # Should produce zero lint errors
│   ├── banned-words-fail.mdx       # Should produce N specific errors
│   ├── review-flag-fail.mdx        # Should block merge
│   ├── currency-fail.mdx           # Should flag £ usage
│   ├── empty-table-cell-fail.mdx   # Should flag decision table gap
│   └── accordion-url-only-fail.mdx # Should flag gated primary action
└── run-copy-tests.js
```

### Test cases

| Test | Input | Expected output | Pass criteria |
|---|---|---|---|
| Banned word: `effectively` | `Pool operators are effectively...` | Line number + BANNED WORD flag | Exact match |
| Banned phrase: `This page covers` | `This page covers what...` | Line number + BANNED PHRASE flag | Exact match |
| Currency: `£` | `at £800 for an RTX` | Line number + CURRENCY flag | Exact match |
| REVIEW flag in body | `{/* REVIEW: confirm */}` in TableCell | REVIEW FLAG + block merge | Merge blocked |
| `if` in body prose | `if the cost base is understood` | PATTERN flag + line number | Flag produced |
| `not [X]` construction | `not just earn staking rewards` | PATTERN flag + line number | Flag produced |
| `consistently` without number | `consistently online and monitored` | PATTERN flag + line number | Flag produced |
| Clean file | All rules passing | Zero errors | Zero output |

---

## T4: Agent Compliance Test

### Purpose
Verify that SKILL.md files produce compliant drafts when used with Codex.

### Test 4a — Draft with skills loaded

**Procedure:**
1. Load `value-prop-check.md` and `copy-rules.md`
2. Request a draft of a 200-word evaluation section for a GPU operator evaluating the AI inference path
3. Apply L4 banned list to the output
4. Apply L5 checklist to the output

**Pass criteria:**
- Zero Tier 1 banned word/phrase violations
- Value proposition in first sentence, no conditionals
- No `not [X]` constructions
- Operator outcome stated before mechanism

### Test 4b — Draft without skills loaded

**Procedure:**
Same request, no skills loaded.

**Expected output:**
At least 3 Tier 1/2 violations. Documents the delta between unaided and skill-guided output.

**This test answers:** What is the measurable value of the SKILL.md files?

---

## T5: Iteration Loop Tests

### Test 5a — Two-pass escalation

**Procedure:**
1. Take a section with a known structural problem (cost before value)
2. Apply only L4 sentence-level fixes (pass 1)
3. Re-apply L5 gate
4. Confirm gate still fails (structural problem not fixed by sentence edits)
5. Apply L6 decision tree
6. Confirm routing to L2 (architecture problem), not L4 (copy problem)

**Pass criteria:**
After two sentence-level passes, the loop routes to L2, not back to L4 for a third pass.

---

## Human Review Cycles

### How many review passes per page type

| Page type | Review passes | Reviewers |
|---|---|---|
| Evaluation / guide | 2 passes: structural + copy | Brief author (L0/L1 check) + copy reviewer (L4/L5 gate) |
| Conceptual | 1 pass: copy + sequence | Copy reviewer |
| Reference | 1 pass: script lint + spot check | Automated + brief spot check |
| Procedural (how-to) | 2 passes: sequence + copy | Brief author + copy reviewer |

### Pass 1 — Structural review (human)

Reviewer checks against L2 content sequence:
- Does the page open with operator outcome?
- Is the majority path featured?
- Are all introduced paths routed?
- Is the decision aid complete?
- Is the staged action path numbered and zero-to-outcome?

**Output:** Structural pass or list of L2 failures. No sentence-level edits at this pass.

### Pass 2 — Copy review (human + script)

Reviewer runs lint-copy.js and lint-structure.js. Reviews all Tier 2 pattern flags. Applies L5 gate checklist.

**Output:** Gate pass (merge approved) or gate fail with specific layer/rule references.

### When to escalate to L6/L7

- Same structural problem survives Pass 2: L6 diagnostic
- Same error class appears in 3+ pages: L7 pattern observer
- L7 routes to product clarity: schedule product owner session before any further drafting on affected pages

---

## Test Schedule

| Test | When to run | Frequency |
|---|---|---|
| T1a (retrospective audit) | Before next content brief for GPU Nodes | Once |
| T1b (GPU Nodes L0) | Before GPU Nodes brief is written | Once |
| T2a (hybrid path gap) | After T1a confirms hypothesis | Once |
| T2b (recurrence detection) | At Sprint 3 completion | Once |
| T3 (script tests) | Before CI integration of lint scripts | Ongoing in CI |
| T4 (agent compliance) | Before first SKILL.md-guided Codex run | Once; then per skill update |
| T5 (iteration loop) | After first real L6 escalation occurs | As needed |

---

## Known Test Outcomes (Pre-Run Predictions)

Based on analysis already completed:

**T1a will find:**
- L0 Q2 unanswerable for both files (hybrid path gap)
- Minimum 8 L4 violations in each file
- At least one L5 gate failure in each file (REVIEW flag in decision table)

**T2a will confirm:**
- Hybrid path gap routes as product clarity problem (L0), not copy problem (L4)
- This validates L7 pattern observer design

**T4b will establish:**
- Baseline violation rate for unaided drafts
- Measurable SKILL.md improvement delta

If T2a routes the hybrid gap to L4 instead of L0, the L7 observer logic needs adjustment — specifically, Q3 (what is the pattern protecting?) needs stronger signal criteria for distinguishing structural from product clarity escalations.
