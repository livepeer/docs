# Implementation — Next Phase
**Livepeer Docs Copy Framework — Document 6**
**Version 1.0 — March 2026**

---

## Purpose

This document defines the sequenced implementation plan for the framework. It is ordered by dependency — each phase unblocks the next. No content work proceeds until the relevant phase gate is passed.

---

## Phase 0 — Product Clarity Gate
**Before any new content is drafted or any existing content is revised.**

### Actions

1. **Answer L0 for the hybrid operator path.**
   The hybrid model (video transcoding + AI inference) is the majority real-world operating model. It currently has no featured page, no L0 answers, and no staged action sequence. This is a product clarity problem that blocks all operator-facing content work.

   Required output: L0 Q1–Q4 answered with product owner (Rich or Rick). Written. Not inferred from existing content.

2. **Answer L0 for GPU Nodes tab.**
   No brief for GPU Nodes should be written until L0 is complete. Current briefs 01–12 and task files should be held pending L0 sign-off on the majority operator path.

3. **Confirm the featured path hierarchy for all three operator tabs.**
   GPU Nodes, Gateways, Developers — each tab needs a defined majority path before content sequence planning can proceed.

**Gate:** Phase 1 does not start until L0 is signed off for hybrid path, GPU Nodes, and the tab hierarchy.

---

## Phase 1 — Script Infrastructure
**Parallel to Phase 0. No content dependency.**

### Actions

1. **Create banned reference files**
   - `tools/scripts/lib/banned-words.txt`
   - `tools/scripts/lib/banned-phrases.txt`
   - `tools/scripts/lib/banned-patterns.txt`

   Source: Document 3, Part B. These files are the single source of truth — both scripts and SKILL.md files import from them.

2. **Build lint-copy.js**
   Tier 1: exact banned word/phrase match. Blocks merge on any hit.
   Tier 2: pattern match. Warns; requires human sign-off.

3. **Build lint-structure.js**
   Checks: empty TableCell in decision context, REVIEW flags in rendered content, missing frontmatter fields, lastVerified staleness.

4. **Build test suite (T3)**
   Fixture files per Document 5, T3. All tests green before CI integration.

5. **CI integration**
   Add to `docs-v2` PR workflow. Tier 1 failures block merge. Tier 2 failures warn.

**Gate:** All T3 tests green. Scripts run clean on a known-passing page and correctly flag all fixture failures.

---

## Phase 2 — SKILL.md Build
**After Phase 1 scripts confirmed. Parallel to Phase 0 if possible.**

### Actions

1. **Build skill file set** per Document 4 architecture:
   - `copy-rules.md` — imports from banned reference files (Phase 1 output)
   - `structure-rules.md`
   - `value-prop-check.md`
   - `persona-routing.md`
   - `review-gate.md`
   - `iteration-diagnostic.md`
   - `pattern-observer.md`
   - `repair-routing.md`

2. **Build root SKILL.md index** with YAML frontmatter and skill references.

3. **Run T4 compliance test** (Document 5):
   - Draft a 200-word evaluation section with skills loaded
   - Confirm zero Tier 1 violations
   - Draft same section without skills loaded
   - Document violation delta

**Gate:** T4a passes (zero Tier 1 violations in skill-guided draft). T4b establishes baseline.

---

## Phase 3 — Retrospective Audit
**After Phase 0 gate passed. Phase 1 scripts available.**

### Actions

1. **Run T1a** — retrospective audit of `operator-rationale.mdx` and `business-case.mdx`:
   - Apply L0 questions
   - Apply L5 gate
   - Run lint scripts
   - Document all failures with layer/rule references

2. **Run T2a** — confirm hybrid path routes as L0 product clarity problem, not L4 copy problem.

3. **Produce audit report** for each file:
   - L0 completion status
   - L5 gate failures by category
   - Lint output
   - L7 pattern observer findings
   - Repair routing recommendation per L8

4. **Do not re-draft pages during the audit.** The audit output is the input to Phase 4 briefs. No edits until brief is written and L0 is answered.

**Gate:** Audit reports complete. Repair routing confirmed for each failed page.

---

## Phase 4 — Brief Template Integration
**After Phase 0 and Phase 3.**

### Actions

1. **Update Codex brief template** to include:
   - L0 section (required, gated — brief cannot be submitted without it)
   - L1 persona mapping table (required)
   - L2 content sequence plan (checkbox format)
   - L5 pre-merge checklist

2. **Apply updated brief template to:**
   - Hybrid operator path page (new — highest priority)
   - GPU Nodes tab briefs 01–12 (revision — hold until L0 answered)
   - Any outstanding operator-facing briefs

3. **Brief review process:** Briefs reviewed at L0/L1 level before any Codex task is launched. A brief with incomplete L0 is returned — Codex does not run.

**Gate:** First brief produced under new template passes L0/L1 review.

---

## Phase 5 — Full Tab Implementation
**After Phase 4. Ongoing.**

### Actions

1. **GPU Nodes tab:** Apply framework end-to-end. L0 first. Briefs second. Codex tasks third. L5 gate on every PR.

2. **Gateways and Developers tabs:** Same sequence. Do not begin until GPU Nodes Phase 0 is confirmed (shared majority-path definitions may affect all three tabs).

3. **Pattern observer — first scheduled run:** After 10+ pages merged under framework. Output: cross-tab pattern report. If recurrence detected, L7 diagnostic before next batch of content.

---

## Dependency Map

```
Phase 0 (Product Clarity)
  └── unblocks Phase 3 (Retrospective Audit)
       └── unblocks Phase 4 (Brief Template)
            └── unblocks Phase 5 (Tab Implementation)

Phase 1 (Script Infrastructure) [parallel]
  └── unblocks Phase 2 (SKILL.md Build)
  └── feeds Phase 3 (scripts used in audit)

Phase 2 (SKILL.md Build) [parallel]
  └── feeds Phase 4 (skills used in Codex tasks)
  └── feeds Phase 5 (ongoing agent compliance)
```

---

## What Does Not Proceed Until Phase 0 Completes

- No new GPU Nodes content briefs
- No revisions to operator-rationale.mdx or business-case.mdx (audit output defines what to fix, not ad-hoc edits)
- No hybrid operator path content of any kind (it does not exist without L0 answers)

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| L0 cannot be answered for hybrid path without SME input | High | Blocks Phase 3/4 | Schedule L0 session with Rich/Rick before any other action |
| Lint scripts produce false positives on technical MDX | Medium | Reviewer fatigue, ignored flags | Tune patterns against fixture set before CI integration; exclude code blocks from all pattern checks |
| SKILL.md files produce compliant but thin drafts | Medium | Content lacks depth | T4 measures this; depth is a separate concern from compliance — address in SKILL.md v2 |
| Phase 0 deferred, content work continues without it | High | Framework bypassed from the start | Phase 0 completion is a hard gate enforced by the documentation lead; not a suggestion |
