# Implementation Requirements & Design
**Livepeer Docs Copy Framework — Document 4**
**Version 1.0 — March 2026**

---

## Purpose

This document defines how the framework (L0–L8) is implemented across a documentation system with hundreds of pages, mixed content types (business, technical, strategic), and multiple authors — human and AI agent.

The implementation has three enforcement layers that work in combination:
1. **SKILL.md files** — AI agent constraints, readable before any content task
2. **Script enforcement** — automated lint passes run in CI
3. **Human review gate** — L5 checklist applied before merge

---

## Design Principles for Implementation

**Rules must be executable, not advisory.**
Every rule in the framework must produce a binary pass/fail result — either at script level (detectable) or at human review level (checklist item). Vague guidelines produce inconsistent enforcement.

**Separate skills for separate concerns.**
A single monolithic SKILL.md covering L0–L8 produces agent confusion. Each layer is independently invokable. An agent running a copy audit does not need the L0 VP definition questions. An agent drafting content does not need the L6 diagnostic tree.

**Scripts catch what patterns can catch; humans catch what patterns cannot.**
Banned words and phrases are script territory. Structural sequence errors (cost before value, abandoned path) and diagram redundancy are human territory. The system must not ask scripts to do human work or humans to do script work.

**Framework layers map directly to implementation components.**

| Layer | Implementation component |
|---|---|
| L0 | Brief template (human-authored, required field) |
| L1 | Brief template (required table before drafting) |
| L2 | Content SKILL.md — structure rules |
| L3 | Content SKILL.md — paragraph rules |
| L4 | Lint script + Copy SKILL.md — banned list |
| L5 | PR checklist (automated where possible, human for structural items) |
| L6 | Review SKILL.md — diagnostic routing |
| L7 | Pattern Observer SKILL.md — cross-session analysis |
| L8 | Brief template — repair routing section |

---

## Component 1: SKILL.md Architecture

### Recommended File Structure

```
ai-tools/ai-skills/docs-copy/
├── SKILL.md                          # Index and invocation guide
├── skills/
│   ├── copy-rules.md                 # L4 banned list; sentence-level enforcement
│   ├── structure-rules.md            # L2–L3 sequence and paragraph rules
│   ├── value-prop-check.md           # L0 questions; VP definition and validation
│   ├── persona-routing.md            # L1 persona mapping; functional routing rules
│   ├── review-gate.md                # L5 checklist; pass/fail criteria
│   ├── iteration-diagnostic.md       # L6 decision tree; escalation routing
│   ├── pattern-observer.md           # L7 cross-session pattern analysis
│   └── repair-routing.md             # L8 repair sequences
└── reference/
    ├── banned-words.txt              # Machine-readable banned word list
    ├── banned-phrases.txt            # Machine-readable banned phrase list
    └── banned-patterns.txt           # Regex patterns for script enforcement
```

---

### SKILL.md Index (root file)

```yaml
---
name: docs-copy-framework
version: 1.0
description: >
  Copy and content governance framework for Livepeer documentation.
  Enforces product-first, persona-first writing standards across all page types.
  Apply before drafting, during review, and during repair cycles.
invocation:
  - "review this page for copy quality"
  - "audit this content against the framework"
  - "draft [page type] for [operator profile]"
  - "diagnose why this section keeps failing review"
skills:
  - skills/value-prop-check.md       # Run before any brief
  - skills/persona-routing.md        # Run before any brief
  - skills/structure-rules.md        # Run before drafting
  - skills/copy-rules.md             # Run during drafting and review
  - skills/review-gate.md            # Run before merge
  - skills/iteration-diagnostic.md   # Run after first gate failure
  - skills/pattern-observer.md       # Run after second failure or pattern recurrence
  - skills/repair-routing.md         # Run after observer escalation
---
```

---

### copy-rules.md (L4 — Banned List)

Format for machine-readable enforcement and agent reading:

```markdown
# Copy Rules — Banned Patterns

## Unconditional banned words
Do not use these words in body prose under any circumstance.
effectively, essentially, basically, meaningful, significant, real (as intensifier),
various, several, simply, just (as minimiser), obviously, clearly

## Banned phrases (exact match)
Do not use any of the following:
- "This page covers"
- "This section covers"
- "The reason is straightforward"
- "Understanding X is essential"
- "among other factors"
- "not just [X]"
- "rather than"
- "what it takes"
- "low but not zero"
- "once [X] is stable"
- "it should be noted"
- "can generate" / "may produce" in value claims

## Banned constructions (pattern-level)
- `not [noun]` in value proposition sentences
- `if [condition]` in body prose outside of code blocks
- `[value statement] — if [condition]`
- `This page [verb]` at sentence start
- `consistently` without an adjacent number within 10 words
- Currency symbols other than $ in non-region-scoped content
- `{/* REVIEW:` appearing in any rendered MDX

## Currency rule
All monetary examples use USD by default.
Region-scoped content declares scope once at section opening.
Mixed currencies within one example are banned.

## The master sentence test
Before any sentence ships, ask:
Does this sentence give the operator something they can act on, believe, or
use to make a decision — stated directly, with no qualifications, contrasts,
or conditions?
If no: rewrite or delete.
```

---

### value-prop-check.md (L0 — Pre-Brief)

```markdown
# Value Proposition Check

Run this skill before writing any brief for an operator-facing page.
Answer all four questions. If any cannot be answered, do not proceed to drafting.

## Q1: Operator outcome
What does this product or feature do for the operator?
State as: a kept outcome, one sentence, no conditionals.

## Q2: Majority path
Who is already succeeding, and what does their operation look like?
The majority real-world model — not an edge case — is the featured path.

## Q3: Reader's real alternative
What would the reader do instead of this?
This defines the competitive context the page must address.

## Q4: Required belief
What does the reader need to believe to take the next step?
One sentence. This is the job of the page.

## Failure conditions
L0 is incomplete if:
- Q1 contains a conditional (if, depends on, can)
- Q2 describes an edge case as the primary model
- Q3 is blank
- Q4 is a mechanism statement, not a belief statement

If L0 cannot be completed: this is a product clarity problem.
Escalate to product owner. Do not draft.
```

---

## Component 2: Script Enforcement

### Recommended Script Architecture

```
tools/scripts/
├── lint-copy.js              # Main copy linter — runs banned word/phrase/pattern checks
├── lint-structure.js         # Structural checks — REVIEW flags, empty table cells, currency
├── lint-frontmatter.js       # Metadata completeness — pageType, audience, lastVerified
└── lib/
    ├── banned-words.js       # Banned word list (from reference/banned-words.txt)
    ├── banned-phrases.js     # Banned phrase list
    └── banned-patterns.js    # Regex pattern list
```

---

### lint-copy.js — What it checks

**Tier 1: Exact match (zero tolerance)**

```javascript
// Banned words — flag with line number and word
const BANNED_WORDS = require('./lib/banned-words');
// Output: [line 54] BANNED WORD: "effectively" — delete or restate directly

// Banned phrases — flag with line number and phrase
const BANNED_PHRASES = require('./lib/banned-phrases');
// Output: [line 12] BANNED PHRASE: "This page covers" — delete; start with content

// Currency — flag non-USD symbols outside region-scoped sections
// Output: [line 128] CURRENCY: £ found outside declared region scope — use USD
```

**Tier 2: Pattern match (flag for human review)**

```javascript
// Conditional in body prose
// Regex: /\bif\b(?![^`]*`)/g  (excludes code blocks)
// Output: [line 67] PATTERN: "if" in body prose — check for conditional gatekeeping

// Weakened value claim
// Regex: /\b(can|may)\s+\w+/g in sections tagged as value-proposition context
// Output: [line 34] PATTERN: "can generate" — assert directly or delete

// "not [noun]" in value sentences
// Regex: /\bnot\s+[a-z]/g in non-code, non-list context
// Output: [line 89] PATTERN: "not [X]" — restate as positive claim

// REVIEW flags in rendered content
// Regex: /\{\/\*\s*REVIEW:/g
// Output: [line 201] REVIEW FLAG: unresolved review flag in rendered content — block merge

// Consistently without number
// Regex: /\bconsistently\b(?![\w\s]{0,40}\d)/g
// Output: [line 145] PATTERN: "consistently" without adjacent number — add threshold
```

---

### lint-structure.js — What it checks

```javascript
// Empty TableCell in decision context
// Flag any <TableCell> that contains only whitespace or an unresolved REVIEW flag
// inside a table that has "Decision" or "Matrix" or "Path" in a nearby heading

// Missing lastVerified in frontmatter
// Flag pages with lastVerified older than 90 days from current date

// Missing pageType in frontmatter
// Flag pages with no pageType field

// Missing audience in frontmatter  
// Flag pages with no audience field

// Accordion containing a URL without that URL also appearing in body copy
// Heuristic: if a URL appears only inside <Accordion> tags, flag for human review
```

---

### CI Integration

```yaml
# .github/workflows/lint-copy.yml
name: Copy lint
on:
  pull_request:
    paths:
      - 'v2/**/*.mdx'

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: node tools/scripts/lint-copy.js --changed-files
      - run: node tools/scripts/lint-structure.js --changed-files
      - run: node tools/scripts/lint-frontmatter.js --changed-files
```

**Tier 1 failures (exact banned matches, unresolved REVIEW flags):** Block merge.
**Tier 2 failures (pattern matches):** Warn; require human reviewer sign-off on each flagged item.

---

## Component 3: Brief Template Integration

The L0 and L1 sections of the brief template enforce pre-draft framework compliance:

```markdown
## BRIEF — [Page Name]

### L0: Value Proposition (required — complete before drafting)

Q1 Operator outcome:
[One sentence. No conditionals.]

Q2 Featured (majority) path:
[Describe the majority real-world operating model.]

Q3 Reader's real alternative:
[What would they do instead?]

Q4 Required belief:
[What must they believe to take the next step?]

---

### L1: Persona Path Mapping (required — complete before drafting)

| Operator profile | Primary question on arrival | What this page must give them |
|---|---|---|
| | | |
| | | |

---

### L2: Content Sequence Plan

[ ] Operator outcome (first sentence)
[ ] Featured path (fully described)
[ ] Variants (with entry requirements)
[ ] Economics (concrete figures)
[ ] Decision aid (complete — no placeholders)
[ ] Staged action path (numbered)
[ ] Next page link

---

### Pre-Merge Checklist (L5)

[ ] L0 questions answered
[ ] Majority path is featured
[ ] No banned constructions (lint-copy.js passes)
[ ] No empty cells in decision aids
[ ] No unresolved REVIEW flags in rendered content
[ ] All introduced paths developed or linked
[ ] Primary actions in body copy
[ ] USD currency throughout
[ ] Page opens with value, not cost or warning
[ ] No section ends on hedge or disclaimer
```

---

## Design Considerations for Scale

**At 100+ pages, enforcement must be asymmetric.**
Not every page requires the same depth of review. Page type determines review depth:

| Page type | L0 required | L5 gate | Script enforcement |
|---|---|---|---|
| Evaluation / guide | Full L0 | Full L5 | All tiers |
| Conceptual | Q1 + Q4 only | Structural items only | Tier 1 only |
| Reference | Not required | Tier 1 banned words | Tier 1 only |
| Procedural (how-to) | Q1 + staged path | Full L5 | All tiers |

**frontmatter `pageType` drives enforcement depth.**
`pageType: guide` triggers full L0+L5. `pageType: reference` triggers Tier 1 lint only. This is enforced in CI by reading the frontmatter before applying rules.

**Pattern observer runs across the tab, not the page.**
L7 is a cross-page analysis. It cannot be run per-PR. It runs on a scheduled basis (weekly or at tab completion) across all pages within a section tab. Output is a pattern report, not a PR comment.
