# Implementation — Phase 2: Structural Enforcement
**Livepeer Docs Copy Framework — Document 9**
**Version 1.0 — March 2026**

---

## Scope

Phase 2 closes the gap between sentence-level rules (Phase 1) and
structural failures that sentence lint cannot catch. Five artefacts:

- **P2-A:** `structure-rules.md` — SKILL.md for L2/L3 sequence and paragraph rules
- **P2-B:** `value-prop-check.md` — SKILL.md for L0 pre-brief gate
- **P2-C:** `persona-routing.md` — SKILL.md for L1 multi-profile pages
- **P2-D:** `lint-structure.js` — CI structural checks
- **P2-E:** CI workflow update — Tier 1 blocking + frontmatter-driven depth

**Prerequisite:** Phase 1 stable. lint-copy.js running clean on 5+ pages with
false-positive rate below 5%.

---

---

# P2-A: structure-rules.md — L2/L3 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/structure-rules.md`

```markdown
---
name: structure-rules
version: 1.0
description: >
  Structural and paragraph rules for Livepeer documentation.
  Load alongside copy-rules.md for any drafting, editing, or
  structural review task. Governs page sequence, paragraph discipline,
  and the handling of tables, diagrams, and action paths.
invoke_when:
  - "draft [page type]"
  - "review page structure"
  - "check sequence"
  - "structural review"
---

# Structure Rules — L2 and L3

---

## Page sequence (L2)

Every evaluation or guide page follows this sequence.
Deviations require explicit justification in the brief.

1. **Operator outcome** — value kept, one sentence, no conditionals
2. **Featured path** — majority real-world model, described in full
3. **Variants** — alternative paths with specific entry requirements
4. **Economics** — concrete figures, no hedging
5. **Decision aid** — complete, no empty cells, no REVIEW flags
6. **Staged action path** — numbered, zero to first outcome
7. **Next page link** — one link, correct next step for primary reader

**Banned sequences:**
- Cost or warning before value proposition
- Variant paths before the majority path is fully described
- Decision aid before economics section
- Any section that introduces a path without developing it or linking to
  a page that does

---

## Paragraph rules (L3)

**One paragraph, one job.**
Label the paragraph's job in three words. If you cannot, split it.

**Lead sentence states the fact.**
Remaining sentences extend or evidence it. No exceptions.

**Final sentence: fact, number, or next step.**
Never a hedge. Never a restatement of the paragraph's opening.
Never a conditional.

**Tables and diagrams stand alone.**
Prose that restates a table row or diagram node is deleted.
Every table and diagram must show something the surrounding prose
does not already say.

**Two representations of identical data: remove one.**
If a diagram and a table carry the same information, the diagram
must be replaced with a version that shows something the table cannot
(a decision path, a causal flow, a sequence) — or deleted.

---

## Action path rules

**Staged action paths are numbered and imperative.**
Format: `1. [Command].` Not `1. You should [verb]`.

**Every introduced path is developed or linked.**
If a path is mentioned and not described on this page, there must be
a `<LinkArrow>` to the page that describes it. No abandoned paths.

**High-value actions appear in body copy.**
A URL or command that answers the reader's primary question must be
visible without interaction. It must not appear only inside:
- A collapsed `<Accordion>`
- A `<Note>` component
- A `Related Pages` card

---

## Decision aid rules

Decision tables, matrices, and flowcharts must meet all of the following:

- No empty cells
- No placeholder text
- No `{/* REVIEW: */}` flags in any cell
- Every path in the decision aid has a corresponding section or link
- The majority operator path is the first or most prominent path shown

---

## Diagram rules

Mermaid diagrams must show one of the following to justify inclusion:
- A causal flow (A causes B causes C)
- A decision path (if X then Y, if not X then Z)
- A sequence over time

A diagram that simply restates a comparison table is deleted.

---

## Note and callout rules

`<Note>` components must forward-point, not apologise.

Allowed: `Operator profiles change frequently — the #orchestrators Discord channel is the current-state source.`
Banned: `The landscape is evolving. We cannot guarantee accuracy.`

A section must not end with a Note that hedges the content
that precedes it.

---

## What this skill does not govern
- Sentence-level banned words and phrases (load copy-rules.md)
- Value proposition definition (load value-prop-check.md)
- Persona routing language (load persona-routing.md)
```

---

---

# P2-B: value-prop-check.md — L0 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/value-prop-check.md`

```markdown
---
name: value-prop-check
version: 1.0
description: >
  L0 value proposition gate. Load before writing any brief for an
  operator-facing page. If the four questions cannot be answered,
  drafting does not begin. This is a product clarity gate, not a
  writing gate.
invoke_when:
  - "start a brief"
  - "write a brief for"
  - "L0 check"
  - "value prop check"
  - "before drafting"
---

# Value Proposition Check — L0

## When to use this skill
Before writing any content brief for an operator-facing page.
Run this check first. If it cannot be completed, stop.

---

## The four questions

Answer each in one sentence. If you cannot, the question has
surfaced a product clarity problem. Stop and escalate.

---

**Q1 — Operator outcome**
What does this product, feature, or section do for the operator?

Rules:
- One sentence
- No `if`, `can`, `may`, `depends on`
- States a kept outcome, not a mechanism

Fail signal: The sentence contains a conditional.
Escalation: Product clarity problem. Escalate to product owner.

---

**Q2 — Featured (majority) path**
Which operator is already succeeding with this, and what does
their setup look like?

Rules:
- Describes the majority real-world operating model
- Not an edge case, not an aspirational user
- This becomes the featured path on the page

Fail signal: Q2 describes a minority or edge-case operator.
Escalation: Architecture problem. Restructure around the actual majority.

---

**Q3 — Reader's real alternative**
What would the reader do instead of this?

Rules:
- Specific. Names the alternative.
- Defines the competitive context the page must address.

Fail signal: Q3 is blank, vague, or says "nothing".
Escalation: Product clarity problem. The value proposition has no
competitive context. It cannot be written without one.

---

**Q4 — Required belief**
What does the reader need to believe to take the next step?

Rules:
- One sentence
- A belief, not a mechanism description
- Specific to this page, not a generic product claim

Fail signal: Q4 is a mechanism ("they need to understand how X works").
Escalation: Rewrite Q4 as the belief that mechanism would produce.

---

## L0 self-check

Before proceeding to the brief:

- [ ] Q1 contains no conditional
- [ ] Q2 describes the majority operator path, not an edge case
- [ ] Q3 is specific and names the alternative
- [ ] Q4 is a belief statement, not a mechanism description

If any box is unchecked: stop. Return to product owner before drafting.

---

## What L0 is not

L0 is not a writing exercise. It is a product clarity check.
If L0 cannot be completed, the page cannot be written well by
anyone — not because the writer lacks skill, but because the
product questions have not been answered.

Do not draft around incomplete L0 answers.
```

---

---

# P2-C: persona-routing.md — L1 SKILL

**Path:** `ai-tools/ai-skills/docs-copy/skills/persona-routing.md`

```markdown
---
name: persona-routing
version: 1.0
description: >
  L1 persona path mapping rules. Load for any page serving more than
  one operator profile. Governs how functional routing language is
  written and where it appears on the page.
invoke_when:
  - "multi-profile page"
  - "persona routing"
  - "operator routing"
  - "different operator types"
---

# Persona Routing — L1

## Functional identifiers, not persona names

Routing language uses hardware, LPT position, and goal.
Named personas (A, B, C, D, E) are planning tools only.
They never appear in published copy.

Correct: `If you have a single GPU and limited LPT, start here.`
Banned:  `Persona A operators should...`

---

## The L1 mapping table

Before drafting a multi-profile page, complete this table in the brief.
Every row must be served by the page or routed to a linked page.

| Operator profile (hardware / LPT / goal) | Primary question on arrival | What this page must give them | Served here or linked? |
|---|---|---|---|

If a row cannot be filled in: the page scope is wrong.
Either the page cannot serve that profile, or the profile
belongs on a different page. Resolve before drafting.

---

## Where routing language appears

Routing appears once, near the top of the page — after the operator
outcome sentence, before the featured path section.

Format: a brief functional description of who this page is for,
with two to four `Tabs` or inline routing sentences covering
different entry points.

It does not appear:
- In the middle of a section
- After the decision aid
- In a `Note` component

---

## Routing language rules

**State the profile in functional terms.**
`Operators with 24 GB VRAM and no LPT` not `AI-focused operators`.

**State what they get, not what they are.**
`Start here for the pool worker path` not `This is for pool workers`.

**One sentence per profile maximum.**
Routing is a pointer, not a description. Description belongs in the
section the reader is being routed to.

**Do not route to a page that does not exist.**
If the destination page has not been written, either:
- Write the routing section after the destination page exists, or
- Mark it as `[Coming soon]` with a REVIEW flag — do not merge
  without resolving

---

## The majority path rule

The majority real-world operator profile is the default.
It is described first, in full, without routing language.
Routing language directs minority profiles to variants
or linked pages.

The majority path is never behind a `<Tab>` or collapsed state.
It is the page's main content.
```

---

---

# P2-D: lint-structure.js — CI Structural Checks

**Path:** `tools/scripts/lint-structure.js`

```javascript
#!/usr/bin/env node

/**
 * lint-structure.js
 * Livepeer Docs Copy Framework — Structural checks
 *
 * Checks:
 * - Unresolved REVIEW flags in rendered content (Tier 1 — blocks merge)
 * - Empty cells in decision-context tables (Tier 1 — blocks merge)
 * - Missing required frontmatter fields (Tier 1 — blocks merge)
 * - Stale lastVerified (Tier 2 — warns)
 * - Primary action URLs only inside accordions (Tier 2 — warns)
 * - Note components ending a section with hedge language (Tier 2 — warns)
 *
 * Usage:
 *   node tools/scripts/lint-structure.js [file]
 *   node tools/scripts/lint-structure.js --changed-files
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ─── Configuration ────────────────────────────────────────────────────────────

const REQUIRED_FRONTMATTER = ['title', 'pageType', 'audience', 'lastVerified'];
const STALE_DAYS = 90;

// Note components ending sections — hedge phrases that signal a CYA note
const HEDGE_NOTE_PHRASES = [
  'is evolving',
  'may change',
  'cannot guarantee',
  'subject to change',
  'check for updates',
  'may not be accurate',
  'use with caution',
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getFiles() {
  const args = process.argv.slice(2);
  if (args.includes('--changed-files')) {
    const diff = execSync('git diff --cached --name-only --diff-filter=ACM', {
      encoding: 'utf8',
    });
    return diff
      .split('\n')
      .filter(f => f.endsWith('.mdx') || f.endsWith('.md'))
      .filter(fs.existsSync);
  }
  const target = args.find(a => !a.startsWith('--'));
  if (target && fs.existsSync(target)) return [target];
  return [];
}

function parseFrontmatter(content) {
  const match = content.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return {};
  const fm = {};
  match[1].split('\n').forEach(line => {
    const [key, ...rest] = line.split(':');
    if (key && rest.length) {
      fm[key.trim()] = rest.join(':').trim().replace(/['"]/g, '');
    }
  });
  return fm;
}

function getEnforcementDepth(pageType) {
  const depths = {
    guide:       'full',
    evaluation:  'full',
    concept:     'structural',
    reference:   'tier1-only',
    'how-to':    'full',
    landing:     'structural',
  };
  return depths[pageType] || 'full';
}

// ─── Checks ───────────────────────────────────────────────────────────────────

function checkFrontmatter(content, filePath) {
  const errors = [];
  const fm = parseFrontmatter(content);

  REQUIRED_FRONTMATTER.forEach(field => {
    if (!fm[field]) {
      errors.push({
        tier: 1,
        file: filePath,
        line: 1,
        id: 'MISSING_FRONTMATTER',
        label: `Missing required frontmatter field: "${field}"`,
        fix: `Add "${field}:" to the page frontmatter.`,
      });
    }
  });

  if (fm.lastVerified) {
    const verified = new Date(fm.lastVerified);
    const now = new Date();
    const daysDiff = (now - verified) / (1000 * 60 * 60 * 24);
    if (daysDiff > STALE_DAYS) {
      errors.push({
        tier: 2,
        file: filePath,
        line: 1,
        id: 'STALE_LAST_VERIFIED',
        label: `lastVerified is ${Math.floor(daysDiff)} days old (threshold: ${STALE_DAYS})`,
        fix: 'Update lastVerified after content review or SME confirmation.',
      });
    }
  }

  return errors;
}

function checkReviewFlags(content, filePath) {
  const errors = [];
  const lines = content.split('\n');
  lines.forEach((line, i) => {
    if (/\{\/\*\s*REVIEW:/i.test(line)) {
      errors.push({
        tier: 1,
        file: filePath,
        line: i + 1,
        id: 'REVIEW_FLAG_RENDERED',
        label: 'Unresolved REVIEW flag in rendered content',
        fix: 'Resolve the REVIEW item or move the flag to a JSX comment outside the rendered tree.',
        text: line.trim().slice(0, 80),
      });
    }
  });
  return errors;
}

function checkEmptyTableCells(content, filePath) {
  const errors = [];
  const lines = content.split('\n');
  let inDecisionTable = false;
  let decisionTableStartLine = 0;

  lines.forEach((line, i) => {
    // Detect tables near a decision-context heading
    if (/^#+\s.*(decision|matrix|path|choose|select)/i.test(line)) {
      inDecisionTable = true;
      decisionTableStartLine = i;
    }
    // Leave decision table context after 30 lines
    if (inDecisionTable && i - decisionTableStartLine > 30) {
      inDecisionTable = false;
    }
    if (inDecisionTable) {
      // Empty TableCell: <TableCell></TableCell> or <TableCell> </TableCell>
      if (/<TableCell>\s*<\/TableCell>/.test(line) ||
          /<TableCell>\s*\{\/\*[^*]*\*\/\}\s*<\/TableCell>/.test(line)) {
        errors.push({
          tier: 1,
          file: filePath,
          line: i + 1,
          id: 'EMPTY_DECISION_CELL',
          label: 'Empty cell in decision table — incomplete decision aid',
          fix: 'Fill the cell or block merge until verified.',
          text: line.trim().slice(0, 80),
        });
      }
    }
  });
  return errors;
}

function checkAccordionUrls(content, filePath) {
  const warnings = [];
  const lines = content.split('\n');
  let inAccordion = false;
  const accordionUrls = [];
  const bodyUrls = [];

  lines.forEach((line, i) => {
    if (/<Accordion\b/i.test(line)) inAccordion = true;
    if (/<\/Accordion>/i.test(line)) inAccordion = false;

    const urlMatch = line.match(/href="([^"]+)"|https?:\/\/[^\s"')]+/g);
    if (urlMatch) {
      urlMatch.forEach(url => {
        const cleaned = url.replace(/href="|"/g, '');
        if (inAccordion) {
          accordionUrls.push({ url: cleaned, line: i + 1 });
        } else {
          bodyUrls.push(cleaned);
        }
      });
    }
  });

  // Flag URLs that appear only inside accordions
  accordionUrls.forEach(({ url, line }) => {
    const inBody = bodyUrls.some(b => b.includes(url) || url.includes(b));
    if (!inBody && url.startsWith('http')) {
      warnings.push({
        tier: 2,
        file: filePath,
        line,
        id: 'ACCORDION_ONLY_URL',
        label: `URL only inside Accordion — may be a primary action gated behind interaction`,
        fix: 'If this is a primary action URL, add it to body copy above the accordion.',
        text: url.slice(0, 80),
      });
    }
  });
  return warnings;
}

function checkHedgeNotes(content, filePath) {
  const warnings = [];
  const lines = content.split('\n');
  let inNote = false;
  let noteLines = [];
  let noteStartLine = 0;

  lines.forEach((line, i) => {
    if (/<Note>/i.test(line)) {
      inNote = true;
      noteStartLine = i + 1;
      noteLines = [];
    }
    if (inNote) noteLines.push(line);
    if (/<\/Note>/i.test(line) && inNote) {
      inNote = false;
      const noteContent = noteLines.join(' ').toLowerCase();
      HEDGE_NOTE_PHRASES.forEach(phrase => {
        if (noteContent.includes(phrase)) {
          warnings.push({
            tier: 2,
            file: filePath,
            line: noteStartLine,
            id: 'HEDGE_NOTE',
            label: `Note component contains hedge language: "${phrase}"`,
            fix: 'Replace with a forward-pointing statement or remove the Note.',
            text: noteLines[1]?.trim().slice(0, 80) || '',
          });
        }
      });
    }
  });
  return warnings;
}

// ─── Runner ───────────────────────────────────────────────────────────────────

function run() {
  const args = process.argv.slice(2);
  const warnOnly = args.includes('--warn-only');
  const files = getFiles();

  if (files.length === 0) {
    console.log('lint-structure: no files to check.');
    process.exit(0);
  }

  let tier1Count = 0;
  let tier2Count = 0;

  files.forEach(filePath => {
    const content = fs.readFileSync(filePath, 'utf8');
    const fm = parseFrontmatter(content);
    const depth = getEnforcementDepth(fm.pageType);

    const allResults = [
      ...checkFrontmatter(content, filePath),
      ...checkReviewFlags(content, filePath),
      ...(depth !== 'tier1-only' ? checkEmptyTableCells(content, filePath) : []),
      ...(depth === 'full' ? checkAccordionUrls(content, filePath) : []),
      ...(depth === 'full' ? checkHedgeNotes(content, filePath) : []),
    ];

    const t1 = allResults.filter(r => r.tier === 1);
    const t2 = allResults.filter(r => r.tier === 2);

    tier1Count += t1.length;
    tier2Count += t2.length;

    if (t1.length > 0) {
      console.error(`\n❌  ${filePath} — ${t1.length} BLOCKING structural error(s):\n`);
      t1.forEach(r => {
        console.error(`  [L${r.line}] ${r.id}: ${r.label}`);
        console.error(`        Fix: ${r.fix}`);
        if (r.text) console.error(`        → "${r.text}"`);
      });
    }

    if (t2.length > 0) {
      console.warn(`\n⚠️   ${filePath} — ${t2.length} structural warning(s):\n`);
      t2.forEach(r => {
        console.warn(`  [L${r.line}] ${r.id}: ${r.label}`);
        console.warn(`        Fix: ${r.fix}`);
        if (r.text) console.warn(`        → "${r.text}"`);
      });
    }
  });

  console.log(`\nlint-structure: ${tier1Count} blocking, ${tier2Count} warnings across ${files.length} file(s).`);

  if (tier1Count > 0 && !warnOnly) {
    console.error('\nMerge blocked. Resolve structural errors before re-submitting.');
    process.exit(1);
  }

  process.exit(0);
}

run();
```

---

---

# P2-E: CI Workflow Update

**File:** `.github/workflows/lint-copy.yml` (updated from Phase 1)

```yaml
name: Copy governance
on:
  pull_request:
    paths:
      - 'v2/**/*.mdx'
      - 'v2/**/*.md'

jobs:
  lint-copy:
    name: Banned words and phrases (Tier 1)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Run lint-copy (Tier 1 blocking)
        run: node tools/scripts/lint-copy.js --changed-files --tier1-only

  lint-structure:
    name: Structural checks
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Run lint-structure
        run: node tools/scripts/lint-structure.js --changed-files

  lint-patterns:
    name: Pattern checks (Tier 2 — warn only in CI)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Run lint-patterns (warn only)
        # Tier 2 patterns warn but do not block merge in CI.
        # Tier 1 escalations within lint-patterns (SELF_UNDERMINING_VALUE)
        # do block — remove --warn-only once false-positive rate confirmed below 5%.
        run: node tools/scripts/lint-patterns.js --changed-files --warn-only

  pattern-observer-scheduled:
    name: Cross-tab pattern report (scheduled)
    runs-on: ubuntu-latest
    if: github.event_name == 'schedule'
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Run pattern observer — all tabs
        run: |
          node tools/scripts/pattern-observer.js --all \
            --output reports/pattern-report-$(date +%Y-%m-%d).md
      - name: Commit report
        run: |
          git config user.name "github-actions"
          git config user.email "actions@github.com"
          git add reports/
          git commit -m "chore: pattern observer report $(date +%Y-%m-%d)" || echo "No changes"
          git push

# Scheduled: first of each month at 08:00 UTC
on:
  schedule:
    - cron: '0 8 1 * *'
  pull_request:
    paths:
      - 'v2/**/*.mdx'
      - 'v2/**/*.md'
```

---

## Phase 2 Gate Criteria

Before Phase 3 tooling is enabled:

- [ ] lint-structure.js runs clean on 5 pages without false positives
- [ ] lint-patterns.js Tier 1 escalations (SELF_UNDERMINING_VALUE) confirmed accurate
- [ ] `--warn-only` removed from lint-patterns CI step (Tier 1 escalations now block)
- [ ] L5 gate pass rate above 80% on first submission across 10+ pages
- [ ] SKILL.md files in active use for at least 3 Codex tasks
