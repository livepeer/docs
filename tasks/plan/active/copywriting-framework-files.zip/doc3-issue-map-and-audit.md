# Concrete Issue Map & Banned Pattern Audit
**Livepeer Docs Copy Framework — Document 3**
**Version 1.0 — March 2026**

---

## Part A — Concrete Issue Examples

Each issue is named, located, mapped to a framework layer, and referenced to the research source that identifies it as a failure mode.

---

### CATEGORY 1: THROAT-CLEARING & META-COMMENTARY

**Issue 1.1 — Page Announcement**
- **Location:** `business-case.mdx`, opening paragraph
- **Example:** `This page covers what professional-grade Orchestrator operation looks like in practice.`
- **Error name:** Throat-clearing opener
- **Framework layer:** L4 (banned: `This page [verb]`)
- **Research ref:** Google Technical Writing — "no announcements of what the page will do"
- **Rule:** Delete. Start with the content.

---

**Issue 1.2 — Instructive Preamble**
- **Location:** `operator-rationale.mdx`, What Orchestrators Earn section
- **Example:** `Understanding both is essential before modelling any return on investment.`
- **Error name:** Bridge-announcement
- **Framework layer:** L4 (banned: `Understanding X is essential`)
- **Research ref:** Google Technical Writing — throat-clearing self-editing rule
- **Rule:** Delete. The bridge IS the content. State the asymmetry directly.

---

**Issue 1.3 — Filler Transition**
- **Location:** `business-case.mdx`, Why Service Fees Scale
- **Example:** `The reason is straightforward:`
- **Error name:** Filler transition
- **Framework layer:** L4 (banned construction class: announcements before facts)
- **Research ref:** Google Technical Writing
- **Rule:** Delete the clause. Begin with the fact.

---

**Issue 1.4 — Empty Qualifier After Number**
- **Location:** `operator-rationale.mdx`, ETH for Gas accordion
- **Example:** `Gas on Arbitrum L2 is low but not zero.`
- **Error name:** Restated number
- **Framework layer:** L4 (banned: `low but not zero`)
- **Research ref:** Google Technical Writing — replace vague qualifiers with numbers
- **Rule:** Delete. The dollar range already carries the meaning.

---

### CATEGORY 2: CONTENT DUPLICATION WITHOUT VALUE

**Issue 2.1 — Visual Duplication**
- **Location:** `business-case.mdx`, Hobbyist vs Commercial section
- **Example:** Mermaid diagram with seven nodes, followed by table with identical seven rows
- **Error name:** Same-information redundancy
- **Framework layer:** L3 (each representation must show something the other cannot)
- **Research ref:** Red Hat Modular Docs — single-source principle
- **Rule:** Diagram becomes a decision-path flowchart. Table retains the comparison data.

---

**Issue 2.2 — Sub-Minimal Diagram**
- **Location:** `business-case.mdx`, Why Service Fees Scale
- **Example:** Two-box diagram: `Jobs × price → ETH` / `Stake × rate → LPT`
- **Error name:** Prose-restating diagram
- **Framework layer:** L3 (tables and diagrams stand alone; prose restating either is deleted)
- **Research ref:** Red Hat Modular Docs — single-source principle
- **Rule:** Delete diagram. Replace with a concrete numerical example in prose.

---

**Issue 2.3 — Prerequisite Re-delivery**
- **Location:** `business-case.mdx`, Why Service Fees Scale
- **Example:** Re-explanation of how inflation rewards work, already covered on a linked page
- **Error name:** Single-source violation
- **Framework layer:** L2 (prerequisites stated, not restated)
- **Research ref:** Red Hat Modular Docs — modules assume declared prerequisites
- **Rule:** Delete. Open at the next layer of knowledge. Trust the linked page to do its job.

---

### CATEGORY 3: FAILS TO ANSWER THE READER'S ACTUAL QUESTION

**Issue 3.1 — Named Threshold, Value Omitted**
- **Location:** `operator-rationale.mdx`, LPT Stake accordion
- **Example:** `Acquiring enough LPT to compete in the active set is the primary entry barrier...` [REVIEW: confirm threshold]
- **Error name:** Named-but-empty critical variable
- **Framework layer:** L5 (gate: unresolved REVIEW flag in decision-critical position)
- **Research ref:** Google Technical Writing — precision; if unknown, declare it unknown explicitly
- **Rule:** Verify and publish the number, or block the section from merge.

---

**Issue 3.2 — Dangling Claim**
- **Location:** `business-case.mdx`, Infrastructure investment accordion
- **Example:** `The break-even analysis is different.` (no analysis follows)
- **Error name:** Asserted-but-unsupported claim
- **Framework layer:** L3 (every "this is different" must show the difference)
- **Research ref:** Google Technical Writing — precision; Microsoft Style Guide — goal before procedure
- **Rule:** Show the analysis. If not on this page, link to the page that does.

---

**Issue 3.3 — Link Dump Without Decision Support**
- **Location:** `operator-rationale.mdx`, Research Tools section
- **Example:** Four links with short labels, no guidance on what conclusion to draw at each
- **Error name:** Unactionable resource list
- **Framework layer:** L2 (high-value actions include guidance, not just the resource)
- **Research ref:** Diátaxis — every page has an onward path; Microsoft Style Guide — goal before procedure
- **Rule:** For each link, state the decision it enables and the threshold that makes it meaningful.

---

**Issue 3.4 — Strawman Rebuttal**
- **Location:** `operator-rationale.mdx`, Video vs AI section
- **Example:** `AI inference is not a guaranteed shortcut to earnings.`
- **Error name:** Arguing against an unstated claim
- **Framework layer:** L4 (banned: `not [X]`)
- **Research ref:** Google Technical Writing — direct assertion; no contrast-by-diminishment
- **Rule:** Delete. The table's "Variable — demand-dependent" cell already handles this.

---

### CATEGORY 4: NOT PERSONA-FIRST / AUDIENCE MISMATCH

**Issue 4.1 — Third-Person Generalisation**
- **Location:** `business-case.mdx`, opening
- **Example:** `Most Orchestrator operators start by thinking about LPT inflation rewards.`
- **Error name:** External address; reader excluded from sentence
- **Framework layer:** L1 (persona path mapping defines the reader; writing addresses them directly)
- **Research ref:** Red Hat Modular Docs — write to specific user story; Microsoft Style Guide — second person
- **Rule:** Address the reader. State what they are here for. Trust them to self-locate.

---

**Issue 4.2 — Excludes Part of Target Audience**
- **Location:** `operator-rationale.mdx`, opening
- **Example:** `Owning a GPU is not enough to make an Orchestrator profitable.`
- **Error name:** Partial audience exclusion from sentence one
- **Framework layer:** L1 (every row in the persona mapping table must be served)
- **Research ref:** Red Hat Modular Docs — user story at module opening
- **Rule:** Rewrite so both hardware-owning operators and hardware-evaluating operators are addressed.

---

**Issue 4.3 — Third-Person Section Header on Operator-Facing Page**
- **Location:** `business-case.mdx`, section header
- **Example:** `## The Commercial Operator Landscape`
- **Error name:** External framing; reader is described, not addressed
- **Framework layer:** L1 (operator profiles; reader self-locates by functional criteria)
- **Research ref:** Microsoft Style Guide — second-person headers in procedure sections
- **Rule:** Reframe header as the reader's question or as a direct routing prompt.

---

**Issue 4.4 — UK Currency for International Audience**
- **Location:** `operator-rationale.mdx`, Hardware accordion
- **Example:** `at £800 for an RTX 4090 and £30/month earnings`
- **Error name:** Region-scoped currency for unscoped audience
- **Framework layer:** L4 (Currency Rule: USD default for international content)
- **Research ref:** Microsoft Style Guide — localisation standards
- **Rule:** USD throughout. If region-specific pricing is needed, state the scope once.

---

**Issue 4.5 — Diplomatic Non-Statement**
- **Location:** `business-case.mdx`, after comparison table
- **Example:** `Neither model is superior - they reflect different operator goals and capabilities.`
- **Error name:** Defensive editorial padding
- **Framework layer:** L3 (final sentence must be a fact, number, or next step — never a restatement)
- **Research ref:** Google Technical Writing — every sentence must carry information
- **Rule:** Delete. The table makes the comparison. Add a routing sentence if needed.

---

### CATEGORY 5: NO CLEAR USER JOURNEY / MISSING NEXT STEP

**Issue 5.1 — Consequence Without Prevention**
- **Location:** `operator-rationale.mdx`, ETH for Gas accordion
- **Example:** `A depleted ETH wallet causes missed reward rounds (LPT permanently foregone)...` [no next step]
- **Error name:** Warning without remediation
- **Framework layer:** L2 (every introduced path must be routed; L3: final sentence is a next step)
- **Research ref:** Diátaxis — every page has an onward path; Microsoft Style Guide — goal before procedure
- **Rule:** Follow every consequence statement with the specific prevention action and a link.

---

**Issue 5.2 — Leverage Claim Without Operationalisation**
- **Location:** `business-case.mdx`, Building Gateway relationships
- **Example:** `An Orchestrator running a pipeline that a Gateway cannot source has real negotiating leverage.`
- **Error name:** Asserted value with no action path
- **Framework layer:** L3 (every introduced path developed or linked)
- **Research ref:** Diátaxis — onward path; Microsoft Style Guide — goal then procedure
- **Rule:** Follow with: where to make contact, what to offer, what to reference.

---

**Issue 5.3 — Third Path Introduced, Not Routed**
- **Location:** `business-case.mdx`, after comparison table
- **Example:** `Many operators run a hybrid: inflation rewards provide a base, service fees from AI and video workloads provide the upside.`
- **Error name:** Abandoned path — majority model treated as footnote
- **Framework layer:** L2 (majority path is featured; L0 Q2 must describe the majority real-world model)
- **Research ref:** DITA — IA built around real use cases; Diátaxis — onward path
- **Rule:** The hybrid model is the featured path. It requires its own page. A footnote is not sufficient.

---

### CATEGORY 6: VALUE PROPOSITION NOT FIRST

**Issue 6.1 — Mechanism-First Frontmatter**
- **Location:** `business-case.mdx`, description field
- **Example:** `How commercial Orchestrators operate - earning from service fees rather than inflation...`
- **Error name:** Mechanism-first description; `rather than` construction
- **Framework layer:** L2 (operator outcome first); L4 (banned: `rather than`)
- **Research ref:** Microsoft Style Guide — goal before procedure
- **Rule:** Lead with the outcome. Delete `rather than`.

---

**Issue 6.2 — Cost Before Value on Evaluation Page**
- **Location:** `operator-rationale.mdx`, opening
- **Example:** Profit formula as opening element, framed as a viability test
- **Error name:** Inverted value sequence
- **Framework layer:** L2 (mandatory sequence: operator outcome first, economics fourth)
- **Research ref:** Microsoft Style Guide — goal before procedure; Diátaxis — page type discipline
- **Rule:** Establish the opportunity before the cost structure.

---

### CATEGORY 7: VAGUE / IMPRECISE LANGUAGE

**Issue 7.1 — Undefined Performance Terms**
- **Location:** `business-case.mdx`, Latency targets
- **Example:** `Consistently slow responses — even within acceptable job completion time — affect long-term selection probability.`
- **Error name:** Two undefined thresholds in a performance-critical sentence
- **Framework layer:** L4 (banned: `consistently` without number; vague operational standards)
- **Research ref:** Google Technical Writing — precision; replace qualifiers with numbers
- **Rule:** Define "acceptable", define the latency target as a number, define "long-term" as a timeframe.

---

**Issue 7.2 — Incomplete Factor List**
- **Location:** `business-case.mdx`, Latency targets
- **Example:** `Gateways rank Orchestrators by response latency among other factors.`
- **Error name:** `among other factors` — incomplete claim
- **Framework layer:** L4 (banned: `among other factors`)
- **Research ref:** Google Technical Writing — precision
- **Rule:** Name all ranking factors, or delete the clause.

---

**Issue 7.3 — Unquantified Standard**
- **Location:** `operator-rationale.mdx`, near Decision Matrix
- **Example:** `Not necessarily production-grade infrastructure, but consistently online and monitored.`
- **Error name:** Two unquantified standards
- **Framework layer:** L4 (banned: `consistently` without number; `not [X]` construction)
- **Research ref:** Google Technical Writing — precision
- **Rule:** State the uptime percentage. Delete `not necessarily production-grade`.

---

**Issue 7.4 — Category Description as Analogy**
- **Location:** `business-case.mdx`, Commercial Operator Landscape
- **Example:** `Pool operators are effectively GPU infrastructure businesses.`
- **Error name:** Analogy in place of definition
- **Framework layer:** L4 (banned: `effectively`)
- **Research ref:** Google Technical Writing — direct assertion
- **Rule:** Define the role in Livepeer-specific operational terms.

---

### CATEGORY 8: AUTHOR-PROTECTIVE HEDGING

**Issue 8.1 — CYA Note as User Guidance**
- **Location:** `business-case.mdx`, Commercial Operator Landscape
- **Example:** `Note: The commercial orchestrator landscape is evolving...`
- **Error name:** Inline disclaimer; defensive note disguised as guidance
- **Framework layer:** L5 (gate: no section ending on hedge or disclaimer)
- **Research ref:** Diátaxis — stale content is updated, not apologised for
- **Rule:** Remove from rendered content. Update `lastVerified` in frontmatter. Add a clean forward-pointer to the Discord channel.

---

**Issue 8.2 — Temporal Hedge on Decision Aid**
- **Location:** `operator-rationale.mdx`, Decision Matrix preamble
- **Example:** `Current network conditions as of early 2026 inform this matrix - stake requirements and fee levels shift over time.`
- **Error name:** Hedge undermining the decision tool it introduces
- **Framework layer:** L5 (gate: no hedge ending a section)
- **Research ref:** Diátaxis — temporal context belongs in metadata
- **Rule:** Delete from body. Frontmatter `lastVerified` field carries temporal context.

---

**Issue 8.3 — Unresolved Placeholder in Published Decision Aid**
- **Location:** `operator-rationale.mdx`, Solo video Orchestrator table row
- **Example:** `Active set threshold {/* REVIEW: confirm threshold */}`
- **Error name:** Empty decision-critical variable
- **Framework layer:** L5 (gate: decision aids must be complete)
- **Research ref:** Google Technical Writing — precision; if unknown, declare it
- **Rule:** Block from merge. Resolve with Rick/Mehrdad. Publish only when verified.

---

### CATEGORY 9: STRUCTURAL / HIERARCHY FAILURES

**Issue 9.1 — High-Value Action Hidden in Accordion**
- **Location:** `business-case.mdx`, Capability selection accordion
- **Example:** `tools.livepeer.cloud/ai/network-capabilities` URL accessible only inside collapsed accordion
- **Error name:** Primary action gated behind interaction
- **Framework layer:** L5 (gate: primary actions in body copy)
- **Research ref:** Microsoft Style Guide — most important information first
- **Rule:** Surface URL in section body before accordion. Accordion contains strategic depth, not the URL itself.

---

**Issue 9.2 — Formula Restatement**
- **Location:** `operator-rationale.mdx`, after profit formula
- **Example:** `If that line does not remain positive... solo operation does not clear its cost base.`
- **Error name:** Prose restating arithmetic already shown
- **Framework layer:** L3 (tables and diagrams stand alone)
- **Research ref:** Google Technical Writing — every sentence carries information
- **Rule:** Delete. Replace with a concrete example using numbers if elaboration is needed.

---

### CATEGORY 10: MISSING PERSONA ROUTING

**Issue 10.1 — No Self-Selection at Differentiation Point**
- **Location:** Both files
- **Error name:** Absent routing mechanism for multi-profile page
- **Framework layer:** L1 (persona path mapping); L2 (functional routing)
- **Research ref:** Red Hat Modular Docs — user story at module opening; DITA — task topics by user
- **Rule:** Add functional routing at the top of each page using hardware, LPT, and goal as identifiers.

---

**Issue 10.2 — Hybrid Path Has No Page**
- **Location:** Both files
- **Error name:** Majority operator path undocumented
- **Framework layer:** L0 Q2 (featured path is the majority model); L2 (introduced paths are routed)
- **Research ref:** DITA — IA built around real use cases, not edge cases
- **Rule:** Hybrid model requires its own page with a staged action sequence. This is an L0 failure — it must be resolved before further operator-facing content is drafted.

---

## Part B — Complete Banned Pattern Audit

For use in script enforcement (Document 4). Every item here is a machine-detectable pattern.

---

### B1 — Banned Words (unconditional)

These words are banned in all body prose without exception:

| Word | Reason |
|---|---|
| `effectively` | False precision |
| `essentially` | False precision |
| `basically` | Condescension |
| `meaningful` | Unquantified intensifier |
| `significant` | Unquantified intensifier |
| `real` (as intensifier) | Unquantified intensifier |
| `various` | Vague placeholder |
| `several` | Vague quantity |
| `simply` | Condescension |
| `just` (as minimiser) | Condescension |
| `obviously` | Condescension |
| `clearly` | Condescension |

---

### B2 — Banned Phrases (exact match)

| Phrase | Error class |
|---|---|
| `This page covers` | Page announcement |
| `This page explains` | Page announcement |
| `This section covers` | Section announcement |
| `In this guide` | Announcement |
| `The reason is straightforward` | Throat-clearing |
| `Understanding X is essential` | Instructive preamble |
| `It is important to note` | Throat-clearing |
| `As mentioned above` | Redundant callback |
| `among other factors` | Incomplete claim |
| `and so on` | Incomplete claim |
| `etc.` | Incomplete claim |
| `low but not zero` | Restated number |
| `not just [X]` | Contrast-by-diminishment |
| `rather than` | Contrast-by-diminishment |
| `what it takes` | Hurdle framing |
| `not preference` | Strawman defence |
| `once [X] is stable` | Unmeasurable condition |
| `depends on various factors` | Vague hedge |
| `it should be noted` | Throat-clearing |
| `Note that` (standalone) | Throat-clearing |

---

### B3 — Banned Patterns (regex-detectable)

| Pattern | Error class | Regex sketch |
|---|---|---|
| `not [noun/verb]` in value statements | Contrast construction | `\bnot\s+\w+` in value-proposition context |
| `if [condition]` in body prose | Conditional gatekeeping | `\bif\b` outside code blocks |
| `can [verb]` / `may [verb]` in value claims | Weakened assertion | `\b(can\|may)\s+\w+` in value-claim context |
| `[value] — if` | Self-undermining value | `—\s+if\b` |
| `This page [verb]` | Page announcement | `^This (page\|section\|guide)\s+\w+` |
| `consistently` without adjacent number | Unquantified standard | `\bconsistently\b` not followed by `\d` within 10 words |
| Currency symbol other than `$` in non-region-scoped content | Currency rule violation | `[£€¥]` outside regional scope declaration |
| `{/* REVIEW:` in rendered MDX | Unresolved flag in published content | `{\/\*\s*REVIEW:` |
| `among other` | Incomplete factor list | `\bamong other\b` |
| `not just` | Contrast-by-diminishment | `\bnot just\b` |

---

### B4 — Banned Structural Patterns (human-reviewed, not script-detectable)

| Pattern | Error class | Detection method |
|---|---|---|
| Diagram and table carrying identical data | Same-information redundancy | Human review: do they show different things? |
| Decision table with empty cell | Incomplete decision aid | Script: empty `<TableCell>` in decision table |
| Decision table with REVIEW flag in cell | Unresolved critical variable | Script: `REVIEW` inside table cell |
| High-value URL only inside `<Accordion>` | Gated primary action | Human review: is this URL in body copy too? |
| Path introduced, not developed or linked | Abandoned journey | Human review: every `path` noun followed by development or `<LinkArrow>` |
| Section ending on `<Note>` with disclaimer | Hedge as final element | Human review: Note contents; does it apologise or forward-point? |
| Cost or warning before value prop | Inverted sequence | Human review: L2 sequence check |
| Page with no functional routing language | Missing self-selection | Human review: L1 mapping table present in brief? |
