# Agent Implementation Prompt Guide — Revised
**Livepeer Docs Copy Framework — Codex Task**
**Version 2.0 — March 2026**

---

## Before running: mandatory manual checks

These must be completed by a human before handing to the agent.
Each is a confirmed infrastructure issue (see Task 1 — Infrastructure Issues).

**Check 1 — Confirm `@needs` requirement IDs with Rick**
All new `tools/scripts/` files require a valid `@needs` field in their JSDoc header.
Run: `node tests/unit/script-docs.test.js` on an existing script to see the format.
Record the IDs to use before running the agent.

**Check 2 — Read the existing PR template**
Run: `git show docs-v2:.github/pull_request_template.md`
The L5 checklist must be integrated, not appended blindly.
Sprint 2 already added enforcement content — identify it before modifying.

**Check 3 — Confirm `ai-tools/ai-skills/` path**
Run: `git ls-tree -r docs-v2 --name-only | grep ai-tools | head -20`
Confirm the directory exists and identify any existing skill files before creating `docs-copy/`.

**Check 4 — Confirm `docs-guide/tooling/` exists and registration mechanism**
Run: `git ls-tree docs-v2 docs-guide/`
Determine whether `generate-docs-guide-indexes.js` scans automatically or requires manifest entry.

**Check 5 — Identify overlap with existing style/authoring tests**
Run: `node tests/unit/style-guide.test.js 2>&1 | head -30`
Run: `node tests/unit/docs-authoring-rules.test.js 2>&1 | head -30`
List rules already enforced. Remove any duplicates from `banned-words.txt` and `banned-phrases.txt`.

**Check 6 — Confirm `tools/lib/` exists**
Run: `git ls-tree docs-v2 tools/lib/`
This is the correct location for reference files, not `tools/scripts/lib/`.

**Check 7 — Confirm `tasks/reports/` structure**
Run: `git ls-tree docs-v2 tasks/reports/`
Confirm whether `tasks/reports/copy-governance/` needs to be created for pattern observer output.

---

## Documents to attach

| Document | Contents |
|---|---|
| Doc 7 | Phase 1: brief template, banned reference files, `lint-copy.js`, PR checklist |
| Doc 9 | Phase 2: `lint-structure.js`, three SKILL.md files |
| Doc 8 | Phase 3: `lint-patterns.js`, `pattern-observer.js`, two SKILL.md files |
| Doc 11 | Root `SKILL.md`, `review-gate.md`, `copy-rules.md`, `invocation-guide.md` |
| Doc 10 | Test suite: fixture files, expected JSON files (runner rewritten below) |

---

## The prompt

```
Base branch: docs-v2
Pull docs-v2 before creating any files.

---

TASK: Create the copy governance framework files as specified in the
attached documents. Where instructions below differ from the attached
documents, these instructions take precedence.

---

STEP 0 — VERIFY BEFORE CREATING ANYTHING

1. Pull docs-v2. Confirm clean.

2. Read .github/pull_request_template.md. Note existing structure.
   Do not modify until Commit 5.

3. Confirm ai-tools/ai-skills/ path. Report what exists.

4. Confirm tools/lib/ exists. If it does not, report and stop.

5. Run: node tests/unit/style-guide.test.js --help
   Run: node tests/unit/frontmatter-taxonomy.test.js --help
   Report what each currently enforces. Do not proceed until
   cross-check against banned-words.txt is confirmed by human.

6. Read tests/run-pr-checks.js. Note where new test suites are registered.

If any Step 0 check produces an unexpected result: stop and report.

---

COMMIT 1 — Reference files

tools/lib/copy-governance/banned-words.txt
  → Content from Doc 7, P1-B, "Reference File 1"
  NOTE: Path is tools/lib/copy-governance/ NOT tools/scripts/lib/

tools/lib/copy-governance/banned-phrases.txt
  → Content from Doc 7, P1-B, "Reference File 2"

ai-tools/ai-skills/docs-copy/reference/banned-words.txt
  → Same content as tools/lib/copy-governance/banned-words.txt

ai-tools/ai-skills/docs-copy/reference/banned-phrases.txt
  → Same content as tools/lib/copy-governance/banned-phrases.txt

Commit message: "feat(copy-framework): add banned word and phrase reference files"

---

COMMIT 2 — Scripts (with corrected headers and paths)

For each script below, add the full JSDoc header block before the
file content from the attached document. Use the @needs IDs confirmed
in pre-run Check 1. Use the exact header format from tests/run-all.js.
Update all require('./lib/...') paths to require('../../lib/copy-governance/...').

tools/scripts/lint-copy.js
  → Header + content from Doc 7, P1-B
  → @purpose-statement: Enforce banned word and phrase rules on MDX content files.
  → @pipeline: P1, P2, P3

tools/scripts/lint-structure.js
  → Header + content from Doc 9, P2-D
  → @purpose-statement: Enforce structural rules on MDX content files.
  → @pipeline: P2, P3

tools/scripts/lint-patterns.js
  → Header + content from Doc 8, P3-A
  → @purpose-statement: Enforce Tier 2 copy pattern rules on MDX content files.
  → @pipeline: P3

tools/scripts/pattern-observer.js
  → Header + content from Doc 8, P3-B
  → @purpose-statement: Aggregate copy pattern violations across a tab or full v2 tree and emit a diagnostic report.
  → @pipeline: P3
  → Update output path from reports/ to tasks/reports/copy-governance/

Commit message: "feat(copy-framework): add lint scripts with required headers"

---

COMMIT 3 — Test suite (integrated into existing runner)

Create tests/unit/copy-lint.test.js
  → This file must export { runTests({ stagedOnly }) }
    returning { errors: [], warnings: [] }
  → It runs the fixture-based tests from Doc 10 as unit tests
  → stagedOnly: when true, scope to staged MDX files only
  → Do NOT create tests/copy-lint/run-all.js — that path is banned

Create tests/copy-lint-fixtures/ (development utility only — not wired to runner)
  → tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
  → tests/copy-lint-fixtures/fixtures/pass/clean-reference.mdx
  → tests/copy-lint-fixtures/fixtures/pass/clean-concept.mdx
  → tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
  → tests/copy-lint-fixtures/fixtures/fail/banned-phrases.mdx
  → tests/copy-lint-fixtures/fixtures/fail/review-flag.mdx
  → tests/copy-lint-fixtures/fixtures/fail/currency.mdx
  → tests/copy-lint-fixtures/fixtures/fail/empty-table-cell.mdx
  → tests/copy-lint-fixtures/fixtures/fail/missing-frontmatter.mdx
  → tests/copy-lint-fixtures/fixtures/fail/accordion-url-only.mdx
  → tests/copy-lint-fixtures/fixtures/fail/hedge-note.mdx
  → tests/copy-lint-fixtures/fixtures/fail/conditional-if.mdx
  → tests/copy-lint-fixtures/fixtures/fail/not-construction.mdx
  → tests/copy-lint-fixtures/expected/[all JSON files from Doc 10]
  All fixture content from Doc 10.

Update tests/run-all.js
  → Add after the Style Guide Tests block:
    const copyLintTests = require('./unit/copy-lint.test');
  → Add in runAllTests():
    console.log('\n✍️  Running Copy Lint Tests...');
    const copyLintResult = normalizeSuiteResult(copyLintTests.runTests({ stagedOnly }));
    totalErrors += copyLintResult.errors.length;
    totalWarnings += copyLintResult.warnings.length;
    console.log(`   ${copyLintResult.errors.length} errors, ${copyLintResult.warnings.length} warnings`);

Update tests/run-pr-checks.js
  → Register copyLintTests in the PR changed-file scoped run.
    Follow the exact pattern used for existing suites in that file.

Commit message: "feat(copy-framework): add copy-lint test suite, wire into runner"

---

COMMIT 4 — SKILL.md files

ai-tools/ai-skills/docs-copy/SKILL.md
  → Content from Doc 11, root SKILL.md

ai-tools/ai-skills/docs-copy/skills/copy-rules.md
  → Content from Doc 11
  → Update require paths to match tools/lib/copy-governance/ location

ai-tools/ai-skills/docs-copy/skills/structure-rules.md
  → Content from Doc 9, P2-A

ai-tools/ai-skills/docs-copy/skills/value-prop-check.md
  → Content from Doc 9, P2-B

ai-tools/ai-skills/docs-copy/skills/persona-routing.md
  → Content from Doc 9, P2-C

ai-tools/ai-skills/docs-copy/skills/review-gate.md
  → Content from Doc 11, review-gate.md section

ai-tools/ai-skills/docs-copy/skills/iteration-diagnostic.md
  → Content from Doc 8, P3-C

ai-tools/ai-skills/docs-copy/skills/pattern-observer.md
  → Content from Doc 8, P3-D

ai-tools/ai-skills/docs-copy/reference/invocation-guide.md
  → Content from Doc 11, invocation-guide.md section

ai-tools/ai-skills/docs-copy/README.md
  → Create from Doc 1 summary section (L0–L8 layer map, file index, start-here instructions)

Commit message: "feat(copy-framework): add SKILL.md files and README"

---

COMMIT 5 — Brief template, PR checklist update

docs-guide/tooling/content-brief-template.md
  → Content from Doc 7, P1-A
  → After creating, run: node tools/scripts/generate-docs-guide-indexes.js --write
  → Then run: node tests/unit/docs-guide-sot.test.js
  → Report output. If SOT test fails, do not proceed — report the failure.

.github/pull_request_template.md
  → READ the existing file first
  → INTEGRATE the L5 checklist from Doc 7, P1-D into the existing structure
  → Do not duplicate any items already present
  → Do not remove existing content

Commit message: "feat(copy-framework): add brief template, integrate L5 into PR checklist"

---

COMMIT 6 — Report output directory

tasks/reports/copy-governance/.gitkeep
  → Create the directory for pattern observer output

Commit message: "feat(copy-framework): add copy-governance report directory"

---

VERIFICATION AFTER ALL COMMITS

Run and report full output:

1. node tests/run-all.js --staged
   Expected: copy-lint suite appears in output, zero new errors from framework files

2. node tests/unit/copy-lint.test.js
   Expected: all fixture tests pass

3. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
   Expected: zero errors

4. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
   Expected: 4 BANNED_WORD errors

5. node tests/unit/script-docs.test.js --staged
   Expected: all four new scripts pass header validation

6. node tests/unit/docs-guide-sot.test.js
   Expected: pass (content-brief-template.md registered)

If any check fails: report the specific failure and stop.
Do not attempt to fix script logic or test infrastructure — report for human review.

---

FORBIDDEN

- Do not modify any existing .mdx content files in v2/
- Do not modify docs.json
- Do not modify navigation-exclusions.json
- Do not modify the .allowlist file
- Do not create tests/copy-lint/run-all.js
- Do not create .github/workflows/lint-copy.yml
- Do not merge content from multiple source documents into a single file
- Do not reformat or rewrite any file contents from the source documents
- Do not create tools/scripts/lib/ — use tools/lib/copy-governance/ instead
```

---

## Adding new items after deployment

**New banned word or phrase:**
1. Edit `tools/lib/copy-governance/banned-words.txt` or `banned-phrases.txt`
2. Mirror to `ai-tools/ai-skills/docs-copy/reference/`
3. Add fail fixture + expected JSON in `tests/copy-lint-fixtures/`
4. Run `node tests/unit/copy-lint.test.js` to confirm

**New Tier 2 pattern:**
1. Add pattern object to `PATTERNS` array in `tools/scripts/lint-patterns.js`
2. Add fail fixture + expected JSON
3. Run test suite

Both scripts import reference files at runtime. No build step required.
