# Agent Implementation Prompt Guide — Revised
**Livepeer Docs Copy Framework — Codex Task**
**Version 3.0 — March 2026**

---

## Before running: mandatory pre-flight checks

Complete these yourself before handing to the agent. Where a check
produces information (not a binary yes/no), record the output — you
will pass it into the prompt as a variable.

**Check 1 — Determine valid `@needs` requirement IDs**
Run: `grep -r "@needs" tools/scripts/ | head -20`
Run: `node tests/unit/script-docs.test.js` to confirm the validation format.
Record the IDs in active use. You will supply these to the agent in Step 0.

**Check 2 — Read the existing PR template**
Run: `git show docs-v2:.github/pull_request_template.md`
Sprint 2 already added enforcement content. Note existing sections before
the agent integrates the L5 checklist.

**Check 3 — Confirm `ai-tools/ai-skills/` path**
Run: `git ls-tree -r docs-v2 --name-only | grep ai-tools | head -20`
If the directory does not exist, the agent creates it. If it does,
note existing files to avoid overwrites.

**Check 4 — Confirm `docs-guide/tooling/` and registration mechanism**
Run: `git ls-tree docs-v2 docs-guide/`
Run: `node tools/scripts/generate-docs-guide-indexes.js --help`
Determine whether a new file in `docs-guide/tooling/` is picked up
automatically or requires a manifest entry.

**Check 5 — Identify overlap with existing style/authoring tests**
Run: `node tests/unit/style-guide.test.js --help 2>&1 | head -40`
Run: `cat tests/unit/docs-authoring-rules.test.js | head -60`
Run: `cat tests/unit/frontmatter-taxonomy.test.js | head -60`
Extract the list of rules each currently enforces. You decide whether
copy-lint runs as an additional layer or whether overlapping rules
should be removed from the new banned lists. Record your decision —
the agent will filter accordingly.

**Check 6 — Confirm `tools/lib/` exists**
Run: `git ls-tree docs-v2 tools/lib/`
If `tools/lib/` does not exist, note this — the agent will create
`tools/lib/copy-governance/` as a new directory.

**Check 7 — Confirm `tasks/reports/` structure**
Run: `git ls-tree docs-v2 tasks/reports/`
Confirm whether `tasks/reports/copy-governance/` exists or needs creating.

---

## Documents to attach

| Document | Contents |
|---|---|
| Doc 7 | Phase 1: brief template, banned reference files, `lint-copy.js`, PR checklist |
| Doc 9 | Phase 2: `lint-structure.js`, three SKILL.md files |
| Doc 8 | Phase 3: `lint-patterns.js`, `pattern-observer.js`, two SKILL.md files |
| Doc 11 | Root `SKILL.md`, `review-gate.md`, `copy-rules.md`, `invocation-guide.md` |
| Doc 10 | Test suite: fixture files, expected JSON files |
| Doc 1 | Framework L0–L8 (for README generation in Commit 4) |

---

## The prompt

```
Base branch: docs-v2
Pull docs-v2 before creating any files.

TASK: Create the copy governance framework files as specified in the
attached documents. Where instructions below differ from the attached
documents, these instructions take precedence.

---

STEP 0 — READ AND REPORT BEFORE CREATING ANYTHING

1. Pull docs-v2. Confirm clean.

2. Read tests/unit/style-guide.test.js — extract and list every rule
   it currently enforces as a table: Rule | Type (word/phrase/pattern).

3. Read tests/unit/docs-authoring-rules.test.js — same table format.

4. Read tests/unit/frontmatter-taxonomy.test.js — list every frontmatter
   field it currently validates.

5. Read .github/pull_request_template.md — note every existing section
   heading and checklist item.

6. Run: git ls-tree docs-v2 ai-tools/ — report what exists.

7. Run: git ls-tree docs-v2 tools/lib/ — report what exists.

8. Run: git ls-tree docs-v2 tasks/reports/ — report structure.

9. Read tests/run-pr-checks.js — report how test suites are registered.

Output a single STEP 0 REPORT covering all nine items above.
Stop after the report. Wait for confirmation before proceeding to Commit 1.

[YOU WILL REVIEW THE STEP 0 REPORT HERE AND CONFIRM:
 - Which banned words/phrases overlap with existing tests → remove those
   from tools/lib/copy-governance/banned-words.txt and banned-phrases.txt
 - Whether frontmatter checks should be removed from lint-structure.js
 - The @needs IDs to use in script headers: [FILL IN FROM CHECK 1]
 - Whether docs-guide/tooling/ needs a manifest entry]

---

COMMIT 1 — Reference files
(Create only after Step 0 confirmed)

tools/lib/copy-governance/banned-words.txt
  → Content from Doc 7, P1-B, "Reference File 1"
  → REMOVE any words confirmed as overlapping in Step 0 review
  NOTE: Path is tools/lib/copy-governance/ — NOT tools/scripts/lib/

tools/lib/copy-governance/banned-phrases.txt
  → Content from Doc 7, P1-B, "Reference File 2"
  → REMOVE any phrases confirmed as overlapping in Step 0 review

ai-tools/ai-skills/docs-copy/reference/banned-words.txt
  → Identical content to tools/lib/copy-governance/banned-words.txt

ai-tools/ai-skills/docs-copy/reference/banned-phrases.txt
  → Identical content to tools/lib/copy-governance/banned-phrases.txt

Commit message: "feat(copy-framework): add banned word and phrase reference files"

---

COMMIT 2 — Scripts

For each script: add the full JSDoc header block using the exact format
from tests/run-all.js lines 1–12. Use @needs IDs supplied in Step 0 review.
Update all require('./lib/...') paths to require('../../lib/copy-governance/...').
If lint-structure.js frontmatter checks are confirmed as overlapping in Step 0
review, remove those checks from the file before committing.

tools/scripts/lint-copy.js
  → Header + content from Doc 7, P1-B
  → @purpose-statement: Enforce banned word and phrase rules on MDX content files.
  → @pipeline: P1, P2, P3

tools/scripts/lint-structure.js
  → Header + content from Doc 9, P2-D
  → @purpose-statement: Enforce structural rules on MDX content files.
  → @pipeline: P2, P3
  → Remove frontmatter checks if confirmed overlapping in Step 0 review

tools/scripts/lint-patterns.js
  → Header + content from Doc 8, P3-A
  → @purpose-statement: Enforce Tier 2 copy pattern rules on MDX content files.
  → @pipeline: P3

tools/scripts/pattern-observer.js
  → Header + content from Doc 8, P3-B
  → @purpose-statement: Aggregate copy pattern violations across a tab or full v2 tree and emit a diagnostic report.
  → @pipeline: P3
  → Update all output paths to tasks/reports/copy-governance/

Commit message: "feat(copy-framework): add lint scripts with required headers"

---

COMMIT 3 — Test suite

Create tests/unit/copy-lint.test.js
  → Must export { runTests({ stagedOnly }) } returning { errors: [], warnings: [] }
  → Must follow the exact structural pattern of an existing tests/unit/*.test.js
  → Runs the fixture-based checks from Doc 10 as unit tests
  → When stagedOnly true: scope to staged MDX files only
  → Do NOT create tests/copy-lint/run-all.js

Create tests/copy-lint-fixtures/ (development reference only — not wired to runner)
  → All pass/ and fail/ fixture files from Doc 10
  → All expected/*.json files from Doc 10

Update tests/run-all.js
  Add require at top (with other requires):
    const copyLintTests = require('./unit/copy-lint.test');

  Add in runAllTests() immediately after Style Guide Tests block:
    console.log('\n✍️  Running Copy Lint Tests...');
    const copyLintResult = normalizeSuiteResult(copyLintTests.runTests({ stagedOnly }));
    totalErrors += copyLintResult.errors.length;
    totalWarnings += copyLintResult.warnings.length;
    console.log(`   ${copyLintResult.errors.length} errors, ${copyLintResult.warnings.length} warnings`);

Update tests/run-pr-checks.js
  → Register copyLintTests following the exact pattern of existing suites.
  → Scope to changed MDX files when stagedOnly is true.

Commit message: "feat(copy-framework): add copy-lint test suite, wire into runner"

---

COMMIT 4 — SKILL.md files and README

ai-tools/ai-skills/docs-copy/SKILL.md
  → Content from Doc 11, root SKILL.md section

ai-tools/ai-skills/docs-copy/README.md
  → Generate from Doc 1: include the L0–L8 layer summary table, file index
    (all files in this directory and skills/ subdirectory), and a
    "start here" section pointing to SKILL.md and invocation-guide.md

ai-tools/ai-skills/docs-copy/skills/copy-rules.md
  → Content from Doc 11, copy-rules section
  → Update any require paths to match tools/lib/copy-governance/

ai-tools/ai-skills/docs-copy/skills/structure-rules.md
  → Content from Doc 9, P2-A

ai-tools/ai-skills/docs-copy/skills/value-prop-check.md
  → Content from Doc 9, P2-B

ai-tools/ai-skills/docs-copy/skills/persona-routing.md
  → Content from Doc 9, P2-C

ai-tools/ai-skills/docs-copy/skills/review-gate.md
  → Content from Doc 11, review-gate.md section

ai-tools/ai-skills/docs-copy/skills/iteration-diagnostic.md
  → Content from Doc 8, P3-C

ai-tools/ai-skills/docs-copy/skills/pattern-observer.md
  → Content from Doc 8, P3-D

ai-tools/ai-skills/docs-copy/skills/skill-docs.md
  → Content from Doc 12 (documentation skill scope), skill file section

ai-tools/ai-skills/docs-copy/reference/invocation-guide.md
  → Content from Doc 11, invocation-guide.md section

Commit message: "feat(copy-framework): add SKILL.md files and README"

---

COMMIT 5 — Brief template and PR checklist

docs-guide/tooling/content-brief-template.md
  → Content from Doc 7, P1-A
  → After creating: run node tools/scripts/generate-docs-guide-indexes.js --write
  → Then run: node tests/unit/docs-guide-sot.test.js
  → Report output. If SOT test fails: stop and report. Do not proceed.

.github/pull_request_template.md
  → READ the existing file first (noted in Step 0)
  → INTEGRATE the L5 checklist from Doc 7, P1-D into the existing structure
  → Do not duplicate any item already present
  → Do not remove or reorder existing content

Commit message: "feat(copy-framework): add brief template, integrate L5 into PR checklist"

---

COMMIT 6 — Report directory

tasks/reports/copy-governance/.gitkeep

Commit message: "feat(copy-framework): add copy-governance report directory"

---

VERIFICATION — run after all commits and report full output

1. node tests/run-all.js --staged
   Expected: copy-lint suite appears, zero new errors

2. node tests/unit/copy-lint.test.js
   Expected: all fixture tests pass

3. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/pass/clean-guide.mdx
   Expected: zero errors

4. node tools/scripts/lint-copy.js tests/copy-lint-fixtures/fixtures/fail/banned-words.mdx
   Expected: BANNED_WORD errors matching expected/banned-words.json

5. node tests/unit/script-docs.test.js --staged
   Expected: all four new scripts pass header validation

6. node tests/unit/docs-guide-sot.test.js
   Expected: pass

If any verification fails: report the specific output and stop.
Do not attempt to fix script logic or test infrastructure.

---

FORBIDDEN

- Do not modify any existing .mdx content files in v2/
- Do not modify docs.json
- Do not modify navigation-exclusions.json
- Do not modify the .allowlist file
- Do not create tests/copy-lint/run-all.js
- Do not create .github/workflows/lint-copy.yml
- Do not create tools/scripts/lib/ — reference files go in tools/lib/copy-governance/
- Do not merge content from multiple source documents into a single file
- Do not reformat or rewrite file contents from source documents
```

---

## Adding new items after deployment

**New banned word or phrase:**
1. Edit `tools/lib/copy-governance/banned-words.txt` or `banned-phrases.txt`
2. Mirror to `ai-tools/ai-skills/docs-copy/reference/`
3. Add fail fixture + expected JSON in `tests/copy-lint-fixtures/`
4. Run `node tests/unit/copy-lint.test.js`

**New Tier 2 pattern:**
1. Add pattern object to `PATTERNS` array in `tools/scripts/lint-patterns.js`
2. Add fail fixture + expected JSON
3. Run test suite
