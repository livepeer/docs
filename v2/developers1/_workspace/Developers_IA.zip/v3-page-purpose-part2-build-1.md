# Developers tab v3 — page-purpose document (Part 2 of 3)

## Build — subgroups 1 to 4 (Video, AI, Agents, Applications)

Build is the depth section. Every page that was in v2 Concepts past the overview,
every v2 Get Started page past setup-paths, and every v2 Guide now lives here in one
of eight subgroups. The eight subgroups per user spec:

1. Video
2. AI
3. Agents
4. Applications
5. Protocol & Local Development
6. Front End Primitives
7. Beta Platforms
8. Tutorials

Parts 2 and 3 cover these subgroups. Part 3 also covers the trimmed Guides section,
Reference, and Contributing.

---

## Build / Video

### B-V-1 `/v2/developers/build/video/ingest-and-playback` — RETAINED

```yaml
---
title: "Ingest and playback"
sidebarTitle: "Ingest & playback"
description: "RTMP and WebRTC ingest to any Livepeer gateway, HLS and LL-HLS and WebRTC playback. The transport layer below the ui-kit primitives."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["B1", "E"]
journeyPosition: 3
activationMoment: "Reader has a verified ingest URL and a verified playback URL working against their chosen gateway."
---
```

**Audience** — developers shipping live or VOD video who need the transport layer
detail under the Player and Broadcast primitives.

**Journey** — from Get Started video-on-livepeer; out to Build / Front End Primitives
for the React layer, or Build / Video / gpu-transcoding for orchestrator-side depth.

**Information to convey**
- Three ingest paths (RTMP, RTMPS, WHIP WebRTC) with port and endpoint shape per
  gateway.
- Three playback paths (HLS, LL-HLS, WebRTC WHEP) with URL shape and latency
  tradeoffs.
- How a stream ID maps to ingest and playback URLs on the Community Gateway,
  Studio, Daydream, and self-hosted go-livepeer.
- Failure modes: segment drops, codec mismatches, TLS issues.

**Retention notes** — the existing page is close; trim Studio-specific JWT content
(that moves to Solutions/Studio) and add gateway-agnostic framing.

---

### B-V-2 `/v2/developers/build/video/gpu-transcoding` — RETAINED

```yaml
---
title: "GPU-accelerated transcoding"
sidebarTitle: "GPU transcoding"
description: "Which GPUs the Livepeer network transcodes on, what codec support comes with each family, and how go-livepeer selects a transcoder for a given profile."
pageType: "how-to"
primaryPersona: "B1"
secondaryPersonas: ["D"]
journeyPosition: 4
activationMoment: "Reader knows which GPU families cover their codec needs and which go-livepeer flags configure transcoder selection."
---
```

**Audience** — developers running orchestrators and app developers evaluating
transcoding cost and performance.

**Journey** — from Build / Video / ingest-and-playback; out to Build / Video /
codec-support, Orchestrators tab for full procurement-side depth.

**Information to convey**
- Nvidia NVENC (Turing, Ampere, Ada): required driver 535+, CUDA 12.x,
  nvidia-container-toolkit for Docker. Verify via `livepeer -transcoder -nvidia all`.
- AMD VAAPI: supported via ffmpeg VAAPI in lpms; lower network adoption.
- Netint MA35D: AV1 and H.265 ASIC. Targets high-density transcoding.
- Kepler and Pascal are deprecated for AI pipelines.
- Real-world throughput numbers from the Livepeer Explorer leaderboard
  (`NEXT_PUBLIC_METRICS_SERVER_URL`), Dune dashboards, stronk.rocks Orchestrator
  Explorer.

---

### B-V-3 `/v2/developers/build/video/codec-support` — NEW

```yaml
---
title: "Codec support on the Livepeer network"
sidebarTitle: "Codec support"
description: "H.264, H.265, AV1, VP9: which codecs the network transcodes to today, which orchestrator hardware supports each, and the licensing notes that matter."
pageType: "reference"
primaryPersona: "B1"
secondaryPersonas: ["E", "D"]
journeyPosition: 4
activationMoment: "Reader picks the codec for their pipeline with a clear view of hardware availability and licensing."
---
```

**Audience** — developers designing transcoding profiles and orchestrators planning
hardware purchases.

**Journey** — from Build / Video / gpu-transcoding; out to Orchestrators tab for
full hardware procurement detail.

**Information to convey**
- **H.264**: default codec. Widest compatibility. Royalty-free for internet video
  up to certain thresholds.
- **H.265 (HEVC)**: hardware-accelerated on Nvidia NVENC (Turing+) and Netint MA35D.
  Carries MPEG-LA patent pool obligations at scale.
- **AV1**: prototype in the go-livepeer fork maintained by `ad-astra-video` (Brad).
  Not merged to upstream main at time of writing. Hardware encode paths: Nvidia
  Ada (RTX 40xx) NVENC, Netint MA35D. Royalty-free.
- **VP9**: decode for ingest; encode rarely requested.
- **AAC, Opus**: audio, standard ffmpeg support.
- Cross-link Ecosystem community ad-astra-video for fork status.

---

### B-V-4 `/v2/developers/build/video/transcoding-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "Transcoding quickstart"
sidebarTitle: "Transcoding quickstart"
description: "Submit a transcoding job to the Livepeer network in ten minutes, from a Go or TypeScript client, against a self-hosted or community gateway."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["B1"]
journeyPosition: 3
activationMoment: "Reader has a successful transcoded segment returned from the network."
---
```

**Journey** — from Get Started video-on-livepeer; out to Build / Video / ingest-and-playback.

**Information to convey**
- Minimal job submission flow via `livepeer-go` or a direct HTTP POST to a
  gateway's transcode endpoint.
- Expected output (HLS manifest, segment URLs).
- Failure modes and how to check orchestrator availability.

**Retention notes** — content already exists in v2 Get Started; move path, light rewrite to
remove Studio-specific framing.

---

### B-V-5 `/v2/developers/build/video/storage-and-archival` — MOVED from v2 Guides

```yaml
---
title: "Storage and archival"
sidebarTitle: "Storage & archival"
description: "Where transcoded segments land: S3, GCS, local disk, catalyst-uploader targets. Archival patterns with IPFS and Filecoin."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["B1"]
journeyPosition: 4
activationMoment: "Reader has a storage backend configured and a retention plan."
---
```

**Information to convey**
- `catalyst-uploader` supports S3, GCS, IPFS, local disk.
- IPFS pinning via Storacha (successor to web3.storage), Singularity, Lighthouse.
- Filecoin archival is application-layer — no direct Filecoin integration in
  go-livepeer, lpms, or catalyst-uploader. The Studio-bound archival UX moves to
  Solutions / Studio / docs.
- Retention, lifecycle rules, tiering patterns.

---

### B-V-6 `/v2/developers/build/video/live-events` — MOVED from v2 Guides

```yaml
---
title: "Live event patterns"
sidebarTitle: "Live events"
description: "Planning, running, and recording a live event on Livepeer. Multi-bitrate profiles, DVR windows, recording triggers."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["B1", "E"]
journeyPosition: 4
activationMoment: "Reader can plan a live event end-to-end from ingest to recording."
---
```

**Information to convey** — covered by existing v2 content; this entry locks the new path.

---

### B-V-7 `/v2/developers/build/video/vod-workflows` — MOVED from v2 Guides

```yaml
---
title: "VOD workflows"
sidebarTitle: "VOD workflows"
description: "Upload, transcode, generate playback. The VOD lifecycle on the Livepeer network using gateway-agnostic tooling."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["E"]
journeyPosition: 4
activationMoment: "Reader has the VOD lifecycle understood end to end."
---
```

**Information to convey** — existing v2 content moved; reframe away from Studio
Asset API to gateway-agnostic upload + transcode + playback flows. Studio-bound
Asset API patterns stay in Solutions / Studio / docs.

---

## Build / AI

### B-A-1 `/v2/developers/build/ai/ai-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "AI Gateway quickstart"
sidebarTitle: "AI quickstart"
description: "Install @livepeer/ai or livepeer-ai-python, authenticate against any AI Gateway, run a text-to-image and an image-to-video call. Production-shaped not toy."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["B2", "E"]
journeyPosition: 3
activationMoment: "Reader has two successful AI Gateway calls returned with full error-handling wiring in place."
---
```

**Information to convey**
- Install, auth, first call.
- Gateway-agnostic pattern.
- Error handling and retry.
- Out-link to ai-pipelines for model catalogue.

**Retention notes** — move existing v2 Get Started content; keep gateway-agnostic
framing and drop Studio-specific branching.

---

### B-A-2 `/v2/developers/build/ai/ai-orchestration` — RETAINED

```yaml
---
title: "AI orchestration on the network"
sidebarTitle: "AI orchestration"
description: "How a gateway routes an AI request to an orchestrator, how orchestrators advertise capabilities and prices, how selection weighting works."
pageType: "concept"
primaryPersona: "B1"
secondaryPersonas: ["D", "E"]
journeyPosition: 4
activationMoment: "Reader can predict which orchestrator will serve a given request under their gateway configuration."
---
```

**Information to convey**
- Capability advertisement from orchestrator to gateway.
- Selection weighting: `-selectRandFreq`, `-selectStakeWeight`,
  `-selectPriceWeight`, `-selectPriceExpFactor`.
- Orchestrator blocklist and min-version (`-orchBlocklist`,
  `-orchMinLivepeerVersion`).
- Community open question on capability discovery:
  https://forum.livepeer.org/t/ai-capability-discovery/3233.

---

### B-A-3 `/v2/developers/build/ai/realtime-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "Realtime LV2V quickstart"
sidebarTitle: "Realtime quickstart"
description: "Start a live-video-to-video job against a gateway in Python using livepeer-python-gateway. From zero to a frame round-trip in one page."
pageType: "tutorial"
primaryPersona: "B2"
secondaryPersonas: ["E"]
journeyPosition: 3
activationMoment: "Reader has a camera-captured frame successfully round-tripped through a realtime LV2V job."
---
```

**Information to convey**
- Install `livepeer-python-gateway` (commit 295f2f25 or later).
- `StartJobRequest` and `start_lv2v()` usage.
- Token schema for orchestrator selection and remote signing:
  `orchestrators`, `signer`, `signer_headers`, `discovery`, `discovery_headers`.
- Example pattern pointing at `examples/camera_capture.py`,
  `examples/write_frames.py`, `examples/subscribe_events.py`.
- Note on alpha status: API changes expected.

---

### B-A-4 `/v2/developers/build/ai/byoc-architecture` — MOVED from v2 Concepts

```yaml
---
title: "BYOC architecture"
sidebarTitle: "BYOC architecture"
description: "The BYOC execution path on go-livepeer, the container contract via pytrickle, how author pricing and orchestrator selection work."
pageType: "concept"
primaryPersona: "E"
secondaryPersonas: ["B2"]
journeyPosition: 4
activationMoment: "Reader can name the four HTTP endpoints a BYOC container must expose and the four FrameProcessor methods it must implement."
---
```

**Information to convey**
- BYOC streaming path merged into go-livepeer main, decoupled from ai-runner,
  per AI SPE Phase 4 Retrospective (26 Jan 2026).
- Canonical spec: *BYOC PyTrickle Engineering Spec for Custom Containers*.
- Container contract:
  - Endpoints: `/api/stream/start`, `/api/stream/params`, `/api/stream/status`,
    `/api/stream/stop`.
  - `pytrickle.FrameProcessor` methods: `initialize()`,
    `process_video_async(frame)`, `process_audio_async(frame)`,
    `update_params(params)`.
- Orchestrator `serviceAddr` include/exclude filter from go-livepeer PR #3634
  (ad-astra-video).
- Author pricing model.
- Cross-link to AI SPE Phase 4 retrospective at
  `forum.livepeer.org/t/ai-spe-phase-4-retrospective/3208`.

---

### B-A-5 `/v2/developers/build/ai/byoc-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "BYOC quickstart"
sidebarTitle: "BYOC quickstart"
description: "Fork a reference BYOC app, swap in your pipeline, publish the container, register with an orchestrator. End-to-end in one page."
pageType: "tutorial"
primaryPersona: "E"
secondaryPersonas: ["B2"]
journeyPosition: 3
activationMoment: "Reader has a container running their own FrameProcessor exercised by a gateway."
---
```

**Information to convey**
- Start from `muxionlabs/byoc-example-apps`: Soldar (Muxion Labs + @rickstaa),
  Realtime Transcription (@JJassonn69 + Muxion Labs, `project-transcript`),
  Video Understanding (@JJassonn69 + Muxion Labs, `gemma3n-pytrickle-app`).
- Fork, swap FrameProcessor, build Docker image, push to a registry, register
  capability.
- Showcase site: https://example-apps.muxionlabs.org.

---

### B-A-6 `/v2/developers/build/ai/byoc-production` — NEW

```yaml
---
title: "BYOC in production"
sidebarTitle: "BYOC production"
description: "Hardening a BYOC container for sustained traffic: observability hooks, framerate bounds, audio format handling, data-channel output patterns."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["B2"]
journeyPosition: 5
activationMoment: "Reader has their container instrumented and sized for real demand."
---
```

**Information to convey**
- `StreamServer` monitoring endpoints expose frame times, input/output FPS,
  memory, errors.
- Framerate defaults (24 FPS default, 60 FPS cap) and per-stream override via
  `max_framerate` in `/api/stream/start`.
- Audio format handling: pytrickle auto-converts mono, stereo, multi-channel.
- Data-channel output patterns from the Phase 4 retrospective.
- Integration into docs.comfystream.org for ComfyStream-compatible BYOC.

---

### B-A-7 `/v2/developers/build/ai/comfystream-platform` — RETAINED

```yaml
---
title: "ComfyStream platform"
sidebarTitle: "ComfyStream platform"
description: "ComfyStream as a real-time streaming backend: three execution modes (WebRTC hosted, BYOC-wrapped, library import), dynamic warmup, automatic modality detection."
pageType: "concept"
primaryPersona: "B2"
secondaryPersonas: ["C", "E"]
journeyPosition: 4
activationMoment: "Reader has a clear picture of which ComfyStream execution mode to use."
---
```

**Information to convey** — three execution modes (WebRTC hosted, BYOC-wrapped,
library); Phase 4 additions (text/data-channel output, multimodal, dynamic warmup);
canonical docs at `docs.comfystream.org`.

---

### B-A-8 `/v2/developers/build/ai/comfystream-authoring` — RETAINED

```yaml
---
title: "Authoring ComfyStream workflows"
sidebarTitle: "Workflow authoring"
description: "How to structure a ComfyStream workflow for real-time use, how to package custom nodes, how to ship a workflow for ComfyStream to consume."
pageType: "how-to"
primaryPersona: "C"
secondaryPersonas: ["B2"]
journeyPosition: 5
activationMoment: "Reader has their own workflow running under ComfyStream."
---
```

---

### B-A-9 `/v2/developers/build/ai/comfyui-stream-pack` — RETAINED

```yaml
---
title: "ComfyUI Stream Pack node catalogue"
sidebarTitle: "Stream Pack"
description: "The four Phase 4 node sets: StreamDiffusion+SDXL+TensorRT+LoRAs+Controlnets+IP-Adapters, StreamDiffusion V2 (V2V and I2I), Super Resolution, AudioTranscription+SRT."
pageType: "reference"
primaryPersona: "B2"
secondaryPersonas: ["C"]
journeyPosition: 5
activationMoment: "Reader picks the right node set for their pipeline."
---
```

**Information to convey** — node-set summary per Phase 4 retrospective.
MuxionLabs `comfyui-rtc` for WebRTC streaming within ComfyUI.

---

### B-A-10 `/v2/developers/build/ai/pytrickle` — RETAINED

```yaml
---
title: "PyTrickle"
sidebarTitle: "PyTrickle"
description: "The Python integration layer for BYOC: FrameProcessor, StreamServer, tensor conventions, audio format handling, framerate limits."
pageType: "reference"
primaryPersona: "E"
secondaryPersonas: ["B2"]
journeyPosition: 5
activationMoment: "Reader has the API signatures they need to extend pytrickle."
---
```

**Information to convey** — per the pytrickle README:
- `FrameProcessor` abstract class with four async methods.
- `StreamServer`, `TrickleClient`, `TrickleProtocol` supporting classes.
- Framerate defaults and caps.
- Tensor conventions (PyTorch, CPU/CUDA auto-move).
- Installation prerequisites (Python 3.8+, PyTorch, FFmpeg).
- Link to pytrickle docs at `muxionlabs.github.io/pytrickle/`.

---

### B-A-11 `/v2/developers/build/ai/ai-pipelines` — RETAINED

```yaml
---
title: "AI pipeline catalogue"
sidebarTitle: "AI pipelines"
description: "Every endpoint exposed by the AI Gateway API: text-to-image, image-to-image, image-to-video, upscale, audio-to-text, text-to-speech, segment-anything-2, image-to-text, LLM, live-video-to-video, BYOC."
pageType: "reference"
primaryPersona: "A"
secondaryPersonas: ["B2", "E"]
journeyPosition: 4
activationMoment: "Reader can select the right endpoint and model for their use case."
---
```

**Information to convey**
- Endpoint table with method, purpose, SDK binding.
- Cross-link to OpenAPI spec in ai-worker at `runner/gen_openapi.py`.
- Authoritative model roster in ai-runner; Daydream may expose additional models
  via BYOC outside the base list.

---

## Build / Agents

### B-Ag-1 `/v2/developers/build/agents/agent-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "Agent quickstart"
sidebarTitle: "Agent quickstart"
description: "Clone livepeer/storyboard, install, run the dev server, see an agent calling a Livepeer capability end to end."
pageType: "tutorial"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 3
activationMoment: "Reader has Storyboard running locally with a working agent loop."
---
```

**Information to convey**
- Clone `livepeer/storyboard`, `npm install`, `npm run dev` (Storyboard on port
  3000, Creative Lab on 3001).
- Configure SDK service URL to `https://sdk.daydream.monster` with
  `DAYDREAM_API_KEY`.
- Walk the first agent tool call through the AgentRunner loop.
- Note: `@livepeer/agent` not published to npm; use workspace packages from the
  monorepo.

---

### B-Ag-2 `/v2/developers/build/agents/agent-sdk` — NEW

```yaml
---
title: "@livepeer/agent SDK"
sidebarTitle: "Agent SDK"
description: "AgentRunner, ToolRegistry, WorkingMemory. Provider abstraction: Gemini, Claude, OpenAI, Livepeer. Publication state and how to vendor the workspace package."
pageType: "reference"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader can build a custom agent against the SDK surface."
---
```

**Information to convey**
- `AgentRunner` manages the LLM-to-tool loop.
- `ToolRegistry.register(name, schema, handler)`.
- `WorkingMemory` with 800-token budget and session memory log.
- Provider abstraction: Gemini (default), Claude, OpenAI, Livepeer.
- Livepeer provider routes all LLM calls through `sdk.daydream.monster` with a
  single `DAYDREAM_API_KEY`.
- Publication state: not on npm as of April 2026. Vendor from
  `livepeer/storyboard/packages/agent` or build on Storyboard directly.

---

### B-Ag-3 `/v2/developers/build/agents/reference-agents` — NEW

```yaml
---
title: "Reference agent templates"
sidebarTitle: "Reference agents"
description: "Titan-Node templates ready to fork: livepeer-8004-agent (EIP-8004 agent), livepeer-402-middleware (402-protocol paid endpoint), Unreal_Vtuber pipelines, ai-benchmark, payment-stream."
pageType: "reference"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader picks a template that matches their agent shape and clones it."
---
```

**Information to convey**
- `Titan-Node/livepeer-8004-agent`: EIP-8004 agent enabling AI systems to
  request, price, and execute tasks on decentralised GPU infrastructure.
- `Titan-Node/livepeer-402-middleware`: Next.js 16 + HTTP 402 + Base network +
  Livepeer Studio `asset.createViaUrl`. Target discovery domain
  `api.livepeer.bot`. This one is Studio-based, flag that distinction.
- `Titan-Node/Unreal_Vtuber` and `vtuber-extension`: real-time VTuber avatar
  pipelines via ComfyStream and Unreal Engine.
- `Titan-Node/ai-benchmark`: pipeline benchmarking harness.
- `Titan-Node/payment-stream`: payment-related tooling.
- Agent SPE treasury context from forum threads.

---

### B-Ag-4 `/v2/developers/build/agents/eliza-integration` — NEW

```yaml
---
title: "Livepeer as an Eliza provider"
sidebarTitle: "Eliza integration"
description: "The Livepeer model provider plugin for the Eliza agent framework (ai16z). OpenAI-compatible chat completions routed through a Livepeer gateway."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader has an Eliza agent routing LLM calls through their chosen Livepeer gateway."
---
```

**Information to convey**
- Plugin location: inside the Eliza framework (`ai16z/eliza`).
- Routes OpenAI-compatible `/v1/chat/completions` to Livepeer gateway:
  Studio at `livepeer.studio/api/beta/generate/llm`, Community Gateway at
  `gateway.livepeer.cloud`, or self-hosted.
- Cross-link Build / Tutorials / build-an-ai-agent-on-livepeer for the end-to-end
  walkthrough.
- Cross-link Titan-Node VTuber repos for avatar-driven Eliza agents.

---

## Build / Applications

### B-App-1 `/v2/developers/build/applications/running-a-gateway` — MOVED from v2 Concepts

```yaml
---
title: "Running a gateway"
sidebarTitle: "Running a gateway"
description: "When an app graduates from a managed gateway to its own infrastructure, what go-livepeer -gateway mode provides, how to configure orchestrator discovery and ticket economics."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["B1"]
journeyPosition: 4
activationMoment: "Reader has a running go-livepeer gateway reachable from their app and serving at least one orchestrator-routed job."
---
```

**Information to convey**
- Graduation signal from Nov 2025 Network Vision: monthly API spend becomes
  material, dev wants selection control, or inference must stay in dev's own
  infra.
- Minimum viable: single go-livepeer gateway binary, `-network offchain` (or
  Arbitrum One), `-orchAddr` or `-orchWebhookUrl`, port 8937.
- Alternatives: Community Gateway at `gateway.livepeer.cloud`, GWID managed
  (Phase 1 approved), self-hosted local gateway.

**Retention notes** — this was wrongly placed under v2 Concepts. Move to Build /
Applications where it belongs.

---

### B-App-2 `/v2/developers/build/applications/local-gateway` — NEW

```yaml
---
title: "Local gateway for a single app"
sidebarTitle: "Local gateway"
description: "Running a minimal go-livepeer gateway alongside a developer's app. Feb 2026 roadmap item translated into a working configuration."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["E"]
journeyPosition: 4
activationMoment: "Reader has a gateway bundled with their app and reachable only from localhost or private network."
---
```

**Information to convey**
- Docker Compose for go-livepeer `-gateway` mode beside an app container.
- Configuration: `-network offchain` or Arbitrum One, `-orchAddr`, `-orchWebhookUrl`.
- Health and metrics on ports 7936 and the CLI port.
- Fit vs managed gateways.

---

### B-App-3 `/v2/developers/build/applications/custody-and-signing` — MOVED from v2 Concepts

```yaml
---
title: "Custody and signing"
sidebarTitle: "Custody & signing"
description: "Where a gateway or app signs transactions and tickets. Remote-signer pattern via livepeer-python-gateway. HSM and vault options."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["D"]
journeyPosition: 5
activationMoment: "Reader has a signing topology that matches their threat model."
---
```

**Information to convey**
- go-livepeer node keys stored as UTC JSON keyfiles via `-ethKeystorePath`.
- Orchestrator operator keys: one per orchestrator; rotation requires unbond +
  rebond.
- `livepeer-python-gateway` remote-signer support via token schema (`signer`
  URL + `signer_headers`).
- HSM and vault patterns: AWS KMS, HashiCorp Vault, pymthouse PostgreSQL-backed.
- `Stronk-Tech/OrchestratorSiphon` for keeping the orchestrator keystore offline
  and signing operational transactions.

---

### B-App-4 `/v2/developers/build/applications/pymthouse-and-oidc` — MOVED from v2 Guides

```yaml
---
title: "Pymthouse and OIDC-based signer DMZs"
sidebarTitle: "Pymthouse & OIDC"
description: "eliteprox/pymthouse architecture: Next.js dashboard, PostgreSQL, signer-dmz container with Apache JWT verification in front of go-livepeer. OIDC topology for multi-tenant gateways."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["D"]
journeyPosition: 6
activationMoment: "Reader has a pymthouse stack running locally with an admin token and a first signer token issued."
---
```

**Information to convey** — from pymthouse README:
- Next.js app on port 3001, PostgreSQL, signer-dmz container (Apache + JWT +
  go-livepeer).
- NextAuth OIDC flow; `npm run oidc:seed` for signing keys.
- Multi-tenant via per-app credentials at `/api/v1/apps/{clientId}/credentials`.
- Bearer tokens `pmth_` prefix, 1-year validity.
- Google, GitHub OAuth and Turnkey Wallet Kit.
- Deployment patterns: Vercel + Railway/Render/Fly.io + Neon/Vercel Postgres.

---

### B-App-5 `/v2/developers/build/applications/gateway-for-app-developers` — NEW

```yaml
---
title: "Gateway integration patterns for app developers"
sidebarTitle: "Gateway integration"
description: "How an app hooks into a managed gateway, a shared community gateway, or its own gateway. Identity handoff, per-tenant quotas, usage telemetry."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader picks the gateway integration pattern that matches their app's identity and billing model."
---
```

**Information to convey**
- Pattern A: managed gateway + per-app API keys.
- Pattern B: shared community gateway (Cloud SPE, Community Gateway at
  `gateway.livepeer.cloud`).
- Pattern C: self-hosted gateway with pymthouse-style DMZ in front.
- Per-tenant quota enforcement at the JWT layer.
- Cross-link custody-and-signing and pymthouse-and-oidc.

---

### B-App-6 `/v2/developers/build/applications/data-and-observability` — MOVED from v2 Concepts

```yaml
---
title: "Data and observability"
sidebarTitle: "Data & observability"
description: "What data the network exposes and how to consume it: subgraph, livepeer-data, livepeer-monitoring, NaaP Analytics, Prometheus scrape endpoints, community exporters."
pageType: "concept"
primaryPersona: "F"
secondaryPersonas: ["B1", "E"]
journeyPosition: 5
activationMoment: "Reader knows which source answers their question and has the endpoint to query."
---
```

**Information to convey** — three-source split:
- **Foundation-hosted**: `livepeer/livepeer-data`, `livepeer-data-mcp`,
  `livepeer-monitoring`, `grafana-dashboards`, subgraph via The Graph.
- **Cloud SPE-hosted**: NaaP Analytics, free + open source, from reference
  load-test gateways.
- **Community-hosted**: `transcodeninja/livepeer-exporter`, Stronk-Tech org
  tools, rickstaa Dune dashboards, stronk.rocks, Livepeer.Tools.
- **Studio-bound** (listed only): Studio webhook catalogue lives in Solutions /
  Studio.

---

### B-App-7 `/v2/developers/build/applications/settlement-observability` — NEW

```yaml
---
title: "Settlement observability"
sidebarTitle: "Settlement observability"
description: "Ticket lifecycle from gateway creation to on-chain redemption. Metrics, reconciliation, failure modes."
pageType: "how-to"
primaryPersona: "F"
secondaryPersonas: ["B1"]
journeyPosition: 5
activationMoment: "Reader has a working reconciliation pipeline between gateway-side ticket metrics and on-chain redemption events."
---
```

**Information to convey**
- Ticket creation with `-ticketEV` (default 1e12 wei), `-maxTicketEV` (3e12),
  `-depositMultiplier` (1).
- On-chain events: `WinningTicketRedeemed`, `TicketRedemptionFailed` on
  TicketBroker proxy `0xa8bB618B1520E284046F3dFc448851A1Ff26e41B`.
- Off-chain accounting metrics from go-livepeer Prometheus output.
- Reconciliation pattern: subtract on-chain redeemed from off-chain sent.
- Known upstream bug: `livepeer_orch_winning_ticket_gas_used` reports gas limit
  not gas used (documented in `transcodeninja/livepeer-exporter`).
- Expected settlement latency ~22h on Arbitrum One per RoundsManager.

---

### B-App-8 `/v2/developers/build/applications/prometheus-scrape` — NEW

```yaml
---
title: "Prometheus scrape configuration"
sidebarTitle: "Prometheus scrape"
description: "Scrape targets, ports, labels, and cardinality guidance for go-livepeer, ai-runner, catalyst-api, pymthouse, and community exporters."
pageType: "how-to"
primaryPersona: "F"
secondaryPersonas: ["B1"]
journeyPosition: 5
activationMoment: "Reader has a running Prometheus scraping all relevant surfaces with sane label cardinality."
---
```

**Information to convey**
- go-livepeer: ports 7935 (orchestrator, transcoder) and 7936 (gateway), path
  `/metrics`, labels `livepeer_node_type` (broadcaster / orchestrator /
  transcoder — broadcaster is legacy for gateway).
- ai-runner: FastAPI metrics when run separately.
- catalyst-api: `/metrics` on its service port.
- pymthouse: `/api/v1/health` on port 3001 (health only, no Prometheus metrics
  in base repo).
- High-cardinality labels to watch: `stream_id`, `session_id`, `orchestrator`.
- Reference compose: `kyriediculous/livepeer-promgraf`.
- Known limitation: `livepeer/docker-livepeer#29` — bundled Grafana dashboards
  target Kubernetes `livepeer_node_type` labels; standalone Docker needs
  customisation.

---

## End of Part 2
