# Developers tab v3 — page-purpose document (Part 3 of 3)

## Build — subgroups 5 to 8, plus Guides, Reference, Contributing

---

## Build / Protocol & Local Development

### B-Pl-1 `/v2/developers/build/protocol/trickle-protocol` — MOVED from v2 Concepts

```yaml
---
title: "Trickle protocol"
sidebarTitle: "Trickle protocol"
description: "The HTTP-based streaming protocol underpinning Livepeer realtime and BYOC paths. Wire format, the Go reference implementation at livepeer/http-trickle, and the Python wrapper at livepeer/pytrickle."
pageType: "concept"
primaryPersona: "D"
secondaryPersonas: ["B2", "E"]
journeyPosition: 5
activationMoment: "Reader can read a trickle request at the wire level and map it to pytrickle FrameProcessor behaviour."
---
```

**Information to convey**
- HTTP-based streaming protocol. Go reference implementation:
  `j0sh/http-trickle` (also at `livepeer/http-trickle`).
- Default port 3389 in pytrickle examples.
- Wire shape: `POST http://host:3389/<stream>` to publish, `GET` to subscribe.
- Stream-scoped by path; no long-lived WebSocket.
- Python wrapper: `livepeer/pytrickle`.
- Used by ComfyStream (via ComfyUI-RTC custom node set, local RTC server) and
  BYOC containers via pytrickle.

---

### B-Pl-2 `/v2/developers/build/protocol/payment-modes` — MOVED from v2 Concepts

```yaml
---
title: "Payment modes"
sidebarTitle: "Payment modes"
description: "The three payment modes a gateway drives: LV2V (live-video-to-video), batch AI (generate endpoints), BYOC (author-priced containers). Ticket mechanics for each."
pageType: "concept"
primaryPersona: "D"
secondaryPersonas: ["B1", "E"]
journeyPosition: 5
activationMoment: "Reader can pick the correct payment mode for a given workload and explain the settlement path."
---
```

**Information to convey**
- LV2V via `/live-video-to-video`: used by ComfyStream and Daydream; BYOC
  streaming parameter updates via store-and-forward from PR #3634 and follow-ups.
- Batch AI via `/generate/*`: text-to-image, image-to-image, etc. via SDKs.
- BYOC via `/byoc/*` with author-defined pricing (Phase 4 merged decoupled
  path).
- Ticket mechanics: probabilistic micropayments in
  `livepeer/protocol/TicketBroker`.
- CLI flags: `-ticketEV`, `-maxTicketEV`, `-depositMultiplier`, `-pricePerUnit`,
  `-pixelsPerUnit`.
- Developer-facing surface: per-request aggregate cost via SDK; per-ticket
  detail only visible to gateway operators.

---

### B-Pl-3 `/v2/developers/build/protocol/off-chain-discovery` — MOVED from v2 Concepts

```yaml
---
title: "Off-chain orchestrator discovery"
sidebarTitle: "Off-chain discovery"
description: "How a gateway finds orchestrators without reading on-chain state. Webhooks, static lists, signer-derived discovery endpoints. Configuration via go-livepeer flags or the Python gateway token schema."
pageType: "concept"
primaryPersona: "B1"
secondaryPersonas: ["D", "E"]
journeyPosition: 5
activationMoment: "Reader can configure custom discovery for a gateway and trace how a request lands on an orchestrator."
---
```

**Information to convey**
- go-livepeer flags:
  - `-orchWebhookUrl <url>`: discovery callback; invalid schemes exit early.
    POST on each `GetOrchestratorInfo`; webhook may override price via
    `priceInfo`.
  - `-authWebhookUrl <url>`: auth webhook per stream.
  - `-network offchain`: disables on-chain registration, payments, verification.
  - `-orchAddr`: static orchestrator address.
  - `-orchBlocklist`: comma-separated block list.
  - Selection weighting: `-selectRandFreq`, `-selectStakeWeight`,
    `-selectPriceWeight`, `-selectPriceExpFactor`.
- `livepeer-python-gateway` base64 token schema: `orchestrators`, `signer`,
  `signer_headers`, `discovery`, `discovery_headers`.
- Selection precedence: token `orchestrators` → explicit `orch_url` → token
  `discovery` → explicit `discovery_url` → signer-derived discovery.
- Open community question thread: `forum.livepeer.org/t/ai-capability-discovery/3233`.

---

### B-Pl-4 `/v2/developers/build/protocol/python-gateway` — RETAINED

```yaml
---
title: "Python gateway"
sidebarTitle: "Python gateway"
description: "livepeer-python-gateway: module layout, StartJobRequest and start_lv2v API, token schema, examples, parity vs Go gateway, alpha status."
pageType: "reference"
primaryPersona: "B2"
secondaryPersonas: ["E"]
journeyPosition: 5
activationMoment: "Reader can call start_lv2v, configure discovery via a token, and subscribe to event streams."
---
```

**Information to convey** — from `livepeer/livepeer-python-gateway` (commit 295f2f25):
- Module `livepeer_gateway.lv2v`: `StartJobRequest`, `start_lv2v(...)`.
- Examples: `get_orchestrator_info.py`, `write_frames.py`, `camera_capture.py`,
  `in_out_composite.py`, `subscribe_events.py`.
- Protobuf regen: `uv run generate-lp-rpc`.
- Parity: LV2V primary scope; batch AI and transcoding remain Go-gateway-only.
- Alpha status; rapid API evolution per Feb 2026 roadmap "Simplify Crypto
  Payments and SDKs".

---

### B-Pl-5 `/v2/developers/build/protocol/lpms-integration` — NEW

```yaml
---
title: "Integrating with lpms"
sidebarTitle: "lpms integration"
description: "lpms as a Go library: the module path, key exported types, CGO and ffmpeg binding considerations, cross-compile caveats, extension points."
pageType: "how-to"
primaryPersona: "D"
secondaryPersonas: ["E"]
journeyPosition: 5
activationMoment: "Reader has an lpms-linked Go program running a transcode on a local file."
---
```

**Information to convey**
- Go module path: `github.com/livepeer/lpms`.
- Core types: `LPMS`, `Segmenter`, `Transcoder`, RTMP handlers.
- CGO + ffmpeg; static build via go-livepeer's `install_ffmpeg.sh`.
- TensorFlow libraries bundled in newer Docker images (+~700MB).
- Extension points: custom probes, custom muxers.

---

### B-Pl-6 `/v2/developers/build/protocol/self-host-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "Self-host a full stack"
sidebarTitle: "Self-host quickstart"
description: "Run go-livepeer gateway + orchestrator + Prometheus + Grafana on one machine via Docker Compose. Three variants: docker-livepeer, catalyst, promgraf."
pageType: "tutorial"
primaryPersona: "D"
secondaryPersonas: ["B1", "E"]
journeyPosition: 4
activationMoment: "Reader has a single-machine Livepeer stack running locally with metrics visible in Grafana."
---
```

**Information to convey**
- Variant 1: `livepeer/docker-livepeer` (official Docker images with
  Prometheus + Grafana).
- Variant 2: `livepeer/catalyst` + `catalyst-api` + `catalyst-uploader` (used by
  Streamplace).
- Variant 3: `kyriediculous/livepeer-promgraf` (Prometheus + Grafana scraping
  7935/7936).
- Kubernetes path via `livepeer/livepeer-charts` + `cloudflared-ingress-operator`.
- Known issue: `livepeer/docker-livepeer#29` on standalone Grafana dashboards.

---

### B-Pl-7 `/v2/developers/build/protocol/livepeer-in-a-box` — MOVED from v2 Guides

```yaml
---
title: "Livepeer-in-a-Box"
sidebarTitle: "Livepeer-in-a-Box"
description: "Docker Compose-based single-machine dev stack. The canonical local dev flow for running gateway + orchestrator against a private testnet."
pageType: "how-to"
primaryPersona: "D"
secondaryPersonas: ["E"]
journeyPosition: 5
activationMoment: "Reader has gateway + orchestrator running against a private ETH network with protocol contracts deployed locally."
---
```

**Information to convey**
- Private testnet via Ganache or Hardhat, `livepeer/protocol` deployed locally.
- Bind-mount local go-livepeer source for contributor work.
- `dlv` debugger attach patterns.
- Cross-link go-livepeer `doc/devenv.md`.

---

### B-Pl-8 `/v2/developers/build/protocol/contributor-quickstart` — MOVED from v2 Get Started

```yaml
---
title: "Contributor quickstart"
sidebarTitle: "Contributor quickstart"
description: "Your first contribution to a Livepeer repo: fork, local dev loop, PR conventions per repo. Maintainers, reviewers, issue labels."
pageType: "tutorial"
primaryPersona: "D"
secondaryPersonas: []
journeyPosition: 3
activationMoment: "Reader has a PR opened and linked to a maintainer for review."
---
```

**Information to convey** — router page into the Contributing section.

---

### B-Pl-9 `/v2/developers/build/protocol/recurring-jobs` — MOVED from v2 Guides

```yaml
---
title: "Recurring jobs against Livepeer"
sidebarTitle: "Recurring jobs"
description: "Scheduling patterns for repeated AI or transcoding calls: cron, Kubernetes CronJob, Temporal, BullMQ. Error handling, retry budgets, cost ceilings."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader has a scheduled job calling the AI Gateway with error handling and cost controls."
---
```

**Information to convey**
- Scheduling patterns: cron, Kubernetes `CronJob`, Temporal workflows, BullMQ,
  Sidekiq, all wrapping AI Gateway SDK calls.
- Do not expose `livepeer/task-runner` as a developer-facing pattern — it is
  Studio's internal service tightly coupled to Studio's Asset API and RabbitMQ
  event bus.
- Studio-specific task patterns move to Solutions / Studio / docs.

---

## Build / Front End Primitives

### B-Fe-1 `/v2/developers/build/frontend/react-player` — REWRITE (from v2 Build frontend)

```yaml
---
title: "Using @livepeer/react Player"
sidebarTitle: "React Player"
description: "Embedding the Livepeer Player primitive in a React app against any HLS or WebRTC source — self-hosted, community, or hosted."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["E", "D"]
journeyPosition: 4
activationMoment: "Reader has a React Player rendering a live or VOD stream from their chosen source."
---
```

**Rewrite guidance**
- `@livepeer/react` Player accepts `src` array directly — gateway-agnostic.
- Show direct HLS example first. Show `getSrc(...)` Studio helper as
  secondary convenience pattern.
- Show WebRTC example.
- `@livepeer/react` v4.3.6, last published ~5 months ago.
- HTML5 component without React: `livepeer/ui-kit#15` open.

---

### B-Fe-2 `/v2/developers/build/frontend/react-broadcast` — REWRITE (from v2 Build frontend)

```yaml
---
title: "Using @livepeer/react Broadcast"
sidebarTitle: "React Broadcast"
description: "Capturing and broadcasting video from a React app to any RTMP or WebRTC ingest endpoint."
pageType: "how-to"
primaryPersona: "A"
secondaryPersonas: ["E"]
journeyPosition: 4
activationMoment: "Reader has a Broadcast component capturing camera and mic sending to their chosen ingest endpoint."
---
```

**Information to convey**
- `<Broadcast.Root ingestUrl={...}>` gateway-agnostic.
- Composition: `Broadcast.Container`, `.Video`, `.Controls`,
  `.EnabledIndicator`, `.StatusIndicator`.
- `getIngest()` Studio helper as optional.
- Mar 2025 release (`@livepeer/core-web@5.1.0`, PR #596) added mirrored
  broadcast + peer connection error callback.
- `@livepeer/react-native` deprecated; path is `react-native-video` +
  `react-native-webrtc`.

---

### B-Fe-3 `/v2/developers/build/frontend/core-web` — NEW

```yaml
---
title: "Using @livepeer/core-web"
sidebarTitle: "core-web"
description: "Framework-agnostic browser bindings for HLS, WebRTC, and metrics collection. For Svelte, Vue, vanilla JS, or custom frameworks."
pageType: "reference"
primaryPersona: "A"
secondaryPersonas: ["E"]
journeyPosition: 4
activationMoment: "Reader has core-web wired into a non-React frontend with playback and metrics."
---
```

**Information to convey**
- `@livepeer/core-web@5.1.0` (Mar 2025). Underpins `@livepeer/react`.
- HLS controller (wraps hls.js with Livepeer recovery).
- WebRTC controller.
- Metrics beacon (gateway-agnostic; defaults to Livepeer endpoint).
- `createControllerStore` pattern.

---

### B-Fe-4 `/v2/developers/build/frontend/creative-kit-ui` — NEW

```yaml
---
title: "Creative-kit UI primitives"
sidebarTitle: "Creative-kit UI"
description: "Canvas, command-bar, and node-graph primitives from @livepeer/creative-kit for agent-driven creative apps."
pageType: "how-to"
primaryPersona: "E"
secondaryPersonas: []
journeyPosition: 5
activationMoment: "Reader can instantiate ArtifactStore, InfiniteBoard, ChatPanel in their own app."
---
```

**Information to convey**
- Workspace package inside `livepeer/storyboard/packages/creative-kit`.
- Core stores: `ArtifactStore`, `ProjectPipeline`.
- Routing: `CommandRouter`, `CapabilityResolver`, `IntentClassifier`.
- UI: `InfiniteBoard`, `ChatPanel`, `ArtifactCard`.
- Publication state: not on npm yet. Vendor the workspace package.

---

## Build / Beta Platforms

### B-Bp-1 `/v2/developers/build/beta/daydream-platform` — NEW

```yaml
---
title: "Daydream (beta)"
sidebarTitle: "Daydream"
description: "Livepeer Inc's creative real-time video platform, open-sourced into Livepeer Foundation. Real-time generative pipelines with StreamDiffusion."
pageType: "concept"
primaryPersona: "C"
secondaryPersonas: ["B2", "E"]
journeyPosition: 4
activationMoment: "Reader can point at Daydream and decide whether to consume its API or fork the open-source stack."
---
```

**Information to convey** — Daydream's role in the ecosystem, API surface for
developers, open-source fork point for those building their own platform.

---

### B-Bp-2 `/v2/developers/build/beta/streamplace-platform` — NEW

```yaml
---
title: "Streamplace (beta)"
sidebarTitle: "Streamplace"
description: "The video layer for AT Protocol decentralised social. Open-source, self-hostable, built on Catalyst."
pageType: "concept"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 4
activationMoment: "Reader decides whether Streamplace fits their social app and has the repo to clone."
---
```

**Information to convey** — Streamplace (stream.place) as canonical Catalyst
deployment; AT Protocol integration; self-host path.

---

### B-Bp-3 `/v2/developers/build/beta/frameworks-platform` — NEW

```yaml
---
title: "Frameworks (beta)"
sidebarTitle: "Frameworks"
description: "Open streaming stack for live video: full media pipeline from ingest to delivery, self-hosted or cloud."
pageType: "concept"
primaryPersona: "E"
secondaryPersonas: ["B1"]
journeyPosition: 4
activationMoment: "Reader decides whether Frameworks fits their streaming stack and has the entry points."
---
```

**Information to convey** — Frameworks (`frameworks.network`) as the open
streaming stack; where it fits relative to Catalyst and Streamplace.

---

## Build / Tutorials

Per user spec, these four pages. The directory names keep existing paths where the
tutorials already live, so no content redirection is needed.

### B-Tu-1 `/v2/developers/guides/tutorials/build-an-ai-agent-on-livepeer` — RETAINED

```yaml
---
title: "Build an AI agent on Livepeer"
sidebarTitle: "AI agent tutorial"
description: "End-to-end walkthrough: Eliza plugin + Livepeer LLM gateway + tool calling. From zero to a deployable agent."
pageType: "tutorial"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader has a working agent responding to prompts with Livepeer-routed LLM responses."
---
```

---

### B-Tu-2 `/v2/developers/guides/tutorials/ipfs-video-integration` — MOVED from v2 Solutions/Studio (retained in docs-v2-dev)

```yaml
---
title: "IPFS video integration"
sidebarTitle: "IPFS + video"
description: "Pin playback assets to IPFS via Storacha or similar and serve from Livepeer playback."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["E"]
journeyPosition: 5
activationMoment: "Reader has an HLS stream backed by IPFS-pinned segments."
---
```

---

### B-Tu-3 `/v2/developers/guides/tutorials/token-gated-video` — MOVED from v2 Solutions/Studio (retained in docs-v2-dev)

```yaml
---
title: "Token-gated video"
sidebarTitle: "Token-gated video"
description: "Gate playback by on-chain ownership: ERC-20, ERC-721, ERC-1155, Unlock Protocol, Lit Protocol. Gateway-agnostic pattern."
pageType: "tutorial"
primaryPersona: "E"
secondaryPersonas: ["A"]
journeyPosition: 5
activationMoment: "Reader has a playback URL that only serves to holders of a specified token."
---
```

---

### B-Tu-4 `/v2/developers/get-started/comfystream-quickstart` — RETAINED (per user spec path)

```yaml
---
title: "ComfyStream quickstart"
sidebarTitle: "ComfyStream quickstart"
description: "Run a ComfyStream pipeline locally, iterate on a workflow, connect to a Livepeer orchestrator."
pageType: "tutorial"
primaryPersona: "B2"
secondaryPersonas: ["C"]
journeyPosition: 3
activationMoment: "Reader has ComfyStream running a real-time pipeline against a gateway."
---
```

**Path note** — user's spec shows this tutorial staying at its existing
`get-started/comfystream-quickstart` URL and being surfaced inside Build /
Tutorials via the nav `pages` array only. Keep the file in place; update
`docs.json` to reference it from the Tutorials group.

---

## Section 3 — Guides (trimmed)

The v2 Guides section is mostly emptied by moves into Build. The following pages
remain in Guides because they are cross-cutting how-tos that sit outside any Build
subgroup.

### G-1 `/v2/developers/guides/identity/signing-keys` — RETAINED

```yaml
---
title: "Managing signing keys"
sidebarTitle: "Signing keys"
description: "Key types across go-livepeer nodes, app signers, orchestrator operators. Storage, rotation, custody patterns."
pageType: "how-to"
primaryPersona: "D"
secondaryPersonas: ["E"]
journeyPosition: 5
activationMoment: "Reader has a key-management plan covering their app, gateway, and any orchestrator or signer they operate."
---
```

**Information to convey** — per the verified details captured in v2 Part 3:
go-livepeer node keys, orchestrator operator keys, Python gateway remote
signing, HSM/vault options, OrchestratorSiphon.

---

### G-2 `/v2/developers/guides/identity/identity-overview` — RETAINED

```yaml
---
title: "Identity on Livepeer at a glance"
sidebarTitle: "Identity overview"
description: "Where identity lives in each layer: node keys, operator addresses, app auth tokens, OIDC for multi-tenant gateways. One diagram and a routing table."
pageType: "concept"
primaryPersona: "E"
secondaryPersonas: ["A", "D"]
journeyPosition: 4
activationMoment: "Reader knows which identity layer applies to each of their components."
---
```

**Information to convey** — one table: layer, identity type, example. Links out to
signing-keys and Build / Applications / custody-and-signing.

---

## Section 4 — Reference (unchanged from v2)

The Reference section keeps the v2 structure:

- Reference / APIs: AI Gateway, trickle, BYOC, go-livepeer HTTP.
- Reference / SDKs: `@livepeer/ai`, `livepeer-ai-python`, `livepeer-ai-go`,
  `@livepeer/react` (ui-kit), `@muxionlabs/byoc-sdk`.
- Reference / Protocol: contracts (link out to canonical
  `/v2/about/resources/reference/livepeer-contract-addresses`), subgraph-schema,
  LIPs, Arbitrum-bridge.
- Reference / Ecosystem: community tools — ad-astra-video, Stronk-Tech,
  MuxionLabs, Titan-Node, eliteprox, Cloud SPE, LiveInfra SPE, GWID SPE,
  GovWorks SPE.

Page detail for each carries over from the v2 Part 4 document. Content
resolutions for each ecosystem entry (specific repos, creators, forum threads)
already documented.

Key IA rule: Reference / Protocol / contracts **links** to
`/v2/about/resources/reference/livepeer-contract-addresses`, does not duplicate
addresses, because that page is auto-updated daily by
`update-contract-addresses.yml` GitHub Action with on-chain verification.

---

## Section 5 — Contributing (unchanged from v2)

The Contributing section keeps the v2 structure:

- Contributing / overview, how-to-help, grants and SPEs, per-repo guides.

Per-repo guides cover: go-livepeer, ai-worker (folds to ai-runner), protocol,
comfystream, ui-kit, subgraph + Explorer, livepeer-data, docs, Livepeer-in-a-Box
contributor flow.

Information resolutions for each per-repo page already documented (maintainers,
issue labels, PR conventions, testing, Docker build patterns).

SPE path and Community Developer Contract pages: forum threads on Embody/WEAVE,
FrameWorks, GovWorks, Cloud, Agent, Protocol R&D, LiveInfra, GWID SPEs; the
pre-proposal template; treasury progression via the Governor at
`0xD9dEd6f9959176F0A04dcf88a0d2306178A736a6`.

---

## Page-count summary

| Section | Pages | Per user spec |
|---|---|---|
| Concepts | 4 | Max 4 ✓ |
| Get Started | 4 | Max 4 ✓ |
| Build / Video | 7 | Depth |
| Build / AI | 11 | Depth |
| Build / Agents | 4 | Depth |
| Build / Applications | 8 | Depth |
| Build / Protocol & Local Development | 9 | Depth |
| Build / Front End Primitives | 4 | Depth |
| Build / Beta Platforms | 3 | Depth |
| Build / Tutorials | 4 | Exactly four, per spec |
| Guides | 2 | Trimmed |
| Reference | As v2 | Unchanged |
| Contributing | As v2 | Unchanged |
| **Total Build** | **50** | |

Concepts and Get Started are the overview layer (8 pages combined). Build carries
50 pages of depth. Guides holds two residual cross-cutting pages. Reference and
Contributing are unchanged from v2.

---

## End of Part 3
