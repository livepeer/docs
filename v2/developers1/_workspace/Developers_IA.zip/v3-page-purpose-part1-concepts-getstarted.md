# Developers tab v3 — page-purpose document (Part 1 of 3)

## Concepts and Get Started

This document supersedes v2-page-purpose-part1.md / part2.md / part3.md / part4.md.
The v3 restructure reduces Concepts to four pages, Get Started to four pages, and moves
nearly all v2 Concepts depth into the Build section.

Canonical branch: `docs-v2-dev`. Path prefix: `/v2/developers/`. UK English; JSX comments
only in MDX; no em dashes; no questions in body copy; entity-led voice.

---

## Section 1 — Concepts (4 pages, hard cap)

Concepts is the overview section that leads to detail. It is not a thesis. The four
pages give a reader:

1. the full developer landscape and every way to participate
2. the mental model of the developer stack
3. the architecture diagrams and layouts
4. a single overview of tooling and observability integrations

Any concept that needs more than a few paragraphs moves to Build.

---

### 1.1 `/v2/developers/concepts/overview` — RETAINED

```yaml
---
title: "Developer landscape on Livepeer"
sidebarTitle: "Overview"
description: "Every way a developer can participate in the Livepeer network: build a video app, call AI inference, ship a realtime pipeline, author a BYOC container, run a gateway, contribute to core OSS."
pageType: "concept"
primaryPersona: "A"
secondaryPersonas: ["B1", "B2", "C", "D", "E", "F"]
journeyPosition: 1
activationMoment: "Reader recognises which developer path matches their goal and knows the next page to read."
---
```

**Audience** — every developer persona on first arrival: Rapid Integrator (A), Gateway
Runner (B1), ComfyStream Developer (B2), ComfyStream Creative (C), OSS Core Builder (D),
Platform/Agent Builder (E), Observability Integrator (F).

**Journey** — entry page for the whole tab; out to one of the four Get Started quickstarts.

**Information to convey**
- The six developer entry points: build a video app, call AI inference, ship a custom
  AI pipeline, build an agent, run your own infrastructure, contribute to core OSS.
- The four Get Started tracks (Video, AI, Agents, Self-host) each map to one of those
  entry points.
- The network has three sides relevant to developers: demand (gateways and apps),
  supply (orchestrators and transcoders), and protocol (contracts, subgraph, treasury).
- Solution products (Daydream, Studio, Streamplace, Frameworks) sit one layer above
  Developers; if the reader's goal is met by a solution product, they should read
  Solutions first.
- A small landscape diagram: demand → protocol → supply, with the developer's
  entry points annotated along the top.

**Retention notes**
- The existing `/v2/developers/concepts/overview.mdx` already covers much of this;
  only refactor to align with the four Get Started tracks below and to route out to
  the three new Concepts pages.

---

### 1.2 `/v2/developers/concepts/mental-model` — NEW (supersedes oss-stack)

```yaml
---
title: "Mental model of the Livepeer developer stack"
sidebarTitle: "Mental model"
description: "The developer stack in layers: applications on top, SDKs and gateways in the middle, go-livepeer and lpms below, protocol contracts at the base. Every other page in this tab slots into one of these layers."
pageType: "concept"
primaryPersona: "D"
secondaryPersonas: ["E", "A"]
journeyPosition: 1
activationMoment: "Reader can name the layer their work lives in and predict which sibling layers they will touch."
---
```

**Audience** — developers who want to hold the full stack in their head before
committing to a path.

**Journey** — from Concepts overview; out to Concepts architecture for the concrete
component layout, or directly to a Build subgroup once they have located their layer.

**Information to convey**
- Layer 1 (apps): frontends and backend services consuming Livepeer through SDKs.
- Layer 2 (SDKs and gateways): `@livepeer/ai`, `livepeer-ai-python`, `livepeer-ai-go`,
  the `@livepeer/react` ui-kit, `@muxionlabs/byoc-sdk`, and any self-hosted or
  managed gateway that exposes the HTTP surface.
- Layer 3 (go-livepeer): orchestrator, transcoder, and gateway binaries in one Go
  codebase. Handles discovery, ticket settlement, job routing, and the LV2V and
  BYOC execution paths.
- Layer 4 (media engine): `lpms` and `ai-runner` (same repo as `ai-worker`,
  `runner/` subdirectory). CGO-bound ffmpeg for transcoding; Python FastAPI for AI.
- Layer 5 (protocol): contracts on Arbitrum One implementing BondingManager,
  TicketBroker, RoundsManager, Minter, Governor, BondingVotes. L1 LPT on Ethereum.
- Layer 6 (data): `livepeer/subgraph` on The Graph, `livepeer-data` for stream
  health and metrics, `livepeer-monitoring`, NaaP Analytics from Cloud SPE.
- One diagram stacking the six layers, with the canonical repo name next to each
  layer and arrows showing which layers a developer typically touches per Get
  Started track.
- Closing paragraph: every subsequent page in the Developers tab sits in exactly one
  of these layers; the sidebar groups roughly match the layers.

**Deprecation note** — v2 `concepts/oss-stack` is superseded by this page. Redirect
`/v2/developers/concepts/oss-stack` → `/v2/developers/concepts/mental-model`.

---

### 1.3 `/v2/developers/concepts/architecture` — NEW

```yaml
---
title: "Livepeer architecture diagrams"
sidebarTitle: "Architecture"
description: "The concrete component layouts a developer encounters: an app calling a gateway, a realtime LV2V pipeline, a BYOC container on an orchestrator, and a self-hosted stack. One diagram per layout, each with its own detail page."
pageType: "concept"
primaryPersona: "E"
secondaryPersonas: ["D", "B1", "A"]
journeyPosition: 1
activationMoment: "Reader can point at the diagram that matches what they are building and follow the link to the right Build page."
---
```

**Audience** — developers who think in diagrams before prose. Platform/Agent Builders
and OSS Core Builders benefit most.

**Journey** — from Concepts overview or mental-model; out to specific Build subgroups.

**Information to convey**
- **Layout A — "App on managed gateway"**: app → `@livepeer/ai` SDK → Livepeer Cloud
  Community Gateway (or Daydream, Studio, GWID) → orchestrator pool. The happy-path
  layout for Rapid Integrators.
- **Layout B — "Realtime LV2V"**: app → gateway `/live-video-to-video` → orchestrator
  running a pytrickle FrameProcessor → trickle in/out → rendered back to app. Covers
  the path a ComfyStream Developer sees.
- **Layout C — "BYOC container"**: app → gateway `/byoc/*` → orchestrator with a
  developer-authored container loaded via pytrickle → any author-defined output.
  Shows where the developer's code lives on the network.
- **Layout D — "Self-hosted gateway"**: app → local go-livepeer gateway
  (`-gateway` mode) → orchestrator discovery via `-orchWebhookUrl` or `-orchAddr` →
  orchestrator pool. The graduation layout.
- **Layout E — "Contribute to core"**: developer → fork of go-livepeer or lpms or
  livepeer/protocol → private testnet via Livepeer-in-a-Box → PR upstream. The
  contributor layout.
- Each layout gets one small SVG diagram and a one-sentence callout pointing to the
  Build subgroup that covers it in depth.
- No prose thesis. Five layouts, five diagrams, five links out.

**Information to exclude**
- Ticket-level mechanics, trickle wire format, payment-mode detail, discovery
  protocol detail. All of that lives under Build/Protocol & Local Development.
- BYOC engineering spec detail. Lives under Build/AI.

---

### 1.4 `/v2/developers/concepts/integrations` — NEW

```yaml
---
title: "Data and tooling integrations at a glance"
sidebarTitle: "Integrations"
description: "The shape of data sources, observability endpoints, tooling repos, and ecosystem surfaces developers can hook into. One page that catalogues the landscape and routes to each integration's own page."
pageType: "concept"
primaryPersona: "F"
secondaryPersonas: ["E", "D"]
journeyPosition: 1
activationMoment: "Reader knows which data surface to query for their question and which Reference or Build page to open next."
---
```

**Audience** — Observability Integrators, Platform/Agent Builders wiring up data
feeds, and developers evaluating what is available before committing.

**Journey** — from Concepts overview; out to Build Applications
data-and-observability, Build Applications prometheus-scrape, Reference protocol
subgraph-schema, and Reference ecosystem community listings.

**Information to convey**
- **Network data**: the subgraph on The Graph (arbitrum-one), with a one-line
  description. Points to Reference protocol subgraph-schema.
- **Stream and AI data**: `livepeer/livepeer-data` (Go repo) with ai, api, health,
  metrics, prometheus, stats, usage, and views packages. Points to Build
  Applications data-and-observability.
- **MCP surface**: `livepeer/livepeer-data-mcp` gated by Cloudflare Access.
- **Network-level SLA data**: NaaP Analytics from Cloud SPE — free, open source,
  aggregated from reference load-test gateways. Links to livepeer.cloud.
- **AI performance leaderboard**: integrated into Livepeer Explorer
  (`NEXT_PUBLIC_METRICS_SERVER_URL` and `NEXT_PUBLIC_AI_METRICS_SERVER_URL`).
- **Prometheus scrape points**: go-livepeer on ports 7935 (orchestrator) and 7936
  (gateway), plus ai-runner and catalyst-api endpoints. Points to Build Applications
  prometheus-scrape.
- **Community exporters**: `transcodeninja/livepeer-exporter` and Stronk-Tech org
  repos. Points to Reference ecosystem community.
- **Ecosystem tooling**: stronk.rocks, Livepeer.Tools payout tracker, rickstaa Dune
  dashboards.
- A simple table with five columns: surface name, what it exposes, endpoint or
  repo, owner, link.

**Information to exclude**
- Full configuration detail for any individual exporter or dashboard. Each page in
  Build Applications or Reference ecosystem owns its own depth.

---

## Section 2 — Get Started (4 pages, hard cap)

Get Started is one page per buildable thing. Every page ends with a link to its Build
subgroup. The track structure is:

| Page | Buildable thing | Build subgroup |
|---|---|---|
| setup-paths | n/a — routing page | — |
| video-on-livepeer | Video apps | Build / Video |
| ai-on-livepeer | AI apps | Build / AI |
| agents-on-livepeer | Agents | Build / Agents |

Video quickstart moves to Studio. Already-on-Daydream-or-Studio is cut — that content
belongs on Solutions pages. Rapid-integrator is cut — the rapid integrator persona
reads setup-paths and then one of the three track pages. Self-host-quickstart and
contributor-quickstart both move to Build / Protocol & Local Development because they
are deeper setup flows that belong alongside the rest of the local-dev tooling.
Custom AI pipelines (byoc-quickstart) moves to Build / AI, and realtime-quickstart
moves to Build / AI, because those are production pipeline flows, not introductions.
Transcoding-quickstart moves to Build / Video for the same reason. ComfyStream
quickstart lives in Build / Tutorials, per spec.

---

### 2.1 `/v2/developers/get-started/setup-paths` — RETAINED

```yaml
---
title: "Choose your setup path"
sidebarTitle: "Setup paths"
description: "A two-question decision tree that routes you to the right Get Started track: Video, AI, or Agents. Plus setup basics for each."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["B1", "B2", "E"]
journeyPosition: 2
activationMoment: "Reader has picked one of the three track pages and has the minimum prerequisites installed."
---
```

**Audience** — any developer arriving at Get Started who has not yet chosen a track.

**Journey** — from Concepts overview; out to one of the three track pages below.

**Information to convey**
- Two questions: "what do you want to build?" (video app / AI app / agent) and
  "where will it run?" (hosted / self-hosted). The answers produce a track.
- Each track has its own prerequisites (Node.js, Python, Docker, wallet, RPC).
- Link to each track page at the end.
- Short note on what's not here: video quickstart lives in Studio docs; custom AI
  pipelines, realtime pipelines, and self-hosting live in Build.

**Retention notes** — existing `get-started/setup-paths.mdx` already covers
prerequisites well; rewrite the routing section to produce three tracks instead of
the current broader list.

---

### 2.2 `/v2/developers/get-started/video-on-livepeer` — MOVED from v2 Concepts, REWRITE

```yaml
---
title: "Build video on Livepeer"
sidebarTitle: "Video on Livepeer"
description: "The Video track: what you can build (live, VOD, recording, playback), which gateway hosts the inference, and the one-page path to your first playable stream against any gateway."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["B1", "E"]
journeyPosition: 2
activationMoment: "Reader has a working playback URL from any gateway (self-hosted, Community, Studio, Daydream) rendered in a `@livepeer/react` Player."
---
```

**Audience** — developers who want to ship a video app and have not decided between
hosted and self-hosted ingest.

**Journey** — from setup-paths; out to Build / Video ingest-and-playback and
Build / Front End Primitives react-player.

**Rewrite guidance**
- This page exists in v2 Concepts as a long explainer. In v3 it is a quickstart
  with conceptual framing kept to a single opening paragraph.
- Frame the three video workloads (live, VOD, recording) in one paragraph each.
- Point at the gateway choice: Livepeer Cloud Community Gateway at
  `gateway.livepeer.cloud`, Studio, Daydream, self-hosted go-livepeer `-gateway`.
- Show a minimal playback snippet with `@livepeer/react` Player taking a raw HLS URL
  so it works against any gateway, not just Studio.
- Show a minimal ingest snippet with `@livepeer/react` Broadcast taking a raw RTMP
  ingest URL.
- End with links to Build / Video / ingest-and-playback, Build / Video / codec-support,
  and Build / Front End Primitives / react-player.

**Information to convey**
- Three video workloads in one line each.
- One playback snippet.
- One ingest snippet.
- Gateway choice as a short table (Community / Studio / Daydream / Self-hosted).
- Three out-links.

**Information to exclude**
- Transcoding profile design: lives in Build / Video / gpu-transcoding and
  codec-support.
- Storage and archival: Build / Video / storage-and-archival.
- Studio-bound features (Access Control JWT, signing keys scoped to Studio keys,
  webhook catalogue): Solutions / Studio / docs.

---

### 2.3 `/v2/developers/get-started/ai-on-livepeer` — MOVED from v2 Concepts, REWRITE

```yaml
---
title: "Build AI on Livepeer"
sidebarTitle: "AI on Livepeer"
description: "The AI track: what you can call today (text-to-image, image-to-image, image-to-video, LLM, TTS/STT, realtime LV2V, BYOC), which SDKs and gateways are gateway-agnostic, and the one-page path to your first AI call."
pageType: "tutorial"
primaryPersona: "A"
secondaryPersonas: ["B2", "E"]
journeyPosition: 2
activationMoment: "Reader has made their first successful AI Gateway call using `@livepeer/ai` against any gateway."
---
```

**Audience** — developers who want to call Livepeer AI from an app.

**Journey** — from setup-paths; out to Build / AI / ai-quickstart for the deeper flow,
Build / AI / ai-pipelines for the model catalogue, and Build / AI / byoc-architecture
if they want to ship their own pipeline.

**Rewrite guidance**
- Single-page primer that introduces the AI Gateway API surface and the two paths
  into it: batch (text-to-image, upscale, audio-to-text, LLM) and realtime
  (live-video-to-video, BYOC streaming).
- Install and first call using `@livepeer/ai` against the Community Gateway.
- Gateway-agnostic pattern: constructor takes `httpBearer` plus a base URL; works
  against any gateway.
- Brief mention of BYOC and ComfyStream as follow-on paths with links out.
- Frame the distinction clearly: `@livepeer/ai` is the AI Gateway SDK; the `livepeer`
  npm package is the Studio API SDK. These are different SDKs.

**Information to convey**
- AI Gateway API surface in a short table: endpoint, purpose, SDK method.
- One code snippet: `new Livepeer({ httpBearer, baseURL })` calling
  `generate.textToImage`.
- Gateway choices: Community, Studio, Daydream, GWID, self-hosted.
- Three out-links: ai-quickstart (deeper), ai-pipelines (model catalogue),
  byoc-architecture (author your own pipeline).

**Information to exclude**
- Full model catalogue: Build / AI / ai-pipelines.
- ComfyStream workflow authoring: Build / AI / comfystream-authoring.
- BYOC engineering spec: Build / AI / byoc-architecture.

---

### 2.4 `/v2/developers/get-started/agents-on-livepeer` — MOVED from v2 Concepts, REWRITE

```yaml
---
title: "Build agents on Livepeer"
sidebarTitle: "Agents on Livepeer"
description: "The Agents track: what an agent on Livepeer looks like, how Storyboard composes @livepeer/agent and @livepeer/creative-kit, and the minimum setup to ship an LLM-driven video or creative agent."
pageType: "tutorial"
primaryPersona: "E"
secondaryPersonas: ["A", "B2"]
journeyPosition: 2
activationMoment: "Reader has a working agent loop calling at least one Livepeer capability (LLM or AI inference) and knows which Build pages to open next."
---
```

**Audience** — Platform/Agent Builders shipping an agent-driven app.

**Journey** — from setup-paths; out to Build / Agents / agent-quickstart for deeper
flow, Build / Agents / agent-sdk for the SDK surface, Build / Agents / reference-agents
for Titan-Node templates, and Build / Tutorials / build-an-ai-agent-on-livepeer for the
end-to-end walkthrough.

**Rewrite guidance**
- Existing v2 Concepts page is too long. Compress to one page.
- Name the three agent building blocks as they exist today: `@livepeer/agent`
  (AgentRunner, ToolRegistry, WorkingMemory; workspace package inside
  `livepeer/storyboard`), `@livepeer/creative-kit` (ArtifactStore, ChatPanel,
  InfiniteBoard; workspace package inside the same repo), and reference templates
  from Titan-Node (`livepeer-8004-agent`, `livepeer-402-middleware`).
- State clearly: `@livepeer/agent` and `@livepeer/creative-kit` are not published to
  npm as of April 2026. To use them today, clone `livepeer/storyboard` and vendor
  the workspace packages, or build on Storyboard directly.
- Describe the four provider options: Gemini (default, `GEMINI_API_KEY`), Claude
  (`ANTHROPIC_API_KEY`), OpenAI (`OPENAI_API_KEY`), Livepeer (`DAYDREAM_API_KEY`,
  routes all LLM calls through `sdk.daydream.monster`).
- Name the EIP-8004 direction via Titan-Node's `livepeer-8004-agent` template for
  developers building a payable agent on decentralised GPU infrastructure.

**Information to convey**
- Three agent paths: Storyboard-derived (vendor the workspace packages),
  Eliza plugin (see Build / Agents / eliza-integration), from-scratch on top of
  `@livepeer/ai` directly.
- One code skeleton: an AgentRunner loop with a single tool calling
  `livepeer.generate.textToImage`.
- Out-links: agent-quickstart, agent-sdk, reference-agents,
  Build / Tutorials / build-an-ai-agent-on-livepeer.

**Information to exclude**
- Storyboard feature catalogue: lives in Build / Beta Platforms / daydream-platform
  cross-links and the Storyboard repo README.
- Full tool-registry API: Build / Agents / agent-sdk.

---

## Get Started pages removed or relocated

The following v2 Get Started pages are cut or moved in v3:

| Page | v3 destination |
|---|---|
| `rapid-integrator` | **CUT**. Rapid integrators read setup-paths → video/ai/agents track. |
| `already-on-daydream-or-studio` | **CUT** from Developers. Content belongs on Solutions pages. |
| `video-quickstart` | Already moved to Studio in v2; stays in Solutions/Studio/docs. |
| `ai-quickstart` | **MOVED** to Build / AI / ai-quickstart (deeper-than-intro flow). |
| `transcoding-quickstart` | **MOVED** to Build / Video / transcoding-quickstart. |
| `comfystream-quickstart` | **MOVED** to Build / Tutorials / comfystream-quickstart (per user spec). |
| `realtime-quickstart` | **MOVED** to Build / AI / realtime-quickstart. |
| `byoc-quickstart` | **MOVED** to Build / AI / byoc-quickstart (custom AI pipelines). |
| `agent-quickstart` | **MOVED** to Build / Agents / agent-quickstart. |
| `self-host-quickstart` | **MOVED** to Build / Protocol & Local Development. |
| `contributor-quickstart` | **MOVED** to Build / Protocol & Local Development. |

Redirects required on the docs-v2-dev branch for every moved page.

---

## End of Part 1
