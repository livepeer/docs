# V3 IA — Page placement decisions

## Concepts (4 pages max)
1. overview (retained) — full developer landscape + all ways to participate
2. mental-model (new, renamed from oss-stack) — mental model of the developer stack
3. architecture (new) — architecture diagrams + layouts
4. integrations (new) — data, tooling, observability shape at a glance

## Get Started (4 pages max)
1. setup-paths (retained)
2. video-on-livepeer (moved from v2 Concepts) — the "Video" path
3. ai-on-livepeer (moved from v2 Concepts) — the "AI" path
4. agents-on-livepeer (moved from v2 Concepts) — the "Agents" path

(contributor-quickstart, already-on-daydream-or-studio, rapid-integrator get cut or folded — see notes)
(custom AI pipelines = byoc-quickstart moves into Build/AI)
(self-host / running livepeer locally moves into Build/Protocol & Local Development)

## Build (8 subgroups)
### Video
- ingest-and-playback
- gpu-transcoding
- codec-support
- transcoding-quickstart (from v2 Get Started)
- storage-and-archival (from v2 Guides)
- live-events (from v2 Guides)
- vod-workflows (from v2 Guides)

### AI
- ai-quickstart (from v2 Get Started)
- ai-orchestration
- realtime-quickstart (from v2 Get Started)
- byoc-architecture (from v2 Concepts, moved)
- byoc-quickstart (from v2 Get Started)
- byoc-production
- comfystream-platform
- comfystream-pipeline-authoring
- comfyui-stream-pack
- pytrickle
- ai-pipelines

### Agents
- agent-quickstart (from v2 Get Started)
- agent-sdk
- reference-agents
- eliza-integration

### Applications
- running-a-gateway (retained from v2 Concepts, moved)
- local-gateway
- custody-and-signing (from v2 Concepts, moved)
- pymthouse-and-oidc (from v2 Guides)
- gateway-for-app-developers
- data-and-observability (from v2 Concepts, moved)
- settlement-observability
- prometheus-scrape

### Protocol & Local Development
- trickle-protocol (from v2 Concepts, moved)
- payment-modes (from v2 Concepts, moved)
- off-chain-discovery (from v2 Concepts, moved)
- python-gateway
- lpms-integration
- self-host-quickstart (from v2 Get Started)
- livepeer-in-a-box (from v2 Guides)
- contributor-quickstart (from v2 Get Started)
- recurring-jobs (from v2 Guides)

### Front End Primitives
- react-player (from v2 Build frontend)
- react-broadcast (from v2 Build frontend)
- core-web (from v2 Build frontend)
- creative-kit-ui (from v2 Build frontend)

### Beta Platforms
- daydream-platform
- streamplace-platform
- frameworks-platform

### Tutorials (per user spec)
- build-an-ai-agent-on-livepeer
- ipfs-video-integration
- token-gated-video
- comfystream-quickstart (from v2 Get Started — doubles up, acts as tutorial entry)

## Guides (trimmed — v2 Guides content mostly moved into Build)
- Remaining: high-level how-tos that don't fit a Build subgroup
- signing-keys (from v2 Guides)
- identity (from v2 Guides remnant)

## Reference (unchanged from v2)
- Same as v2

## Contributing (unchanged from v2)
- Same as v2

## Pages explicitly cut (superseded or redundant in v3)
- oss-stack — folded into Concepts/mental-model
- rapid-integrator (Get Started) — rapid integrators use setup-paths directly
- already-on-daydream-or-studio — content belongs on Solutions pages, not Developers
- video-quickstart — already cut to Studio
