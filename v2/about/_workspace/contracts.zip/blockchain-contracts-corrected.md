---
title: Blockchain Contracts
sidebarTitle: Blockchain Contracts
description: An overview of the Livepeer protocol blockchain contracts.
keywords:
  - livepeer
  - about
  - livepeer protocol
  - blockchain contracts
  - blockchain
  - contracts
  - overview
  - protocol
'og:image': /snippets/assets/site/og-image/fallback.png
'og:image:alt': Livepeer Docs social preview image
'og:image:type': image/png
'og:image:width': 1200
'og:image:height': 630
audience: general
purpose: concept
lastVerified: 2026-03-18
---

import { Image } from '/snippets/components/primitives/image.jsx'
import { CustomDivider } from '/snippets/components/primitives/divider.jsx'
import { LinkArrow } from '/snippets/components/primitives/links.jsx'
import { Subtitle, CopyText } from '/snippets/components/primitives/text.jsx'

# Livepeer Blockchain Contracts

Livepeer uses a comprehensive system of Ethereum smart contracts to permissionlessly govern its decentralised network.

The Livepeer Protocol is deployed on Arbitrum One and uses these contracts to govern:

- LivepeerToken (LPT) ownership and delegation
- Staking and selection of active orchestrators
- Distribution of inflationary rewards and fees to participants
- Time-based progression of the protocol through rounds
- Payment processing through a probabilistic micropayment system

There are three categories of contracts in the Livepeer Protocol:

1. **Core Protocol Contracts** — staking, payments, round progression, and service discovery
2. **Token and Utility Contracts** — the LPT token and bridge infrastructure
3. **Governance Contracts** — on-chain voting, proposal execution, and treasury management

These consist of **13 active contracts** on Arbitrum One, plus legacy bridge contracts on Ethereum Mainnet.

## Contract Interaction Architecture

```mermaid
graph TB
    subgraph "Registry"
        Controller["Controller\nContract Registry"]
    end

    subgraph "Discovery"
        ServiceRegistry["ServiceRegistry\nOrchestrator URI Mapping"]
        AIServiceRegistry["AIServiceRegistry\nAI Capability Registration"]
    end

    subgraph "Economic"
        LPT["LivepeerToken\nERC-20"]
        BondingManager["BondingManager\nStaking & Rewards"]
        TicketBroker["TicketBroker\nMicropayments"]
        Minter["Minter\nToken Inflation"]
    end

    subgraph "Time"
        RoundsManager["RoundsManager\nProtocol Rounds"]
    end

    subgraph "Governance"
        BondingVotes["BondingVotes\nStake Checkpointing"]
        Governor["Governor\nUpgrade Executor"]
        LivepeerGovernor["LivepeerGovernor\nOn-chain Voting"]
        Treasury["Treasury\nProtocol Treasury"]
    end

    subgraph "Participants"
        Gateway["Gateway Node"]
        Orchestrator["Orchestrator Node"]
        Delegator["LPT Holder"]
    end

    Controller -.->|"Address Lookup"| LPT
    Controller -.->|"Address Lookup"| BondingManager
    Controller -.->|"Address Lookup"| TicketBroker
    Controller -.->|"Address Lookup"| RoundsManager
    Controller -.->|"Address Lookup"| Minter
    Controller -.->|"Address Lookup"| ServiceRegistry
    Controller -.->|"Address Lookup"| BondingVotes
    Controller -.->|"Address Lookup"| LivepeerGovernor
    Controller -.->|"Address Lookup"| Treasury

    Delegator -->|"approve() LPT"| LPT
    Delegator -->|"bond(amount, orch)"| BondingManager
    Delegator -->|"castVote()"| LivepeerGovernor
    BondingManager -->|"transferFrom()"| LPT
    BondingManager -->|"checkpointBondingState()"| BondingVotes

    Orchestrator -->|"transcoder(rewardCut, feeShare)"| BondingManager
    Orchestrator -->|"setServiceURI(url)"| ServiceRegistry
    Orchestrator -->|"reward()"| BondingManager
    BondingManager -->|"createReward()"| Minter
    Minter -->|"mint() new LPT"| LPT
    Minter -->|"mint() treasury cut"| Treasury

    Gateway -->|"fundDepositAndReserve()"| TicketBroker
    Orchestrator -->|"redeemWinningTicket()"| TicketBroker
    TicketBroker -->|"transfer() to orchestrator"| LPT

    RoundsManager -->|"currentRound()"| BondingManager
    RoundsManager -->|"blockHashForRound()"| TicketBroker

    BondingVotes -->|"getPastVotes()"| LivepeerGovernor
    LivepeerGovernor -->|"execute()"| Governor
    Governor -->|"setContractInfo()"| Controller
```

<CustomDivider />

## Core Protocol Contracts

The core protocol contracts manage staking, delegation, reward distribution, round progression, payment processing, and service discovery. The Controller serves as the central registry — upgrading a contract means registering a new implementation address in the Controller, not changing the stable proxy address.

#### **Controller**: <Subtitle text="Contract Registry" />

The Controller is the central registry for all protocol contracts. Every other contract resolves peer contract addresses from the Controller using keccak256 hashes of contract names as keys.

<Accordion title="Controller">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xD8E8328501E9645d16Cf49539efC04f734606ee4" newline={false} />
  ```
  0xD8E8328501E9645d16Cf49539efC04f734606ee4
  ```

  **Purpose**:
  - Central address registry for all protocol contracts
  - Enables contract upgrades while maintaining stable proxy addresses
  - Provides `pause()`/`unpause()` for emergency situations

  **Key functions**:
  - `getContract(bytes32 _id)` — look up a contract address by keccak256 name hash
  - `setContractInfo(bytes32 _id, address _contractAddress, bytes20 _gitCommitHash)` — register or update a contract
  - `pause()` / `unpause()` — emergency pause for the entire system
</Accordion>

#### **BondingManager**: <Subtitle text="Staking & Delegation" />

The BondingManager is the most critical economic contract. It manages the orchestrator pool as a sorted doubly-linked list, handles delegator bonding and unbonding, and distributes inflationary rewards.

<Accordion title="BondingManager">
  **Proxy Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x35Bcf3c30594191d53231E4FF333E8A770453e40" newline={false} />
  ```
  0x35Bcf3c30594191d53231E4FF333E8A770453e40
  ```

  **Target Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x4bA7E7531Ab56bC8d78dB4FDc88D21F621f34BB4" newline={false} />
  ```
  0x4bA7E7531Ab56bC8d78dB4FDc88D21F621f34BB4
  ```
  {/* Verified on-chain 18 Mar 2026 via Controller.getContract(keccak256("BondingManagerTarget")).
      Deployed 16 Feb 2026 — V11 implementation. Previous docs address 0xF62C30242... was incorrect. */}

  **Purpose**:
  - Manages the active orchestrator pool (sorted by stake)
  - Handles bonding (staking) and delegation to orchestrators
  - Distributes inflationary LPT rewards to orchestrators and delegators
  - Manages unbonding period and LPT withdrawal queue
  - Calls `checkpointBondingState()` on BondingVotes for governance weight

  **Key functions**:
  - `bond(uint256 _amount, address _to)` — delegate stake to an orchestrator
  - `unbond(uint256 _amount)` — begin withdrawal (unbonding period applies)
  - `withdrawStake(uint256 _unbondingLockId)` — complete withdrawal after unbonding period
  - `transcoder(uint256 _rewardCut, uint256 _feeShare)` — register or update orchestrator parameters
  - `reward()` — called by active orchestrators each round to mint and distribute rewards
  - `claimEarnings(uint256 _endRound)` — claim accumulated rewards and fees
</Accordion>

#### **TicketBroker**: <Subtitle text="Probabilistic Micropayments" />

The TicketBroker implements Livepeer's off-chain probabilistic micropayment system. Gateways pre-fund a deposit and reserve; orchestrators receive payment by redeeming winning lottery tickets on-chain.

<Accordion title="TicketBroker">
  **Proxy Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xa8bB618B1520E284046F3dFc448851A1Ff26e41B" newline={false} />
  ```
  0xa8bB618B1520E284046F3dFc448851A1Ff26e41B
  ```

  **Target Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xea1b0F6c8D158328a6e3D3F924B86A759F41465c" newline={false} />
  ```
  0xea1b0F6c8D158328a6e3D3F924B86A759F41465c
  ```
  {/* Verified on-chain 18 Mar 2026 via Controller.getContract(keccak256("TicketBrokerTarget")). */}

  **Purpose**:
  - Holds gateway deposits (ETH) and payment reserves
  - Validates and settles winning probabilistic payment tickets
  - Manages the unlock period before gateways can withdraw funds
  - Tracks claimed reserves per orchestrator to prevent over-redemption
  - Emits `RedeemWinningTicket` events for on-chain payment monitoring

  **Key functions**:
  - `fundDepositAndReserve(uint256 _depositAmount, uint256 _reserveAmount)` — gateway funds deposit and reserve
  - `redeemWinningTicket(Ticket calldata _ticket, bytes calldata _sig, uint256 _recipientRand)` — orchestrator redeems a winning ticket
  - `unlock()` — gateway begins withdrawal unlock period
  - `withdraw()` — gateway completes withdrawal after unlock period
  - `cancelUnlock()` — cancel an in-progress unlock
</Accordion>

#### **RoundsManager**: <Subtitle text="Protocol Time Management" />

The RoundsManager defines the protocol's block-based time unit. Each round is a fixed number of Arbitrum blocks. Round initialisation is required at the start of each round before reward calls can proceed.

<Accordion title="RoundsManager">
  **Proxy Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xdd6f56DcC28D3F5f27084381fE8Df634985cc39f" newline={false} />
  ```
  0xdd6f56DcC28D3F5f27084381fE8Df634985cc39f
  ```

  **Target Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x92d804Ed49D92438aEA6fe552BD9163aacb7E841" newline={false} />
  ```
  0x92d804Ed49D92438aEA6fe552BD9163aacb7E841
  ```
  {/* Verified on-chain 18 Mar 2026 via Controller.getContract(keccak256("RoundsManagerTarget")). */}

  **Purpose**:
  - Defines round length in blocks and tracks current round
  - Stores block hashes per round for ticket randomness
  - Enforces the round lock period (orchestrators cannot update parameters during lock)

  **Key functions**:
  - `initializeRound()` — initialise a new round (callable by any node)
  - `currentRound()` — returns the current round number
  - `blockHashForRound(uint256 _round)` — returns the block hash for a given round
</Accordion>

#### **Minter**: <Subtitle text="Token Inflation" />

The Minter controls LPT token inflation. Each round it calculates mintable tokens based on the inflation rate and target bonding rate. Since the Delta upgrade, a configurable fraction is directed to the Treasury.

<Accordion title="Minter">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xc20DE37170B45774e6CD3d2304017fc962f27252" newline={false} />
  ```
  0xc20DE37170B45774e6CD3d2304017fc962f27252
  ```
  {/* Verified on-chain 18 Mar 2026 via Controller.getContract(keccak256("Minter")). */}

  **Purpose**:
  - Manages the LPT token inflation schedule
  - Calculates mintable tokens per round
  - Adjusts inflation up or down based on actual vs target bonding rate
  - Called by BondingManager during orchestrator `reward()` calls
  - Mints a configurable fraction to the Treasury each round

  **Key functions**:
  - `createReward(uint256 _fracNum, uint256 _fracDenom)` — called by BondingManager to mint rewards
  - `currentMintableTokens()` — returns tokens mintable in the current round
  - `inflation()` — returns current inflation rate
</Accordion>

#### **ServiceRegistry**: <Subtitle text="Orchestrator Discovery" />

The ServiceRegistry stores the on-chain service URI for each orchestrator. Gateway nodes query this registry to discover orchestrator endpoints during initialisation.

<Accordion title="ServiceRegistry">
  **Proxy Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xC92d3A360b8f9e083bA64DE15d95Cf8180897431" newline={false} />
  ```
  0xC92d3A360b8f9e083bA64DE15d95Cf8180897431
  ```

  **Target Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x38093CDca43aeCd7bb474983519A246e93A3b0a7" newline={false} />
  ```
  0x38093CDca43aeCd7bb474983519A246e93A3b0a7
  ```
  {/* Both verified on-chain 18 Mar 2026 via Controller.getContract(). */}

  **Purpose**:
  - Allows orchestrators to register and update their HTTPS service endpoints
  - Enables gateway nodes to discover orchestrators via on-chain data
  - Emits `ServiceURIUpdate` events on each change

  **Key functions**:
  - `setServiceURI(string calldata _serviceURI)` — orchestrator registers or updates endpoint
  - `getServiceURI(address _addr)` — returns the registered URI for a given address
</Accordion>

#### **AIServiceRegistry**: <Subtitle text="AI Capability Registration" />

A standalone registry for orchestrators advertising AI pipeline capabilities. Detached from the Controller — address is hardcoded in go-livepeer rather than resolved through the registry.

<Accordion title="AIServiceRegistry">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x04C0b249740175999E5BF5c9ac1dA92431EF34C5" newline={false} />
  ```
  0x04C0b249740175999E5BF5c9ac1dA92431EF34C5
  ```
  {/* Verified on-chain 18 Mar 2026 via Blockscout get_address_info. Deployed by AI subnet deployer,
      not the main Livepeer Deployer. Detached from Controller — hardcoded in go-livepeer starter.go. */}

  **Purpose**:
  - Separate registry for AI subnet orchestrators
  - Stores AI capability metadata and endpoint URIs
</Accordion>

#### **MerkleSnapshot**: <Subtitle text="Staking Snapshots" />

Stores Merkle roots for snapshots of the staking state at specific rounds, used in migration and reward distribution verification.

<Accordion title="MerkleSnapshot">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x10736ffaCe687658F88a46D042631d182C7757f7" newline={false} />
  ```
  0x10736ffaCe687658F88a46D042631d182C7757f7
  ```
  {/* Verified on-chain 18 Mar 2026 via Blockscout get_address_info. */}
</Accordion>

<CustomDivider />

## Token and Utility Contracts

<Tip>
Livepeer moved from Ethereum Mainnet to Arbitrum One in 2022 (the Confluence upgrade) to increase transaction throughput and reduce fees.

On Ethereum Mainnet, only the `LivepeerToken` and `BridgeMinter` contracts remain operational. All other Ethereum Mainnet protocol contracts are paused.

This keeps the token's security anchored to Ethereum Mainnet while all protocol operations run on Arbitrum One.
</Tip>

#### **LivepeerToken (LPT)**: <Subtitle text="ERC-20 Token" />
<Badge color="green">Dual-chain — Ethereum Mainnet (origin) and Arbitrum One</Badge>

The LivepeerToken is the native protocol token. The canonical contract lives on Ethereum Mainnet; an equivalent representation exists on Arbitrum One via the bridge.

<Accordion title="LivepeerToken">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0x289ba1701C2F088cf0faf8B3705246331cB8A839" newline={false} />
  ```
  0x289ba1701C2F088cf0faf8B3705246331cB8A839
  ```
  {/* Verified on-chain 18 Mar 2026 via Controller.getContract(keccak256("LivepeerToken")). */}

  **Address (Ethereum Mainnet)**:
  <LinkArrow label="View on Etherscan" href="https://etherscan.io/address/0x58b6a8a3302369daec383334672404ee733ab239" newline={false} />
  ```
  0x58b6a8a3302369daec383334672404ee733ab239
  ```
  {/* Verified on-chain 18 Mar 2026 via Blockscout get_address_info (chain 1). 1.88M holders. */}

  **Purpose**:
  - ERC-20 token used for bonding, staking, payment reserves, and governance voting weight
  - `approve()` must be called before bonding or funding deposits

  **Key functions**:
  - Standard ERC-20: `transfer()`, `balanceOf()`, `totalSupply()`, `approve()`, `transferFrom()`
  - `mint(address _to, uint256 _amount)` — callable only by addresses with MINTER_ROLE
</Accordion>

#### **BridgeMinter**: <Subtitle text="Token Bridge Minting" />
<Badge color="green">Ethereum Mainnet</Badge>

Holds the MINTER_ROLE on the L1 LivepeerToken contract. Called by the bridge when LPT is transferred from Arbitrum back to L1.

<Accordion title="BridgeMinter">
  **Address (Ethereum Mainnet)**:
  <LinkArrow label="View on Etherscan" href="https://etherscan.io/address/0x8dDDB96CF36AC8860f1DE5C7c4698fd499FAB405" newline={false} />
  ```
  0x8dDDB96CF36AC8860f1DE5C7c4698fd499FAB405
  ```
  {/* Verified on-chain 18 Mar 2026 via Blockscout get_address_info (chain 1). */}
</Accordion>

#### **LivepeerTokenFaucet**: <Subtitle text="Test Token Distribution" />
<Badge color="surface">Testnets Only</Badge>

Used on testnets for distributing test LPT. **Does not exist on Ethereum Mainnet or Arbitrum One mainnet.**

<CustomDivider />

## Governance Contracts

The Delta upgrade (LIP-89, LIP-91 — October 2023) introduced on-chain governance via four contracts: BondingVotes (stake checkpointing), LivepeerGovernor (OpenZeppelin Governor-based voting), Treasury (funded by protocol inflation), and Governor (the existing upgrade executor).

#### **Governor**: <Subtitle text="Protocol Upgrade Executor" />

Holds the owner role on the Controller and executes protocol upgrade transactions after governance approval.

<Accordion title="Governor">
  **Address (Arbitrum One)**:
  <LinkArrow label="View on Arbiscan" href="https://arbiscan.io/address/0xD9dEd6f9959176F0A04dcf88a0d2306178A736a6" newline={false} />
  ```
  0xD9dEd6f9959176F0A04dcf88a0d2306178A736a6
  ```
  {/* Verified on-chain 18 Mar 2026 via Blockscout get_address_info. Deployed by Livepeer Deployer. */}

  **Purpose**:
  - Owns